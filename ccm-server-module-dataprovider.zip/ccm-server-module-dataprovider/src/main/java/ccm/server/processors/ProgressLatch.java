package ccm.server.processors;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

@Data
@Slf4j
public class ProgressLatch {
    private final CountDownLatch rollBackLatch = new CountDownLatch(1);
    private CountDownLatch mainThreadLatch;
    private final AtomicBoolean rollBack = new AtomicBoolean(false);

    public ProgressLatch(int mainThreads) {
        this.mainThreadLatch = new CountDownLatch(mainThreads);
    }

    public ProgressLatch() {

    }

    public void setMainThreads(Integer count) {
        if (this.mainThreadLatch != null) {
            long latchCount = this.mainThreadLatch.getCount();
            this.mainThreadLatch = new CountDownLatch(Integer.parseInt(Long.toString(latchCount)) + count);
        } else
            this.mainThreadLatch = new CountDownLatch(count);
    }
}
