package ccm.server.processors;

import ccm.server.callables.DmlCallable;
import ccm.server.callables.base.CallableBase;
import ccm.server.callables.base.DmlCallableBase;
import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.*;
import ccm.server.interfaces.Function;
import ccm.server.models.LiteObject;
import ccm.server.models.ResultSet;
import ccm.server.params.IfAndPRCarrier;
import ccm.server.params.InfoDetailsCarrier;
import ccm.server.util.CommonUtility;
import ccm.server.util.GeneralUtility;
import ccm.server.util.PerformanceUtility;
import cn.hutool.core.exceptions.ExceptionUtil;
import cn.hutool.core.thread.ThreadFactoryBuilder;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.util.StopWatch;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Slf4j
@Service("threadsProcessor")
public class ThreadsProcessor {
    @Autowired
    private PlatformTransactionManager transactionManager;

    public static ThreadsProcessor Instance;

    public PlatformTransactionManager getTransactionManager() {
        return this.transactionManager;
    }

    public TransactionStatus getTransactionStatus() {
        DefaultTransactionDefinition defaultTransactionDefinition = new DefaultTransactionDefinition();
        defaultTransactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
        defaultTransactionDefinition.setIsolationLevel(TransactionDefinition.ISOLATION_REPEATABLE_READ);
        return this.transactionManager.getTransaction(defaultTransactionDefinition);
    }

    @PostConstruct
    public void doInit() {
        Instance = this;
        Instance.transactionManager = this.transactionManager;
    }

    public static final int count = 2000;
    public static final int N_CPUS = 1500;//Runtime.getRuntime().availableProcessors();

    /**
     * 实际CPU核数
     */
    public static final int AVAILABLE_PROCESSORS = Runtime.getRuntime().availableProcessors();

    /*private final ThreadPoolExecutor execPool = ExecutorBuilder.create()
            .setCorePoolSize(N_CPUS)
            .setMaxPoolSize(N_CPUS * 2)
            .setWorkQueue(new LinkedBlockingQueue<>(1024))
            .build();*/
    /**
     * 线程工厂,用于创建线程
     */
    private static final ThreadFactory threadFactory =
            ThreadFactoryBuilder.create()
                    .setNamePrefix("==IMC-Transaction-Thread-")
                    .build();
    /**
     * 线程池创建
     */
    private final static ThreadPoolExecutor execPool = new ThreadPoolExecutor(
            N_CPUS,
            N_CPUS * 2,
            TimeUnit.SECONDS.toNanos(60), TimeUnit.NANOSECONDS,
            new LinkedBlockingQueue<>(1024),
            threadFactory,
            new ThreadPoolExecutor.AbortPolicy()) {
        /**
         * 线程执行前执行
         * @param t
         * @param r
         */
        @Override
        protected void beforeExecute(Thread t, Runnable r) {
            super.beforeExecute(t, r);
            log.trace("{} before execute !", t.getName());
        }

        /**
         * 线程执行后执行
         * @param r
         * @param t
         */
        @Override
        protected void afterExecute(Runnable r, Throwable t) {
            super.afterExecute(r, t);
            // log.trace("after execute " + r.toString());
            if (t != null) {
                log.error("子线程执行存在异常,异常信息:{}", ExceptionUtil.getMessage(t), ExceptionUtil.getRootCause(t));
            } else {
                if (r instanceof Future<?>) {
                    try {
                        //get这里会首先检查任务的状态，然后将上面的异常包装成ExecutionException
                        Object result = ((Future<?>) r).get();
                    } catch (CancellationException ce) {
                        t = ce;
                    } catch (ExecutionException ee) {
                        t = ee.getCause();
                        log.error("子线程执行存在异常,异常信息:{}", ExceptionUtil.getMessage(t), ExceptionUtil.getRootCause(t));
                    } catch (InterruptedException ie) {
                        // ignore/reset
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }

        /**
         * 线程终止后执行
         */
        @Override
        protected void terminated() {
            super.terminated();
        }
    };

    public <T> Future<T> execute(Callable<T> callable) {
        return execPool.submit(callable);
    }

    public <T> List<T> execute(List<Callable<T>> callables) {
        StopWatch stopWatch = PerformanceUtility.start();
        List<T> result = new ArrayList<>();
        if (callables != null && callables.size() > 0) {
            List<List<Callable<T>>> listList = CommonUtility.createList(callables, 500);
            for (List<Callable<T>> callableList : listList) {
                List<Future<T>> futures = this.future(callableList);
                if (CommonUtility.hasValue(futures)) {
                    for (Future<T> future : futures) {
                        T t = null;
                        try {
                            t = future.get();
                            result.add(t);
                        } catch (Exception e) {
                            log.error(e.getMessage());
                        }
                    }
                }
            }
        }
        log.trace("finish to execute:" + result.size() + PerformanceUtility.stop(stopWatch));
        return result;
    }

    public <T> List<T> execute(List<Callable<T>> callables, ThreadPoolExecutor pool) {
        StopWatch stopWatch = PerformanceUtility.start();
        List<T> result = new ArrayList<>();
        if (callables != null && callables.size() > 0) {
            List<List<Callable<T>>> listList = CommonUtility.createList(callables, 500);
            for (List<Callable<T>> callableList : listList) {
                List<Future<T>> futures = this.future(callableList, pool);
                if (CommonUtility.hasValue(futures)) {
                    for (Future<T> future : futures) {
                        T t = null;
                        try {
                            t = future.get();
                            result.add(t);
                        } catch (Exception e) {
                            log.error(e.getMessage());
                        }
                    }
                }
            }
        }
        log.trace("finish to execute:" + result.size() + PerformanceUtility.stop(stopWatch));
        return result;
    }

    private <T> List<Future<T>> future(List<Callable<T>> callable, ThreadPoolExecutor pool) {
        List<Future<T>> result = new ArrayList<>();
        if (CommonUtility.hasValue(callable)) {
            for (Callable<T> callable1 : callable) {
                result.add(pool.submit(callable1));
            }
        }
        return result;
    }


    public <T> List<T> executeList(List<Callable<List<T>>> callables) {
        StopWatch stopWatch = PerformanceUtility.start();
        List<T> result = new ArrayList<>();
        List<Future<List<T>>> futures = this.futureList(callables);
        if (CommonUtility.hasValue(futures)) {
            for (Future<List<T>> future : futures) {
                List<T> t = null;
                try {
                    t = future.get();
                    result.addAll(t);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
        log.info("finish to execute list:" + result.size() + PerformanceUtility.stop(stopWatch));
        return result;
    }

    private <T> List<Future<List<T>>> futureList(List<Callable<List<T>>> callables) {
        List<Future<List<T>>> result = new ArrayList<>();
        if (CommonUtility.hasValue(callables)) {
            for (Callable<List<T>> callable1 : callables) {
                result.add(execPool.submit(callable1));
            }
        }
        return result;
    }


    private <T> List<Future<T>> future(List<Callable<T>> callable) {
        List<Future<T>> result = new ArrayList<>();
        if (CommonUtility.hasValue(callable)) {
            for (Callable<T> callable1 : callable) {
                result.add(execPool.submit(callable1));
            }
        }
        return result;
    }


    private <T, V> void result(ResultSet<T> resultSet, List<Future<V>> futures, Function<V, T> consumer) {
        if (resultSet == null)
            resultSet = new ResultSet<>();
        if (CommonUtility.hasValue(futures)) {
            for (Future<V> future : futures) {
                V v = null;
                try {
                    v = future.get();
                    List<T> ts = consumer.result(v);
                    if (CommonUtility.hasValue(ts))
                        resultSet.getList().addAll(ts);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    public ResultSet<LiteObject> fillingRel(MetaDataRel rel, ThrowableConsumer<IfAndPRCarrier<MetaDataRel>> consumer, String... parrTablePrefixes) {
        ResultSet<LiteObject> result = new ResultSet<>();
        if (rel != null && consumer != null) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<Callable<IfAndPRCarrier<MetaDataRel>>> callables = new ArrayList<>();
            if (parrTablePrefixes != null && parrTablePrefixes.length > 0) {
                for (String tablePrefix : parrTablePrefixes) {
                    callables.add(() -> {
                        IfAndPRCarrier<MetaDataRel> carrier = new IfAndPRCarrier<MetaDataRel>(rel, tablePrefix);
                        consumer.accept(carrier);
                        return carrier;
                    });
                }
            }
            List<Future<IfAndPRCarrier<MetaDataRel>>> futures = this.future(callables);
            this.result(result, futures, IfAndPRCarrier::toAdvancedLiteObject);
            log.trace("filling metadata rel completed" + PerformanceUtility.stop(stopWatch));
        }
        this.mergeResultForIFAndPR(result);
        return result;
    }

    public ResultSet<LiteObject> fillingRelWithInfoDetails(List<MetaDataRel> metaDataRels, ThrowableConsumer<InfoDetailsCarrier<MetaDataRel>> infoDetailsCarrierThrowableConsumer, String... tablePrefixes) {
        ResultSet<LiteObject> result = new ResultSet<>();
        if (metaDataRels != null && metaDataRels.size() > 0 && tablePrefixes != null && tablePrefixes.length > 0) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<List<MetaDataRel>> lists = CommonUtility.createList(metaDataRels, count);
            List<Callable<InfoDetailsCarrier<MetaDataRel>>> callables = new ArrayList<>();
            for (String tablePrefix : tablePrefixes) {
                for (List<MetaDataRel> list : lists) {
                    Callable<InfoDetailsCarrier<MetaDataRel>> callable = () -> {
                        InfoDetailsCarrier<MetaDataRel> paramWithResult = new InfoDetailsCarrier<MetaDataRel>(MetaDataRel.class, list, tablePrefix);
                        infoDetailsCarrierThrowableConsumer.accept(paramWithResult);
                        return paramWithResult;
                    };
                    callables.add(callable);
                }
            }
//            List<List<Callable<InfoDetailsCarrier<MetaDataRel>>>> listList = CommonUtility.createList(callables, 1);
//            for (List<Callable<InfoDetailsCarrier<MetaDataRel>>> callableList : listList) {
            List<Future<InfoDetailsCarrier<MetaDataRel>>> futures = this.future(callables);
            this.result(result, futures, InfoDetailsCarrier::toLiteObject);
            if (result.size() == 0) {
                result.getList().addAll(metaDataRels.stream().map(LiteObject::new).collect(Collectors.toSet()));
            }
//            }
            log.trace("filling metadata object(s) with info details completed" + PerformanceUtility.stop(stopWatch));
        }
        return result;
    }

    public ResultSet<LiteObject> fillingRel(List<MetaDataRel> rels, ThrowableConsumer<IfAndPRCarrier<MetaDataRel>> consumer, String... tablePrefixes) {
        ResultSet<LiteObject> result = new ResultSet<>();
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(rels) && consumer != null && tablePrefixes != null && tablePrefixes.length > 0) {
            List<List<MetaDataRel>> listList = CommonUtility.createList(rels, count);
            List<Callable<IfAndPRCarrier<MetaDataRel>>> callables = new ArrayList<>();
            for (String tablePrefix : tablePrefixes) {
                for (List<MetaDataRel> list : listList) {
                    Callable<IfAndPRCarrier<MetaDataRel>> callable = () -> {
                        IfAndPRCarrier<MetaDataRel> relIFAndPRCarrier = new IfAndPRCarrier<MetaDataRel>(list, tablePrefix);
                        consumer.accept(relIFAndPRCarrier);
                        return relIFAndPRCarrier;
                    };
                    callables.add(callable);
                }
            }
            List<Future<IfAndPRCarrier<MetaDataRel>>> futures = this.future(callables);
            this.result(result, futures, IfAndPRCarrier::toAdvancedLiteObject);
            log.trace("filling metadata rel completed" + PerformanceUtility.stop(stopWatch));
        }
        return result;
    }

    private void mergeResultForIFAndPR(ResultSet<LiteObject> source) {
        if (source != null) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> liteObjects = source.getList();
            if (CommonUtility.hasValue(liteObjects)) {
                List<LiteObject> result = new ArrayList<>();
                Map<String, List<LiteObject>> mapByOBID = GeneralUtility.toMapByOBID(liteObjects);
                for (Map.Entry<String, List<LiteObject>> listEntry : mapByOBID.entrySet()) {
                    LiteObject liteObject = listEntry.getValue().get(0);
                    for (int i = 1; i < listEntry.getValue().size(); i++) {
                        LiteObject current = listEntry.getValue().get(i);
                        liteObject.merge(current);
                    }
                    result.add(liteObject);
                }
                source.setList(result);
            }
            log.trace("complete to merge for IF and PR" + PerformanceUtility.stop(stopWatch));
        }
    }

    public ResultSet<LiteObject> fillingObj(MetaDataObj obj, ThrowableConsumer<IfAndPRCarrier<MetaDataObj>> consumer, String... parrTablePrefixes) {
        ResultSet<LiteObject> result = new ResultSet<>();
        StopWatch stopWatch = PerformanceUtility.start();
        if (obj != null && consumer != null) {
            List<Callable<IfAndPRCarrier<MetaDataObj>>> callables = new ArrayList<>();
            if (parrTablePrefixes != null && parrTablePrefixes.length > 0) {
                for (String tablePrefix : parrTablePrefixes) {
                    callables.add(() -> {
                        IfAndPRCarrier<MetaDataObj> ifAndPRCarrier = new IfAndPRCarrier<MetaDataObj>(obj, tablePrefix);
                        consumer.accept(ifAndPRCarrier);
                        return ifAndPRCarrier;
                    });
                }
            }
            List<Future<IfAndPRCarrier<MetaDataObj>>> futures = this.future(callables);
            this.result(result, futures, IfAndPRCarrier::toAdvancedLiteObject);
            log.trace("filling metadata object completed" + PerformanceUtility.stop(stopWatch));
        }
        this.mergeResultForIFAndPR(result);
        return result;
    }

    public ResultSet<LiteObject> fillingObjWithInfoDetails(List<MetaDataObj> metaDataObjs, ThrowableConsumer<InfoDetailsCarrier<MetaDataObj>> infoDetailsCarrierThrowableConsumer, String... tablePrefixes) {
        ResultSet<LiteObject> result = new ResultSet<>();
        if (metaDataObjs != null && metaDataObjs.size() > 0 && tablePrefixes != null && tablePrefixes.length > 0) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<List<MetaDataObj>> lists = CommonUtility.createList(metaDataObjs, count);
            List<Callable<InfoDetailsCarrier<MetaDataObj>>> callables = new ArrayList<>();
            for (String tablePrefix : tablePrefixes) {
                for (List<MetaDataObj> list : lists) {
                    Callable<InfoDetailsCarrier<MetaDataObj>> callable = () -> {
                        InfoDetailsCarrier<MetaDataObj> paramWithResult = new InfoDetailsCarrier<MetaDataObj>(MetaDataObj.class, list, tablePrefix);
                        infoDetailsCarrierThrowableConsumer.accept(paramWithResult);
                        return paramWithResult;
                    };
                    callables.add(callable);
                }
            }
//            List<List<Callable<InfoDetailsCarrier<MetaDataObj>>>> listList = CommonUtility.createList(callables, 1);
//            for (List<Callable<InfoDetailsCarrier<MetaDataObj>>> callableList : listList) {
            List<Future<InfoDetailsCarrier<MetaDataObj>>> futures = this.future(callables);
            this.result(result, futures, InfoDetailsCarrier::toLiteObject);
//            }
            log.trace("filling metadata object(s) with info details completed" + PerformanceUtility.stop(stopWatch));
        }
        return result;
    }

    public ResultSet<LiteObject> fillingObj(List<MetaDataObj> objs, ThrowableConsumer<IfAndPRCarrier<MetaDataObj>> consumer, String... parrTablePrefixes) {
        ResultSet<LiteObject> result = new ResultSet<>();
        if (CommonUtility.hasValue(objs) && consumer != null) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<List<MetaDataObj>> listList = CommonUtility.createList(objs, count);
            List<Callable<IfAndPRCarrier<MetaDataObj>>> callables = new ArrayList<>();
            if (parrTablePrefixes != null) {
                for (String tablePrefix : parrTablePrefixes) {
                    for (List<MetaDataObj> list : listList) {
                        Callable<IfAndPRCarrier<MetaDataObj>> callable = () -> {
                            IfAndPRCarrier<MetaDataObj> ifAndPRCarrier = new IfAndPRCarrier<MetaDataObj>(list, tablePrefix);
                            consumer.accept(ifAndPRCarrier);
                            return ifAndPRCarrier;
                        };
                        callables.add(callable);
                    }
                }
            }
            List<List<Callable<IfAndPRCarrier<MetaDataObj>>>> listList1 = CommonUtility.createList(callables, 100);
            for (List<Callable<IfAndPRCarrier<MetaDataObj>>> callableList : listList1) {
                List<Future<IfAndPRCarrier<MetaDataObj>>> futures = this.future(callableList);
                this.result(result, futures, IfAndPRCarrier::toAdvancedLiteObject);
            }
            log.trace("filling metadata object(s) completed" + PerformanceUtility.stop(stopWatch));
        }
        this.mergeResultForIFAndPR(result);
        return result;
    }

    public <T extends MetaData> ResultSet<T> queryMT(List<T> source, ThrowableConsumer<List<T>> consumer) {
        ResultSet<T> result = new ResultSet<>();
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(source) && consumer != null) {
            List<List<T>> listList = CommonUtility.createList(source, count);
            for (List<T> ts : listList) {
                consumer.accept(ts);
                if (CommonUtility.hasValue(ts))
                    result.getList().addAll(ts);
            }
            result.setResult(true);
        }
        log.trace("query under main thread completed" + PerformanceUtility.stop(stopWatch));
        return result;
    }

    public <T extends MetaData> ResultSet<T> query(List<T> source, ThrowableConsumer<List<T>> consumer) {
        ResultSet<T> result = new ResultSet<>();
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(source) && consumer != null) {
            List<List<T>> listList = CommonUtility.createList(source, count);
            List<CallableBase<T>> callableMetaWrappers = new ArrayList<>();
            for (List<T> list : listList) {
                CallableBase<T> metaWrapper = new CallableBase<T>(list, consumer);
                callableMetaWrappers.add(metaWrapper);
            }
            List<Future<List<T>>> futures = new ArrayList<>();
            for (CallableBase<T> task : callableMetaWrappers)
                futures.add(execPool.submit(task));

            for (Future<List<T>> future : futures) {
                List<T> ts = null;
                try {
                    ts = future.get();
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                } finally {
                    if (result.getResult() && CommonUtility.hasValue(ts))
                        result.getList().addAll(ts);
                }
            }
            log.trace("threads query finish:" + result.getResult() + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    public <T extends MetaData> void addCallableJob(DmlCallable<T> callable, JobWrapper<T> jobWrapper) {
        if (callable != null && jobWrapper != null) {
            for (JobWrapperEntity<T> job : jobWrapper.getJobs()) {
                callable.add(job);
            }
        }
    }

    public <T extends MetaData> DmlCallable<T> generateCallable(JobWrapper<T> jobWrapper, ProgressLatch progressLatch, int startExecutionOrder) {
        if (jobWrapper != null && progressLatch != null) {
            DmlCallable<T> metaDataDMLCallable = new DmlCallable<>(this.transactionManager);
            metaDataDMLCallable.setProgressLatch(progressLatch);
            startExecutionOrder++;
            metaDataDMLCallable.setExecutionOrder(startExecutionOrder);
            progressLatch.setMainThreads(1);
            for (JobWrapperEntity<T> job : jobWrapper.getJobs()) {
                metaDataDMLCallable.add(job);
            }
            return metaDataDMLCallable;
        }
        return null;
    }

    protected <T extends MetaData> void raiseErrorAfterProceeded(ResultSet<T> resultSet, List<DmlCallable<T>> callableMetaWrappers) throws Exception {
        if (CommonUtility.hasValue(callableMetaWrappers) && resultSet != null) {
            List<String> errorMessages = new ArrayList<>();
            for (DmlCallable<T> callable : callableMetaWrappers) {
                List<Exception> exceptions = callable.exceptions();
                if (CommonUtility.hasValue(exceptions)) {
                    errorMessages.addAll(exceptions.stream().map(Throwable::getMessage).collect(Collectors.toList()));
                }
            }
            if (errorMessages.size() > 0)
                throw new Exception(String.join(StringPool.CRLF, errorMessages));
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public <T extends MetaData> ResultSet<T> getResult(List<DmlCallable<T>> callableMetaWrappers, ProgressLatch progressLatch) throws Exception {
        ResultSet<T> result = new ResultSet<>();
        StopWatch stopWatch = PerformanceUtility.start();
        List<Future<List<T>>> futureArrayList = new ArrayList<>();
        //  log.trace("submit " + callableMetaWrappers.size() + " callable(s) to thread pool for execution");
        List<DmlCallable<T>> dmlCallables = new ArrayList<>(callableMetaWrappers);
        dmlCallables.sort(Comparator.comparingInt(DmlCallableBase::getExecutionOrder));
        for (DmlCallable<T> task : dmlCallables)
            futureArrayList.add(execPool.submit(task));
        progressLatch.getMainThreadLatch().await();
        this.raiseErrorAfterProceeded(result, dmlCallables);
        if (!progressLatch.getRollBack().get()) {
            for (Future<List<T>> future : futureArrayList) {
                List<T> ts = null;
                try {
                    ts = future.get();
                } catch (Exception e) {
                    result.setException(e);
                } finally {
                    if (result.getResult() && CommonUtility.hasValue(ts))
                        result.getList().addAll(ts);
                }
            }
        } else {
            result.setResult(false);
            result.getList().clear();
        }
        // log.trace("complete to get result with provided dml callable(s)" + PerformanceUtility.stop(stopWatch));
        return result;
    }

    public static HashMap<String, String> getThreadPoolStatus() {
        HashMap<String, String> stringStringHashMap = new HashMap<>();
        stringStringHashMap.put("当前排队线程数", String.valueOf(execPool.getQueue().size()));
        stringStringHashMap.put("当前活动线程数", String.valueOf(execPool.getActiveCount()));
        stringStringHashMap.put("当前线程池的大小", String.valueOf(execPool.getPoolSize()));
        stringStringHashMap.put("线程池的最大容量", String.valueOf(execPool.getMaximumPoolSize()));
        stringStringHashMap.put("线程池曾经达到的线程的最大数", String.valueOf(execPool.getLargestPoolSize()));
        stringStringHashMap.put("执行完成任务数", String.valueOf(execPool.getCompletedTaskCount()));
        stringStringHashMap.put("总任务数", String.valueOf(execPool.getTaskCount()));
        stringStringHashMap.put("核心线程数", String.valueOf(execPool.getCorePoolSize()));
        return stringStringHashMap;
    }
}
