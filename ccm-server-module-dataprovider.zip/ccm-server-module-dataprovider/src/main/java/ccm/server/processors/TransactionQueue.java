package ccm.server.processors;

import ccm.server.entity.TransactionJob;
import ccm.server.models.ResultSet;
import ccm.server.util.ReentrantLockUtility;
import lombok.extern.slf4j.Slf4j;
import org.jeecg.common.util.SpringContextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Slf4j
@Service
public class TransactionQueue {
    @Autowired
    private ThreadsProcessor threadsProcessor;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final AtomicBoolean isRunning = new AtomicBoolean(false);

    //    @Transactional(rollbackFor = Exception.class)
    public void execute(TransactionJob transactionJob) throws Exception {
        if (!this.isRunning.get()) {
            Exception exception = null;
            this.isRunning.set(true);
            try {
                if (transactionJob != null) {
                    this.submit(transactionJob);
                }
            } catch (Exception e) {
                exception = e;
            } finally {
                this.isRunning.set(false);
            }
            if (exception != null)
                throw exception;
        }
    }

    //    @Transactional(rollbackFor = Exception.class)
    public void submit(TransactionJob transactionJob) throws Exception {
        if (transactionJob != null) {
            if (transactionJob.getProgressLatch() != null && transactionJob.getCallables() != null && transactionJob.getCallables().size() > 0) {
                transactionJob.getMyProcessingLatch().countDown();
                ResultSet result = null;
                try {
                    result = SpringContextUtils.getBean(ThreadsProcessor.class).getResult(transactionJob.getCallables(), transactionJob.getProgressLatch());
                    if (result != null)
                        result.Throw();
                } catch (Exception exception) {
                    transactionJob.setException(exception);
                } finally {
                    transactionJob.getMyProcessingLatch().countDown();
                    transactionJob.getMyLatch().countDown();
                }
                transactionJob.await();
                transactionJob.raiseError();
            }
        }
    }
}
