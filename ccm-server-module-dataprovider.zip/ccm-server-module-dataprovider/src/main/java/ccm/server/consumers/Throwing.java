package ccm.server.consumers;

import javax.validation.constraints.NotNull;
import java.util.function.Consumer;

public class Throwing {
    private Throwing() {
    }

    @NotNull
    public static <T> Consumer<T> rethrow(@NotNull final ThrowableConsumer<T> consumer) {
        return consumer;
    }
    
    @SuppressWarnings("unchecked")
    @NotNull
    public static <E extends Exception> void sneakyThrow(@NotNull final Exception ex) throws E {
        throw (E) ex;
    }
}
