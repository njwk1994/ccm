package ccm.server.consumers;

import java.util.function.Consumer;

@FunctionalInterface
public interface ThrowableConsumer<T> extends Consumer<T> {

    @Override
    default void accept(final T e) {
        try {
            accept0(e);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            Throwing.sneakyThrow(ex);
        }
    }

    void accept0(T e) throws Exception;
}
