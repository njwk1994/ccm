package ccm.server.util;

import ccm.server.enums.operator;
import ccm.server.enums.propertyDefinitionType;
import ccm.server.enums.propertyValueType;
import com.baomidou.mybatisplus.core.enums.SqlKeyword;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.github.yulichang.toolkit.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class SqlHelper {
    public static final String TABLE_OBJ_IF = "OBJIF";
    public static final String TABLE_OBJ_PR = "OBJPR";
    public static final String TABLE_OBJ_REL = "OBJREL";
    public static final String TABLE_OBJ = "OBJ";
    private static final String MAIN_TABLE_OBID = Constant.TABLE_ALIAS + StringPool.DOT + propertyDefinitionType.OBID;

    public static String tableSuffix(Integer tableIndex) {
        if (tableIndex == null)
            return StringPool.EMPTY;
        return String.valueOf(tableIndex);
    }

    public static String generateConditionValue(ccm.server.enums.operator operator, String valueType, String value) {
        StringBuilder stringBuilder = new StringBuilder();
        if (operator == null) operator = ccm.server.enums.operator.equal;
        propertyValueType propertyValueType = ccm.server.enums.propertyValueType.StringType;
        if (!StringUtils.isEmpty(valueType))
            ccm.server.enums.propertyValueType.valueOf(valueType);
        switch (operator) {
            case equal:
            case notEqual:
                stringBuilder.append("").append(StringPool.SINGLE_QUOTE).append(value).append(StringPool.SINGLE_QUOTE);
                break;
            case largeOrEqualThan:
            case lessOrEqualThan:
            case largeThan:
            case lessThan:
                switch (propertyValueType) {
                    case IntegerType:
                    case DoubleType:
                        stringBuilder.append(value);
                        break;
                    default:
                        stringBuilder.append(StringPool.SINGLE_QUOTE).append(value).append(StringPool.SINGLE_QUOTE);
                        break;
                }
                break;
            case in:
            case notIn:
                stringBuilder.append(StringPool.LEFT_BRACKET).append(Arrays.stream(getValueArray(value)).map(c -> "" + StringPool.SINGLE_QUOTE + c + StringPool.SINGLE_QUOTE).collect(Collectors.joining(","))).append(StringPool.RIGHT_BRACKET);
                break;
            case notLike:
            case like:
                stringBuilder.append("").append(StringPool.SINGLE_QUOTE).append(getReplacedValueFromSTARIntoPERCENT(value)).append(StringPool.SINGLE_QUOTE);
                break;
            case between:
                Object[] array = getValueArrayWith2Elements(value);
                switch (propertyValueType) {
                    case IntegerType:
                    case DoubleType:
                        stringBuilder.append(array[0]).append(StringPool.SPACE).append(StringPool.AND).append(StringPool.SPACE).append(array[1]);
                        break;
                    default:
                        stringBuilder.append(StringPool.SINGLE_QUOTE).append(array[0]).append(StringPool.SINGLE_QUOTE).append(StringPool.SPACE).append(StringPool.AND).append(StringPool.SPACE).append(StringPool.SINGLE_QUOTE).append(array[1]).append(StringPool.SINGLE_QUOTE);
                        break;
                }
                break;
            case _is:
            case _isNOT:
                stringBuilder.append(StringPool.NULL);
                break;
        }
        String result = stringBuilder.toString();
        if (StringUtils.isEmpty(result)) {
            result = StringPool.SINGLE_QUOTE + StringPool.SINGLE_QUOTE;
        }
        return result;
    }

    public static String getReplacedValueFromSTARIntoPERCENT(String value) {
        return CommonUtility.replaceValueFromSTARIntoPERCENT(value);
    }

    public static String[] getValueArray(String value) {
        String[] temp = CommonUtility.valueArray(value);
        String[] result = new String[temp.length];
        for (int i = 0; i < temp.length; i++) {
            String current = temp[i];
            result[i] = CommonUtility.replaceCharToComma(current);
        }
        return result;
    }

    public static Object[] getValueArrayWith2Elements(String value) {
        return CommonUtility.valueArrayWith2Elements(value);
    }

    public static String sqlJoinOnOBIDToOBID1(String table) {
        return MAIN_TABLE_OBID + SqlKeyword.EQ.getSqlSegment() + propertyDefinitionType.OBID1.generateColumn(table);
    }

    public static String sqlJoinOnOBIDToOBID2(String table) {
        return MAIN_TABLE_OBID + SqlKeyword.EQ.getSqlSegment() + propertyDefinitionType.OBID2.generateColumn(table);
    }

    public static String sqlJoinOnOBID1ToOBJOBID(String mainTable, String joinTable) {
        return propertyDefinitionType.OBID1.generateColumn(mainTable) + SqlKeyword.EQ.getSqlSegment() + propertyDefinitionType.OBJOBID.generateColumn(joinTable);
    }

    public static String sqlJoinOnOBID2ToOBJOBID(String mainTable, String joinTable) {
        return propertyDefinitionType.OBID2.generateColumn(mainTable) + SqlKeyword.EQ.getSqlSegment() + propertyDefinitionType.OBJOBID.generateColumn(joinTable);
    }

    public static String sqlJoinOnOBIDToOBJOBID(String table) {
        return MAIN_TABLE_OBID +
                SqlKeyword.EQ.getSqlSegment() +
                propertyDefinitionType.OBJOBID.generateColumn(table);
    }

    public static String sqlIsNull(String table) {
        return ccm.server.enums.propertyDefinitionType.OBID.generateColumn(table) + StringPool.SPACE + SqlKeyword.IS_NULL.getSqlSegment();
    }

    public static String sqlTerminationUser(String table) {
        return StringPool.LEFT_BRACKET +
                propertyDefinitionType.TerminationUser.generateColumn(table) +
                StringPool.SPACE +
                SqlKeyword.IS_NULL.getSqlSegment() +
                StringPool.SPACE +
                SqlKeyword.OR.getSqlSegment() +
                StringPool.SPACE +
                propertyDefinitionType.TerminationUser.generateColumn(table) +
                SqlKeyword.EQ.getSqlSegment() +
                StringPool.SINGLE_QUOTE + StringPool.SINGLE_QUOTE +
                StringPool.RIGHT_BRACKET;
    }

    public static String sqlPropertyStrValue(String table, String valueType, ccm.server.enums.operator operator, String value) {
        return sqlColumnValue(propertyDefinitionType.STRVALUE, valueType, table, operator, value);
    }

    public static String sqlPropertyDef(String table, String propertyDefinitionUID) {
        return propertyDefinitionType.PropertyDefinitionUID.generateColumn(table) + SqlKeyword.EQ.getSqlSegment() + StringPool.SINGLE_QUOTE + propertyDefinitionUID + StringPool.SINGLE_QUOTE;
    }

    public static String sqlRelDef(String table, String relDefUID) {
        return propertyDefinitionType.RelDefUID.generateColumn(table) + SqlKeyword.EQ.getSqlSegment() + StringPool.SINGLE_QUOTE + relDefUID + StringPool.SINGLE_QUOTE;
    }

    public static String sqlColumnValue(propertyDefinitionType propertyDefinitionType, String valueType, String table, ccm.server.enums.operator operator, String value) {
        return propertyDefinitionType.generateColumn(table) + operator.getActualOperator() + generateConditionValue(operator, valueType, value);
    }

    public static String joinInterfaceTable(String alias, Integer tableIndex) {
        List<String> segments = new ArrayList<>();
        String table = alias + (tableIndex == null ? "" : tableIndex);
        segments.add(TABLE_OBJ_IF);
        segments.add(table);
        segments.add(Constant.ON);
        segments.add(sqlJoinOnOBIDToOBJOBID(table));
        //        segments.add(StringPool.AND);
        //        segments.add(sqlTerminationUser(table));
        return String.join(" ", segments);
    }

    public static String joinPropertyTable(String alias, Integer tableIndex, String linkTable) {
        List<String> segments = new ArrayList<>();
        String table = alias + (tableIndex == null ? "" : tableIndex);
        segments.add(TABLE_OBJ_PR);
        segments.add(table);
        segments.add(Constant.ON);
        segments.add(propertyDefinitionType.InterfaceOBID.generateColumn(table) + operator.equal.getActualOperator() + propertyDefinitionType.OBID.generateColumn(linkTable));
        //        segments.add(StringPool.AND);
        //        segments.add(sqlTerminationUser(table));
        return String.join(" ", segments);
    }
}

