package ccm.server.util;

import ccm.server.models.db.DbWrapper;
import com.alibaba.druid.pool.DruidDataSource;
import com.baomidou.dynamic.datasource.DynamicRoutingDataSource;
import com.baomidou.dynamic.datasource.ds.ItemDataSource;
import com.baomidou.mybatisplus.annotation.DbType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;

@Service
@Slf4j
public class DbUtility {
    public final static String default_db_key = "master";
    @Autowired
    private DataSource dataSource;

    public DbWrapper getDefaultDbWrapper() {
        return new DbWrapper() {{
            this.setName(default_db_key);
            this.setDbType(getMasterDbType());
            this.setDbAlias(getActualDdName(getMasterDbSource()));
        }};
    }

    public DruidDataSource getMasterDbSource() {
        DynamicRoutingDataSource dynamicRoutingDataSource = (DynamicRoutingDataSource) dataSource;
        ItemDataSource dataSource = (ItemDataSource) dynamicRoutingDataSource.getDataSource(default_db_key);
        return (DruidDataSource) dataSource.getRealDataSource();
    }

    public DbType getMasterDbType() {
        DruidDataSource masterDbSource = this.getMasterDbSource();
        if (masterDbSource != null) {
            return DbType.getDbType(masterDbSource.getDbType().toUpperCase());
        }
        return null;
    }

    public static String getActualDdName(DruidDataSource dataSource) {
        if (dataSource != null) {
            String url = dataSource.getUrl();
            String[] strings = url.split("\\?");
            String[] split = strings[0].split("/");
            return split[split.length - 1];
        }
        return "";
    }
}
