package ccm.server.util;

import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataRel;
import ccm.server.models.LiteObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class GeneralUtility {

    public static void add(Map<String, LiteObject> sourceCollection, String key, LiteObject liteObject) {
        if (sourceCollection != null && !StringUtils.isEmpty(key)) {
            if (sourceCollection.containsKey(key))
                sourceCollection.replace(key, liteObject);
            else
                sourceCollection.put(key, liteObject);
        }
    }

    public static MetaDataRel instantiateRelationship(MetaDataObj end1, MetaDataObj end2, String relDef) {
        if (end1 != null && end2 != null && !StringUtils.isEmpty(relDef)) {
            MetaDataRel rel = new MetaDataRel();
            rel.setRelDefUid(relDef);
            rel.setDomainUid1(end1.getDomainUid());
            rel.setDomainUid2(end2.getDomainUid());
            rel.setName1(end1.getName());
            rel.setName2(end2.getName());
            rel.setUid1(end1.getObjUid());
            rel.setUid2(end2.getObjUid());
            rel.setConfig(end1.getConfig());
        }
        return null;
    }

    public static Map<String, List<LiteObject>> toMapByOBID(List<LiteObject> liteObjects) {
        Map<String, List<LiteObject>> result = new HashMap<>();
        if (CommonUtility.hasValue(liteObjects)) {
            for (LiteObject liteObject : liteObjects) {
                String obid = liteObject.getOBID();
                CommonUtility.doAddElementGeneral(result, obid, liteObject);
            }
        }
        return result;
    }

    public static void fillLiteObject(LiteObject liteObject, List<Map<String, Object>> sources) {
        if (liteObject != null && CommonUtility.hasValue(sources)) {
            
        }
    }
}
