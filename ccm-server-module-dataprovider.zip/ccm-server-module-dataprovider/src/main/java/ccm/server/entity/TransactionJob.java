package ccm.server.entity;

import ccm.server.callables.DmlCallable;
import ccm.server.models.ResultSet;
import ccm.server.processors.ProgressLatch;
import ccm.server.processors.ThreadsProcessor;
import ccm.server.util.CommonUtility;
import ccm.server.util.ISharedCommon;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.jeecg.common.util.SpringContextUtils;
import org.springframework.transaction.TransactionStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Collectors;

@Slf4j
@Data
public class TransactionJob<T extends MetaData> {
    private final List<DmlCallable<T>> callables;
    private final ProgressLatch progressLatch;
    private final String id;
    private Exception exception;
    private final CountDownLatch myLatch = new CountDownLatch(1);
    private final CountDownLatch myProcessingLatch = new CountDownLatch(2);
    private ThreadsProcessor threadsProcessor;

    public void await() {
        try {
            this.myLatch.await();
        } catch (InterruptedException e) {
            log.error("transaction job await failed", e);
        }
    }

    public String getId() {
        return this.id;
    }

    public Exception error() {
        return this.exception;
    }

    public void raiseError() throws Exception {
        if (this.exception != null)
            throw this.exception;
    }

    public void submit() throws Exception {
        this.commit();
        this.await();
        this.raiseError();
    }

    public boolean processing() {
        return this.myProcessingLatch.getCount() == 1;
    }

    public boolean completed() {
        return this.myLatch.getCount() == 0;
    }

    public List<String> getEffectTables() {
        List<String> result = new ArrayList<>();
        if (CommonUtility.hasValue(this.callables)) {
            for (DmlCallable<T> callable : this.callables) {
                List<JobWrapperEntity<T>> parameters = callable.getParameters();
                if (CommonUtility.hasValue(parameters)) {
                    List<String> keys = parameters.stream().map(JobWrapperEntity::getUniqueKey).distinct().map(c -> c.replace(ISharedCommon.COMMON_CONNECTOR, "")).collect(Collectors.toList());
                    result.addAll(keys);
                }
            }
        }
        return result;
    }

    public TransactionJob(ThreadsProcessor threadsProcessor, String id, List<DmlCallable<T>> callables, ProgressLatch progressLatch) {
        this.id = id;
        this.progressLatch = progressLatch;
        this.callables = callables;
        this.threadsProcessor = threadsProcessor;
    }

    public void commit() {
        log.trace("enter to commit under transaction job");
        if (this.progressLatch != null && this.callables != null && this.callables.size() > 0) {
            this.myProcessingLatch.countDown();
            ResultSet<T> result = null;
            TransactionStatus transactionStatus = this.threadsProcessor.getTransactionStatus();
            try {
                result = SpringContextUtils.getBean(ThreadsProcessor.class).getResult(callables, progressLatch);
                if (result != null)
                    result.Throw();
                this.threadsProcessor.getTransactionManager().commit(transactionStatus);
            } catch (Exception exception) {
                this.exception = exception;
                this.threadsProcessor.getTransactionManager().rollback(transactionStatus);
            } finally {
                this.myProcessingLatch.countDown();
                this.myLatch.countDown();
            }
        } else
            log.trace("nothing under transaction job and complete directly");
    }
}
