package ccm.server.entity;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.enums.CRUD;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class JobWrapperEntity<T extends MetaData> {
    private List<T> items;
    private ThrowableConsumer<List<T>> consumer;
    private CRUD crud;
    private final List<Exception> exceptions = new ArrayList<>();

    private String uniqueKey;

    public void setException(Exception exception) {
        if (exception != null)
            this.exceptions.add(exception);
    }

    public JobWrapperEntity(CRUD crud, List<T> items, ThrowableConsumer<List<T>> consumer) {
        this.crud = crud;
        this.items = items;
        this.consumer = consumer;
    }
}
