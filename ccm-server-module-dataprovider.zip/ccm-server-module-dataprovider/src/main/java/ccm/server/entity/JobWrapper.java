package ccm.server.entity;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.enums.CRUD;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;


@Data
public class JobWrapper<T extends MetaData> {
    private String uniqueKey;
    private final List<JobWrapperEntity<T>> jobs = new ArrayList<JobWrapperEntity<T>>();

    public void add(CRUD crud, List<T> items, ThrowableConsumer<List<T>> consumer) {
        if (items != null && consumer != null)
            this.jobs.add(new JobWrapperEntity<T>(crud, items, consumer) {{
                this.setUniqueKey(uniqueKey);
            }});
    }
}
