package ccm.server.interfaces;

import java.util.List;

@FunctionalInterface
public interface Function<T, V> {
    List<V> result(T t);
}
