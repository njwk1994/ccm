package ccm.server.method;

import com.baomidou.mybatisplus.core.metadata.TableInfo;
import com.baomidou.mybatisplus.core.toolkit.sql.SqlScriptUtils;
import com.github.yulichang.method.MPJAbstractMethod;
import com.github.yulichang.method.MPJResultType;
import com.github.yulichang.method.SqlMethod;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlSource;

//public class SelectJoinList extends MPJAbstractMethod {
//    protected String sqlDistinct() {
//        return SqlScriptUtils.convertIf("DISTINCT", "ew.selectDistinct", false);
//    }
//
//    @Override
//    public MappedStatement injectMappedStatement(Class<?> mapperClass, Class<?> modelClass, TableInfo tableInfo) {
//        SqlMethod sqlMethod = SqlMethod.SELECT_JOIN_LIST;
//        String sql = String.format(sqlMethod.getSql(), sqlFirst(), sqlDistinct(), sqlSelectColumns(tableInfo, true),
//                tableInfo.getTableName(), sqlAlias(), sqlFrom(), sqlWhereEntityWrapper(true, tableInfo), sqlComment());
//        SqlSource sqlSource = languageDriver.createSqlSource(configuration, sql, modelClass);
//        return this.addSelectMappedStatementForOther(mapperClass, sqlMethod.getMethod(), sqlSource, MPJResultType.class);
//    }
//}
