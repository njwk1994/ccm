package ccm.server.enums;

public enum CRUD {
    C,
    R,
    U,
    D,
    T,
    CUDT,
}
