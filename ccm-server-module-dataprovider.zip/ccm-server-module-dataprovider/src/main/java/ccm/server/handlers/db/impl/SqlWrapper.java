package ccm.server.handlers.db.impl;

import ccm.server.enums.CRUD;
import ccm.server.enums.tableSuffix;
import ccm.server.handlers.db.ISqlWrapper;
import com.baomidou.mybatisplus.annotation.DbType;

public abstract class SqlWrapper implements ISqlWrapper {
    @Override
    public abstract DbType getDbType();

    @Override
    public int getOrder() {
        return 0;
    }

    @Override
    public String getTableAlias() {
        return "t";
    }

    @Override
    public String getTableNameAlias(int index) {
        return "%" + this.getTableAlias() + index + "%";
    }

    @Override
    public String getIndexSql(tableSuffix tableSuffix) {
        return "";
    }

    @Override
    public String getTableNamePlaceHolder() {
        return "%" + this.getTableAlias()+"%";
    }

    @Override
    public String getRetrieveTablesSql(String... params) {
        return "";
    }

    public abstract String getRetrieveTablesSql(String table);

    @Override
    public String getCreateTableSql(tableSuffix tableSuffix) {
        return "";
    }

    @Override
    public String getDropTableSql(tableSuffix tableSuffix) {
        return "";
    }

    @Override
    public String getAlterColumnSql(CRUD crud) {
        return "";
    }

    @Override
    public String getColumnsUnderTableSql(String table) {
        return "";
    }

    @Override
    public String getPrimaryKeySql(tableSuffix tableSuffix) {
        return "";
    }
}
