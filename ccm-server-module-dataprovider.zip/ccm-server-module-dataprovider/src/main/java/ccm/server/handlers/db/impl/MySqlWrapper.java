package ccm.server.handlers.db.impl;

import ccm.server.enums.tableSuffix;
import ccm.server.handlers.db.IMySqlWrapper;
import com.baomidou.mybatisplus.annotation.DbType;
import org.springframework.stereotype.Service;

@Service
public class MySqlWrapper extends SqlWrapper implements IMySqlWrapper {
    @Override
    public String getIndexSql1(tableSuffix tableSuffix) {
        return null;
    }

    @Override
    public DbType getDbType() {
        return DbType.MYSQL;
    }

    @Override
    public String getRetrieveTablesSql(String... params) {
        if (params != null && params.length > 0) {
            return "select table_name from information_schema.tables where table_schema='" + params[0] + "' and table_name='" + params[1] + "';";
        }
        return "select table_schema,table_name from information_schema.tables;";
    }

    /**
     * @param table
     * @return
     */
    @Override
    public String getRetrieveTablesSql(String table) {
        return null;
    }

    @Override
    public String getDropTableSql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            StringBuilder stringBuilder = new StringBuilder();
            String pattern = "";
            String table = this.getTableNamePlaceHolder();
            switch (tableSuffix) {
                case OBJPR:
                case OBJPRDETAILS:
                case OBJREL:
                case OBJIF:
                case OBJ:
                    pattern = "drop table " + table + tableSuffix;
                    break;
                default:
                    return super.getDropTableSql(tableSuffix);
            }
            stringBuilder.append(pattern);
            return stringBuilder.toString();
        }
        return super.getDropTableSql(null);
    }

    @Override
    public String getCreateTableSql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            String table = this.getTableNamePlaceHolder();
            StringBuilder stringBuilder = new StringBuilder();
            String pattern = "";
            switch (tableSuffix) {
                case OBJ:
                    pattern = "CREATE TABLE " + table + "OBJ (" +
                            "NAME varchar(128) CHARACTER SET utf8mb4 NOT NULL," +
                            "OBID varchar(32) NOT NULL," +
                            "OBJ_UID varchar(128) CHARACTER SET utf8mb4 NOT NULL," +
                            "DESCRIPTION varchar(512) CHARACTER SET utf8mb4 NULL," +
                            "CONFIG varchar(128) CHARACTER SET utf8mb4 NULL," +
                            "CLASS_DEFINITION_UID varchar(48) NOT NULL," +
                            "DOMAIN_UID varchar(30) NOT NULL," +
                            "UNIQUE_KEY varchar(256) CHARACTER SET utf8mb4 NULL," +
                            "LAST_UPDATE_DATE datetime NULL," +
                            "LAST_UPDATE_USER varchar(32) NULL," +
                            "CREATION_USER varchar(64) CHARACTER SET utf8mb4 DEFAULT 'internal user'  NOT NULL," +
                            "CREATION_DATE datetime DEFAULT '1990-01-01 00:00:00' NOT NULL," +
                            "TERMINATION_USER varchar(32) CHARACTER SET utf8mb4 NULL DEFAULT ''," +
                            "TERMINATION_DATE datetime NULL DEFAULT '9999-12-31 00:00:00');";
                    break;
                case OBJIF:
                    pattern = "CREATE TABLE " + table + "OBJIF(" +
                            "OBID varchar(32) NOT NULL," +
                            "OBJ_OBID varchar(64) CHARACTER SET utf8mb4 NOT NULL," +
                            "INTERFACE_DEF_UID varchar(128) NOT NULL," +
                            "CREATION_DATE datetime DEFAULT '1990-01-01 00:00:00' NOT NULL," +
                            "CREATION_USER varchar(128) CHARACTER SET utf8mb4 DEFAULT 'internal user' NOT NULL," +
                            "TERMINATION_DATE datetime NULL DEFAULT '9999-12-31 00:00:00'," +
                            "TERMINATION_USER varchar(128) CHARACTER SET utf8mb4 NULL DEFAULT ''," +
                            "CONFIG varchar(128) CHARACTER SET utf8mb4 NULL);";
                    break;
                case OBJPR:
                    pattern = "CREATE TABLE " + table + "OBJPR(" +
                            "OBID varchar(32) NOT NULL," +
                            "PROPERTY_DEF_UID varchar(128) NOT NULL," +
                            "OBJ_OBID varchar(64) NOT NULL," +
                            "STR_VALUE text NULL," +
                            "UOM varchar(128) CHARACTER SET utf8mb4 NULL," +
                            "CREATION_USER varchar(128) CHARACTER SET utf8mb4 DEFAULT 'internal user' NOT NULL," +
                            "CREATION_DATE datetime DEFAULT '1990-01-01 00:00:00' NOT NULL," +
                            "TERMINATION_USER varchar(128) CHARACTER SET utf8mb4 NULL DEFAULT ''," +
                            "TERMINATION_DATE datetime NULL DEFAULT '9999-12-31 00:00:00'," +
                            "CONFIG varchar(128) CHARACTER SET utf8mb4 NULL," +
                            "INTERFACE_OBID varchar(64) NOT NULL," +
                            "INTERFACE_DEF_UID varchar(128) NOT NULL);";
                    break;
                case OBJREL:
                    pattern = "CREATE TABLE " + table + "OBJREL(" +
                            "OBID varchar(32) NOT NULL," +
                            "OBJ_UID varchar(512) CHARACTER SET utf8mb4 NOT NULL," +
                            "UID1 varchar(128) CHARACTER SET utf8mb4 NULL," +
                            "REL_DEF_UID varchar(48) NOT NULL," +
                            "UID2 varchar(128) CHARACTER SET utf8mb4 NOT NULL," +
                            "DOMAIN_UID1 varchar(30) CHARACTER SET utf8mb4 NOT NULL," +
                            "DOMAIN_UID2 varchar(30) CHARACTER SET utf8mb4 NOT NULL," +
                            "NAME1 varchar(128) CHARACTER SET utf8mb4 NULL," +
                            "NAME2 varchar(128) CHARACTER SET utf8mb4 NULL," +
                            "CREATION_DATE datetime DEFAULT '1990-01-01 00:00:00' NOT NULL," +
                            "CREATION_USER varchar(16) CHARACTER SET utf8mb4 DEFAULT 'internal user' NOT NULL," +
                            "TERMINATION_DATE datetime NULL DEFAULT '9999-12-31 00:00:00'," +
                            "TERMINATION_USER varchar(16) CHARACTER SET utf8mb4 NULL DEFAULT ''," +
                            "PREFIX varchar(4) CHARACTER SET utf8mb4 NULL," +
                            "DOMAIN_UID varchar(30) NOT NULL," +
                            "OBID1 varchar(32) NOT NULL," +
                            "OBID2 varchar(32) NOT NULL," +
                            "IS_REQUIRED tinyint(1) NULL," +
                            "ORDER_VALUE int NULL," +
                            "CONFIG varchar(16) CHARACTER SET utf8mb4 NULL," +
                            "CLASS_DEFINITION_UID1 varchar(48) NOT NULL," +
                            "CLASS_DEFINITION_UID2 varchar(48) NOT NULL);";
                    break;
                case OBJPRDETAILS:
                    pattern = "CREATE TABLE " + table + "OBJPRDETAILS(" +
                            "OBID varchar(32) NOT NULL," +
                            "DETAILS longtext NULL," +
                            "PROPERTY_OBID varchar(64) NOT NULL," +
                            "CREATION_DATE datetime NOT NULL," +
                            "CREATION_USER varchar(64) CHARACTER SET utf8mb4 NULL," +
                            "TERMINATION_USER varchar(64) NULL DEFAULT ''," +
                            "TERMINATION_DATE datetime NULL DEFAULT '9999-12-31 00:00:00'," +
                            "CONFIG varchar(128) CHARACTER SET utf8mb4 NULL);";
                    break;
                default:
                    return super.getCreateTableSql(tableSuffix);
            }
            stringBuilder.append(pattern);
            stringBuilder.append(this.getPrimaryKeySql(tableSuffix));
            stringBuilder.append(this.getIndexSql(tableSuffix));
            stringBuilder.append(this.getIndexSql1(tableSuffix));
            return stringBuilder.toString();
        }
        return super.getCreateTableSql(null);
    }

    @Override
    public String getIndexSql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            StringBuilder stringBuilder = new StringBuilder();
            String pattern = "";
            String table = this.getTableNamePlaceHolder();
            switch (tableSuffix) {
                case OBJ:
                    pattern = "CREATE UNIQUE INDEX IDX_" + table + "OBJ_OBID_CLASSDEFUID ON " + table + "OBJ (OBID ASC,CLASS_DEFINITION_UID ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJ_UID_CLASSDEFUID ON " + table + "OBJ (OBJ_UID ASC,CLASS_DEFINITION_UID ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJ_NAME_CLASSDEFUID ON " + table + "OBJ (NAME ASC,CLASS_DEFINITION_UID ASC);" +
                            "CREATE UNIQUE INDEX IDX_" + table + "OBJ_UID ON " + table + "OBJ (OBJ_UID ASC,DOMAIN_UID ASC,TERMINATION_USER ASC,TERMINATION_DATE ASC);";
                    break;
                case OBJIF:
                    pattern = "CREATE UNIQUE INDEX IDX_" + table + "OBJIF_INTERFACE ON " + table + "OBJIF (OBJ_OBID ASC,INTERFACE_DEF_UID ASC,TERMINATION_USER ASC,TERMINATION_DATE ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJIF_OBJOBID ON " + table + "OBJIF (OBJ_OBID ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJIF_OBJOBID_INTERFACEDEFUID ON " + table + "OBJIF (OBJ_OBID ASC,INTERFACE_DEF_UID ASC);";
                    break;
                case OBJREL:
                    pattern = "CREATE INDEX IDX_" + table + "OBJREL_END1FOREXPANSION ON " + table + "OBJREL (REL_DEF_UID ASC," +
                            "OBID1 ASC," +
                            "NAME1 ASC," +
                            "CLASS_DEFINITION_UID1 ASC," +
                            "CREATION_USER ASC," +
                            "TERMINATION_USER ASC," +
                            "IS_REQUIRED ASC," +
                            "ORDER_VALUE ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJREL_END1FORQUERY ON " + table + "OBJREL (UID1 ASC, REL_DEF_UID ASC, NAME1 ASC, OBID1 ASC, CLASS_DEFINITION_UID1 ASC, DOMAIN_UID1 ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJREL_END2FOREXPANSION ON " + table + "OBJREL (REL_DEF_UID ASC," +
                            "OBID2 ASC," +
                            "NAME2 ASC," +
                            "CLASS_DEFINITION_UID2 ASC," +
                            "CREATION_USER ASC," +
                            "TERMINATION_USER ASC," +
                            "IS_REQUIRED ASC," +
                            "ORDER_VALUE ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJREL_END2FORQUERY ON " + table + "OBJREL (UID2 ASC, REL_DEF_UID ASC, NAME2 ASC, OBID2 ASC, CLASS_DEFINITION_UID2 ASC, DOMAIN_UID2 ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJREL_OBID1FORADQUERY ON " + table + "OBJREL (OBID1 ASC);" +
                            "CREATE INDEX IDX_" + table + "OBJREL_OBID2FORADQUERY ON " + table + "OBJREL (OBID2 ASC);" +
                            "CREATE UNIQUE INDEX IDX_" + table + "OBJREL_RELATIONSHIP ON " + table + "OBJREL (" +
                            "UID1 ASC," +
                            "REL_DEF_UID ASC," +
                            "UID2 ASC," +
                            "DOMAIN_UID1 ASC," +
                            "DOMAIN_UID2 ASC," +
                            "TERMINATION_DATE ASC," +
                            "TERMINATION_USER ASC," +
                            "PREFIX ASC," +
                            "OBID1 ASC," +
                            "OBID2 ASC," +
                            "CLASS_DEFINITION_UID1 ASC," +
                            "CLASS_DEFINITION_UID2 ASC " +
                            ");";
                    break;
                case OBJPRDETAILS:
                    break;
                case OBJPR:
                    pattern = "CREATE INDEX IDX_" + table + "PR_IOBID ON " + table + "OBJPR (INTERFACE_OBID ASC);" +
                            "CREATE INDEX IDX_" + table + "PR_IOBID_OOBID ON " + table + "OBJPR (INTERFACE_OBID ASC,OBJ_OBID ASC);" +
                            "CREATE INDEX IDX_" + table + "PR_OOBID_PUID_STR ON " + table + "OBJPR (OBJ_OBID ASC,PROPERTY_DEF_UID ASC);" +
                            "CREATE UNIQUE INDEX IDX_" + table + "PR_P ON " + table + "OBJPR (OBJ_OBID ASC,INTERFACE_DEF_UID ASC,PROPERTY_DEF_UID ASC,TERMINATION_USER ASC,TERMINATION_DATE ASC);" +
                            "CREATE INDEX IDX_" + table + "PR_PUID ON " + table + "OBJPR (PROPERTY_DEF_UID);";
                    break;
                default:
                    return super.getIndexSql(tableSuffix);
            }
            stringBuilder.append(pattern);
            return stringBuilder.toString();
        }
        return super.getIndexSql(null);
    }

    @Override
    public String getPrimaryKeySql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            String table = this.getTableNamePlaceHolder();
            String pattern = "";
            StringBuilder stringBuilder = new StringBuilder();
            switch (tableSuffix) {
                case OBJ:
                case OBJPR:
                case OBJIF:
                case OBJREL:
                case OBJPRDETAILS:
                    pattern = "ALTER TABLE " + table + tableSuffix + " ADD PRIMARY KEY (OBID);";
                    break;
                default:
                    break;
            }
            stringBuilder.append(pattern);
            return stringBuilder.toString();
        }
        return super.getPrimaryKeySql(null);
    }
}
