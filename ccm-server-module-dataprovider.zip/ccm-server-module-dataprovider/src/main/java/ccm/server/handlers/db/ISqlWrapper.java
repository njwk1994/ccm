package ccm.server.handlers.db;

import ccm.server.enums.CRUD;
import ccm.server.enums.tableSuffix;
import com.baomidou.mybatisplus.annotation.DbType;

public interface ISqlWrapper {
    DbType getDbType();

    String getTableAlias();

    int getOrder();

    String getTableNameAlias(int index);

    String getIndexSql(tableSuffix tableSuffix);

    String getIndexSql1(tableSuffix tableSuffix);

    String getTableNamePlaceHolder();

    String getRetrieveTablesSql(String... params);

    String getCreateTableSql(tableSuffix tableSuffix);

    String getDropTableSql(tableSuffix tableSuffix);

    String getAlterColumnSql(CRUD crud);

    String getColumnsUnderTableSql(String table);

    String getPrimaryKeySql(tableSuffix tableSuffix);
}
