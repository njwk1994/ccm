package ccm.server.handlers.db.impl;

import ccm.server.enums.CRUD;
import ccm.server.enums.tableSuffix;
import ccm.server.handlers.db.ISqlServerSqlWrapper;
import com.baomidou.mybatisplus.annotation.DbType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class SqlServerSqlWrapper extends SqlWrapper implements ISqlServerSqlWrapper {
    @Override
    public DbType getDbType() {
        return DbType.SQL_SERVER;
    }

    @Override
    public int getOrder() {
        return 0;
    }

    /**
     * @param params
     * @return
     */
    @Override
    public String getRetrieveTablesSql(String... params) {
        if (params != null && params.length > 0) {
            return "select name from sysobjects where id = object_id('" + params[1] + "') and OBJECTPROPERTY(id, N'IsUserTable') = 1;";
        }
        return "select name from sysobjects where OBJECTPROPERTY(id, N'IsUserTable') = 1;";
    }

    @Override
    public String getIndexSql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            StringBuilder stringBuilder = new StringBuilder();
            String pattern = "";
            String table = this.getTableNamePlaceHolder();
            switch (tableSuffix) {
                case OBJ:
                    pattern = "CREATE UNIQUE NONCLUSTERED INDEX [IDX_" + table + "OBJ_OBID_CLASSDEFUID] ON [dbo].[" + table + "OBJ] ([OBID] ASC,[CLASS_DEFINITION_UID] ASC) INCLUDE ([NAME],[OBJ_UID],[DESCRIPTION],[CONFIG],[DOMAIN_UID],[UNIQUE_KEY],[LAST_UPDATE_DATE],[LAST_UPDATE_USER],[CREATION_USER],[CREATION_DATE],[TERMINATION_USER],[TERMINATION_DATE]);" +
                            "CREATE  NONCLUSTERED INDEX [IDX_" + table + "OBJ_UID_CLASSDEFUID] ON [dbo].[" + table + "OBJ] ([OBJ_UID] ASC,[CLASS_DEFINITION_UID] ASC) INCLUDE ([NAME],[OBID],[DESCRIPTION],[CONFIG],[DOMAIN_UID],[UNIQUE_KEY],[LAST_UPDATE_DATE],[LAST_UPDATE_USER],[CREATION_USER],[CREATION_DATE],[TERMINATION_USER],[TERMINATION_DATE]);" +
                            "CREATE  NONCLUSTERED INDEX [IDX_" + table + "OBJ_NAME_CLASSDEFUID] ON [dbo].[" + table + "OBJ] ([NAME] ASC,[CLASS_DEFINITION_UID] ASC) INCLUDE ([OBJ_UID],[OBID],[DESCRIPTION],[CONFIG],[DOMAIN_UID],[UNIQUE_KEY],[LAST_UPDATE_DATE],[LAST_UPDATE_USER],[CREATION_USER],[CREATION_DATE],[TERMINATION_USER],[TERMINATION_DATE]);" +
                            "CREATE UNIQUE NONCLUSTERED INDEX [IDX_" + table + "OBJ_UID] ON [dbo].[" + table + "OBJ] ([OBJ_UID] ASC,[DOMAIN_UID] ASC,[TERMINATION_USER] ASC,[TERMINATION_DATE] ASC);";
                    break;
                case OBJIF:
                    pattern = "CREATE UNIQUE NONCLUSTERED INDEX [IDX_" + table + "OBJIF_INTERFACE] ON [dbo].[" + table + "OBJIF] ([OBJ_OBID] ASC,[INTERFACE_DEF_UID] ASC,[TERMINATION_USER] ASC,[TERMINATION_DATE] ASC);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJIF_OBJOBID] ON [dbo].[" + table + "OBJIF] ([OBJ_OBID] ASC)INCLUDE([OBID],[INTERFACE_DEF_UID],[CREATION_DATE],[CREATION_USER],[TERMINATION_DATE],[TERMINATION_USER]);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJIF_OBJOBID_INTERFACEDEFUID] ON [dbo].[" + table + "OBJIF] ([OBJ_OBID] ASC,[INTERFACE_DEF_UID] ASC);";
                    break;
                case OBJREL:
                    pattern = "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJREL_END1FOREXPANSION] ON [dbo].[" + table + "OBJREL] ([REL_DEF_UID] ASC,[OBID1] ASC,[OBID] ASC,[OBJ_UID] ASC,[UID1] ASC,[UID2] ASC,[DOMAIN_UID1] ASC,[DOMAIN_UID2] ASC,[NAME1] ASC,[NAME2] ASC,[CREATION_DATE] ASC,[CREATION_USER] ASC,[TERMINATION_DATE] ASC,[TERMINATION_USER] ASC,[PREFIX] ASC,[DOMAIN_UID] ASC,[OBID2] ASC,[IS_REQUIRED] ASC,[ORDER_VALUE] ASC,[CONFIG] ASC,[CLASS_DEFINITION_UID1] ASC,[CLASS_DEFINITION_UID2] ASC);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJREL_END1FORQUERY] ON [dbo].[" + table + "OBJREL] ([UID1] ASC,[REL_DEF_UID] ASC,[NAME1] ASC,[OBID1] ASC,[CLASS_DEFINITION_UID1] ASC,[DOMAIN_UID1] ASC)INCLUDE([OBID],[OBJ_UID],[UID2],[DOMAIN_UID2],[NAME2],[CREATION_DATE],[CREATION_USER],[TERMINATION_DATE],[TERMINATION_USER],[PREFIX],[DOMAIN_UID],[OBID2],[IS_REQUIRED],[ORDER_VALUE],[CONFIG],[CLASS_DEFINITION_UID2]);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJREL_END2FOREXPANSION] ON [dbo].[" + table + "OBJREL] ([REL_DEF_UID] ASC,[OBID2] ASC)INCLUDE([OBID],[OBJ_UID],[UID1],[UID2],[DOMAIN_UID1],[DOMAIN_UID2],[NAME1],[NAME2],[CREATION_DATE],[CREATION_USER],[TERMINATION_DATE],[TERMINATION_USER],[PREFIX],[DOMAIN_UID],[OBID1],[IS_REQUIRED],[ORDER_VALUE],[CONFIG],[CLASS_DEFINITION_UID1],[CLASS_DEFINITION_UID2]);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJREL_END2FORQUERY] ON [dbo].[" + table + "OBJREL] ([REL_DEF_UID] ASC,[UID2] ASC,[DOMAIN_UID2] ASC,[NAME2] ASC,[CLASS_DEFINITION_UID2] ASC,[OBID] ASC,[OBJ_UID] ASC,[UID1] ASC,[DOMAIN_UID1] ASC,[NAME1] ASC,[CREATION_DATE] ASC,[CREATION_USER] ASC,[TERMINATION_DATE] ASC,[TERMINATION_USER] ASC,[PREFIX] ASC,[DOMAIN_UID] ASC,[OBID1] ASC,[OBID2] ASC,[IS_REQUIRED] ASC,[ORDER_VALUE] ASC,[CONFIG] ASC,[CLASS_DEFINITION_UID1] ASC);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJREL_OBID1FORADQUERY] ON [dbo].[" + table + "OBJREL] ([OBID1] ASC);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJREL_OBID2FORADQUERY] ON [dbo].[" + table + "OBJREL] ([OBID2] ASC);" +
                            "CREATE UNIQUE NONCLUSTERED INDEX [IDX_" + table + "OBJREL_RELATIONSHIP] ON [dbo].[" + table + "OBJREL] ([UID1] ASC,[REL_DEF_UID] ASC,[UID2] ASC,[DOMAIN_UID1] ASC,[DOMAIN_UID2] ASC,[TERMINATION_DATE] ASC,[TERMINATION_USER] ASC,[PREFIX] ASC,[OBID1] ASC,[OBID2] ASC,[CLASS_DEFINITION_UID1] ASC,[CLASS_DEFINITION_UID2] ASC);";
                    break;
                case OBJPRDETAILS:
                    break;
                case OBJPR:
                    pattern = "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_INTERFACEOBID] ON [dbo].[" + table + "OBJPR] ([INTERFACE_OBID] ASC)INCLUDE([OBID],[PROPERTY_DEF_UID],[OBJ_OBID],[STR_VALUE],[UOM],[CREATION_USER],[CREATION_DATE],[TERMINATION_USER],[TERMINATION_DATE],[INTERFACE_DEF_UID]);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_INTERFACEOBID_OBJOBID] ON [dbo].[" + table + "OBJPR] ([INTERFACE_OBID] ASC,[OBJ_OBID] ASC)INCLUDE([OBID],[PROPERTY_DEF_UID],[STR_VALUE],[UOM],[CREATION_USER],[CREATION_DATE],[TERMINATION_USER],[TERMINATION_DATE],[INTERFACE_DEF_UID]);" +
                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_OBJOBID_PROPERTYDEFUID_STRVALUE] ON [dbo].[" + table + "OBJPR] ([OBJ_OBID] ASC,[PROPERTY_DEF_UID] ASC)INCLUDE([STR_VALUE]);" +
                            "CREATE UNIQUE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_PROPERTY] ON [dbo].[" + table + "OBJPR] ([OBJ_OBID] ASC,[INTERFACE_DEF_UID] ASC,[PROPERTY_DEF_UID] ASC,[TERMINATION_USER] ASC,[TERMINATION_DATE] ASC);" +
                                "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_PROPERTYDEFUID] ON [dbo].[" + table + "OBJPR] ([PROPERTY_DEF_UID]) INCLUDE ([OBJ_OBID],[STR_VALUE]);";
                    break;
                default:
                    return super.getIndexSql(tableSuffix);
            }
            stringBuilder.append(pattern);
            return stringBuilder.toString();
        }
        return super.getIndexSql(null);
    }

    @Override
    public String getIndexSql1(tableSuffix tableSuffix) {
//        if (tableSuffix != null) {
//            StringBuilder stringBuilder = new StringBuilder();
//            String pattern = "";
//            String table = this.getTableNamePlaceHolder();
//            switch (tableSuffix) {
//                case OBJIF:
//                    pattern = "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJIF_OBJOBID] ON [dbo].[" + table + "OBJIF] ([OBJ_OBID]);";
//                    break;
//                case OBJPR:
//                    pattern =
//                            "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_OBJOBID] ON [dbo].[" + table + "OBJPR] ([OBJ_OBID]);" +
//                                    "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_INTERFACEOBID] ON [dbo].[" + table + "OBJPR] ([INTERFACE_OBID]);" +
//                                    "CREATE NONCLUSTERED INDEX [IDX_" + table + "OBJPR_PROPERTYDEFUID] ON [dbo].[" + table + "OBJPR] ([PROPERTY_DEF_UID]) INCLUDE ([OBJ_OBID],[STR_VALUE]);";
//                    ;
//                    break;
//                default:
//                    break;
//            }
//            stringBuilder.append(pattern);
//            return stringBuilder.toString();
//        }
        return super.getIndexSql(null);
    }

    @Override
    public String getTableNamePlaceHolder() {
        return super.getTableNamePlaceHolder();
    }

    @Override
    public String getRetrieveTablesSql(String table) {
        if (!StringUtils.isEmpty(table))
            return "SELECT name,object_id,type,type_desc,create_date,modify_date FROM sys.all_objects WHERE type IN ('U') and object_id = OBJECT_ID(N'[dbo].[" + table + "]') ";
        return "SELECT name,object_id,type,type_desc,create_date,modify_date FROM sys.all_objects WHERE type IN ('U')";
    }

    @Override
    public String getCreateTableSql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            String table = this.getTableNamePlaceHolder();
            StringBuilder stringBuilder = new StringBuilder();
            String pattern = "";
            switch (tableSuffix) {
                case OBJ:
                    pattern = "CREATE TABLE [dbo].[" + table + "OBJ]([NAME] [nvarchar](128) NOT NULL," +
                            "[OBID] [varchar](64) NOT NULL," +
                            "[OBJ_UID] [nvarchar](128) NOT NULL," +
                            "[DESCRIPTION] [nvarchar](512) NULL," +
                            "[CONFIG] [nvarchar](128) NULL," +
                            "[CLASS_DEFINITION_UID] [varchar](128) NOT NULL," +
                            "[DOMAIN_UID] [nvarchar](64) NOT NULL," +
                            "[UNIQUE_KEY] [nvarchar](256) NULL," +
                            "[LAST_UPDATE_DATE] [datetime] NULL," +
                            "[LAST_UPDATE_USER] [varchar](32) NULL," +
                            "[CREATION_USER] [varchar](64) DEFAULT 'internal user' NOT NULL," +
                            "[CREATION_DATE] [datetime] DEFAULT '1990-01-01 00:00:00.000' NOT NULL," +
                            "[TERMINATION_USER] [varchar](32) NULL," +
                            "[TERMINATION_DATE] [date] NULL);";
                    break;
                case OBJIF:
                    pattern = "CREATE TABLE [dbo].[" + table + "OBJIF](" +
                            "[OBID] [varchar](64) NOT NULL," +
                            "[OBJ_OBID] [varchar](64) NOT NULL," +
                            "[INTERFACE_DEF_UID] [varchar](128) NOT NULL," +
                            "[CREATION_DATE] [datetime] DEFAULT '1990-01-01 00:00:00.000' NOT NULL," +
                            "[CREATION_USER] [varchar](128) DEFAULT 'internal user' NOT NULL," +
                            "[TERMINATION_DATE] [datetime] NULL," +
                            "[TERMINATION_USER] [varchar](128) NULL," +
                            "[CONFIG] [nvarchar](128) NULL);";
                    break;
                case OBJPR:
                    pattern = "CREATE TABLE [dbo].[" + table + "OBJPR](" +
                            "[OBID] [varchar](64) NOT NULL," +
                            "[PROPERTY_DEF_UID] [varchar](128) NOT NULL," +
                            "[OBJ_OBID] [varchar](64) NOT NULL," +
                            "[STR_VALUE] [nvarchar](max) NULL," +
                            "[UOM] [nvarchar](128) NULL," +
                            "[CREATION_USER] [varchar](128) DEFAULT 'internal user' NOT NULL," +
                            "[CREATION_DATE] [datetime] DEFAULT '1990-01-01 00:00:00.000' NOT NULL," +
                            "[TERMINATION_USER] [varchar](128) NULL," +
                            "[TERMINATION_DATE] [datetime] NULL," +
                            "[CONFIG] [nvarchar](128) NULL," +
                            "[INTERFACE_OBID] [varchar](64) NOT NULL," +
                            "[INTERFACE_DEF_UID] [varchar](128) NOT NULL);";
                    break;
                case OBJREL:
                    pattern = "CREATE TABLE [dbo].[" + table + "OBJREL](" +
                            "[OBID] [varchar](512) NOT NULL," +
                            "[OBJ_UID] [nvarchar](1024) NOT NULL," +
                            "[UID1] [nvarchar](512) NOT NULL," +
                            "[REL_DEF_UID] [varchar](64) NOT NULL," +
                            "[UID2] [nvarchar](512) NOT NULL," +
                            "[DOMAIN_UID1] [nvarchar](64) NOT NULL," +
                            "[DOMAIN_UID2] [nvarchar](64) NOT NULL," +
                            "[NAME1] [nvarchar](256) NULL," +
                            "[NAME2] [nvarchar](256) NULL," +
                            "[CREATION_DATE] [datetime] DEFAULT '1990-01-01 00:00:00.000' NOT NULL," +
                            "[CREATION_USER] [varchar](32) DEFAULT 'internal user' NOT NULL," +
                            "[TERMINATION_DATE] [datetime] NULL," +
                            "[TERMINATION_USER] [varchar](32) NULL," +
                            "[PREFIX] [nvarchar](16) NULL," +
                            "[DOMAIN_UID] [nvarchar](64) NOT NULL," +
                            "[OBID1] [varchar](32) NOT NULL," +
                            "[OBID2] [varchar](32) NOT NULL," +
                            "[IS_REQUIRED] [bit] NULL," +
                            "[ORDER_VALUE] [int] NULL," +
                            "[CONFIG] [nvarchar](128) NULL," +
                            "[CLASS_DEFINITION_UID1] [varchar](64) NOT NULL," +
                            "[CLASS_DEFINITION_UID2] [varchar](64) NOT NULL);";
                    break;
                case OBJPRDETAILS:
                    pattern = "CREATE TABLE [dbo].[" + table + "OBJPRDETAILS](" +
                            "[OBID] [varchar](64) NOT NULL," +
                            "[DETAILS] [nvarchar](max) NULL," +
                            "[PROPERTY_OBID] [varchar](64) NOT NULL," +
                            "[CREATION_DATE] [date] NOT NULL," +
                            "[CREATION_USER] [varchar](64) NULL," +
                            "[TERMINATION_USER] [varchar](64) NULL," +
                            "[TERMINATION_DATE] [date] NULL," +
                            "[CONFIG] [nvarchar](128) NULL);";
                    break;
                default:
                    return super.getCreateTableSql(tableSuffix);
            }
            stringBuilder.append(pattern);
            stringBuilder.append(this.getPrimaryKeySql(tableSuffix));
            stringBuilder.append(this.getIndexSql(tableSuffix));
            stringBuilder.append(this.getIndexSql1(tableSuffix));
            return stringBuilder.toString();
        }
        return super.getCreateTableSql(null);
    }

    @Override
    public String getDropTableSql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            StringBuilder stringBuilder = new StringBuilder();
            String pattern = "";
            String table = this.getTableNamePlaceHolder();
            switch (tableSuffix) {
                case OBJPR:
                case OBJPRDETAILS:
                case OBJREL:
                case OBJIF:
                case OBJ:
                    pattern = "drop table [dbo].[" + table + tableSuffix.toString() + "]";
                    break;
                default:
                    return super.getDropTableSql(tableSuffix);
            }
            stringBuilder.append(pattern);
            return stringBuilder.toString();
        }
        return super.getDropTableSql(null);
    }

    @Override
    public String getAlterColumnSql(CRUD crud) {
        if (crud != null) {
            String table = this.getTableNamePlaceHolder();
            String pattern = "";
            StringBuilder stringBuilder = new StringBuilder();
            switch (crud) {
                case C:
                    pattern = "alter table " + table + " add " + this.getTableNameAlias(1) + " " + this.getTableNameAlias(2) + " " + this.getTableNameAlias(3) + ";";
                    break;
                case D:
                case T:
                    pattern = "alter table " + table + " drop column " + this.getTableNameAlias(1) + ";";
                    break;
                case U:
                    pattern = "alter table " + table + " alter column " + this.getTableNameAlias(1) + " " + this.getTableNameAlias(2) + " " + this.getTableNameAlias(3) + ";";
                    break;
                default:
                    break;
            }
            stringBuilder.append(pattern);
            return stringBuilder.toString();
        }
        return super.getAlterColumnSql(null);
    }

    @Override
    public String getPrimaryKeySql(tableSuffix tableSuffix) {
        if (tableSuffix != null) {
            String table = this.getTableNamePlaceHolder();
            String pattern = "";
            StringBuilder stringBuilder = new StringBuilder();
            switch (tableSuffix) {
                case OBJ:
                case OBJPR:
                case OBJIF:
                case OBJREL:
                case OBJPRDETAILS:
                    pattern = "ALTER TABLE [dbo].[" + table + tableSuffix + "] ADD PRIMARY KEY CLUSTERED ([OBID]);";
                    break;
                default:
                    break;
            }
            stringBuilder.append(pattern);
            return stringBuilder.toString();
        }
        return super.getPrimaryKeySql(null);
    }

    @Override
    public String getColumnsUnderTableSql(String table) {
        if (!StringUtils.isEmpty(table)) {
            return "select " +
                    "TB.[Name] As table_id," +
                    "TC.[name] As field_name," +
                    "convert(int,TC.[colorder]) As sort_index," +
                    "(Case When TK.TABLE_NAME Is not Null Then 'Y' Else 'N' End) As is_key, " +
                    "(Case When TK.TABLE_NAME Is not Null Then (Case When COLUMNPROPERTY( TC.id,TC.name,'IsIdentity')=1 Then 'Identity' Else 'Customer' END) Else null End) As key_rule," +
                    "T0.name field_type," +
                    "(Case When TC.length > 0 and T0.name in ('NVhar','NVarChar') Then TC.length / 2 When T0.name='ntext' Then '2147483646'else TC.length end) Length, (Case TC.[isnullable] When 0 Then 'Y' Else 'N' End) As NotNull, " +
                    "SUBSTRING(TM.text,3 , len(TM.text)-4) As default_value," +
                    "TE.value AS field_desc" +
                    "from sys.sysobjects TB" +
                    "left join sys.syscolumns TC on TB.id = TC.id" +
                    "left join sys.systypes T0 on TC.xtype = T0.XUserType" +
                    "left join INFORMATION_SCHEMA.KEY_COLUMN_USAGE TK on TB.[name]= TK.TABLE_NAME and TK.COLUMN_NAME = TC.[name]" +
                    "left join sys.syscomments TM on TC.cdefault=TM.id " +
                    "left join sys.extended_properties TE on  TC.id=TE.major_id and TC.colid=TE.minor_id     " +
                    "where TB.[Name] = '" + table + "'" +
                    "order by TC.id,TC.colorder";
        }
        return super.getColumnsUnderTableSql(table);
    }
}
