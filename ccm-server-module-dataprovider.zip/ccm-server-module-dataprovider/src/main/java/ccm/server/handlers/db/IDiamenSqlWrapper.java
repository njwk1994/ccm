package ccm.server.handlers.db;

public interface IDiamenSqlWrapper {
}
