package ccm.server.handlers;

import ccm.server.enums.domainInfo;
import ccm.server.util.ISharedCommon;
import com.baomidou.mybatisplus.extension.plugins.handler.TableNameHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class ConfigurationPlusDomainTableNameParser implements TableNameHandler {

    public final List<String> effectiveTables;

    public final static ThreadLocal<String> localSuffix = new ThreadLocal<>();

    public final static ThreadLocal<String> localPrefix = new ThreadLocal<>();

    public static void reset() {
        localSuffix.remove();
        localPrefix.remove();
    }

    public static void setConfigurationAndDomainGroupAlias(String configuration, String domainGroup) {
        reset();
        localPrefix.set(configuration);
        localSuffix.set(domainGroup);
    }

    public static void setTablePrefix(String tablePrefix) {
        if (!StringUtils.isEmpty(tablePrefix)) {
            reset();
            String[] strings = tablePrefix.split(ISharedCommon.COMMON_CONNECTOR);
            if (strings.length == 1) {
                localPrefix.set(null);
                localSuffix.set(strings[0]);
            } else {
                localPrefix.set(strings[0]);
                localSuffix.set(strings[1]);
            }
        }
    }

    public ConfigurationPlusDomainTableNameParser(String configurationPrefix, String domainSuffix) {
        reset();
        localPrefix.set(configurationPrefix);
        localSuffix.set(domainSuffix);
        this.effectiveTables = new ArrayList<String>() {{
            add("OBJ");
            add("OBJIF");
            add("OBJPR");
            add("OBJPRDETAILS");
            add("OBJREL");
        }};
    }

    /**
     * 生成动态表名
     *
     * @param sql       当前执行 SQL
     * @param tableName 表名
     * @return String
     */
    @Override
    public String dynamicTableName(String sql, String tableName) {
        log.trace("execution sql before change table:" + sql);
        if (this.effectiveTables.contains(tableName)) {
            String prefix = localPrefix.get();
            String suffix = localSuffix.get();
            List<String> collection = new ArrayList<>();
            collection.add(prefix);
            collection.add(suffix);
            collection.add(tableName);
            return collection.stream().filter(c -> !StringUtils.isEmpty(c)).collect(Collectors.joining(""));
        }
        return tableName;
    }
}
