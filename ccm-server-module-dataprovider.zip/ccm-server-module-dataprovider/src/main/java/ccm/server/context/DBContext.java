package ccm.server.context;

import ccm.server.business.IDataProviderService;
import ccm.server.business.ISchemaProviderService;
import ccm.server.entity.*;
import ccm.server.enums.*;
import ccm.server.models.LiteObject;
import ccm.server.models.LiteObjectCollection;
import ccm.server.models.page.PageResult;
import ccm.server.models.query.ExpansionWrapper;
import ccm.server.models.query.QueryRequest;
import ccm.server.processors.ProgressLatch;
import ccm.server.service.impl.MetaDataServiceImpl;
import ccm.server.shared.ISharedCacheService;
import ccm.server.shared.ISharedLocalService;
import ccm.server.util.CommonUtility;
import ccm.server.util.ISharedCommon;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service("dBContext")
@Slf4j
public class DBContext {
    public static DBContext Instance;
    @Autowired
    private ISharedCacheService sharedCacheService;
    @Autowired
    private ISharedLocalService sharedLocalService;
    @Autowired
    private IDataProviderService dataProviderService;
    @Autowired
    private ISchemaProviderService schemaProviderService;

    public void commit(Map<String, LiteObjectCollection> liteObjectCollectionMap) throws Exception {
        if (liteObjectCollectionMap != null && liteObjectCollectionMap.size() > 0) {
            LiteObjectCollection liteObjectCollection = new LiteObjectCollection(null);
            for (Map.Entry<String, LiteObjectCollection> collectionEntry : liteObjectCollectionMap.entrySet()) {
                liteObjectCollection.add(collectionEntry.getValue());
            }
            if (liteObjectCollection.size() > 0) {
                this.commit(liteObjectCollection);
            }
        }
    }

    public void commit(LiteObjectCollection liteObjectCollection) throws Exception {
        if (liteObjectCollection != null && liteObjectCollection.size() > 0) {
            List<MetaDataObj> objectsToCommit = new ArrayList<>();
            List<MetaDataObjInterface> interfacesToCommit = new ArrayList<>();
            List<MetaDataObjProperty> propertiesToCommit = new ArrayList<>();
            List<MetaDataRel> relsToCommit = new ArrayList<>();
            log.trace("********** initialized collections for OBJ/OBJIF/OBJREL/OBJPR storage **********");
            for (Map.Entry<String, LiteObject> objectEntry : liteObjectCollection.entrySet()) {
                LiteObject value = objectEntry.getValue();
                switch (value.DataType()) {
                    case data:
                        if (value.getOBJ().getUpdateState() != objectUpdateState.none)
                            objectsToCommit.add(value.getOBJ());
                        break;
                    case rel:
                        if (value.getREL().getUpdateState() != objectUpdateState.none)
                            relsToCommit.add(value.getREL());
                        break;
                }
                if (value.hasInterface()) {
                    interfacesToCommit.addAll(value.getINTERFACES());
                    if (value.getToBeTerminatedInterfaces().size() > 0) {
                        interfacesToCommit.addAll(value.getToBeTerminatedInterfaces());
                    }
                }
                if (value.hasProperty()) {
                    for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : value.getPROPERTIES().entrySet())
                        propertiesToCommit.addAll(listEntry.getValue());

                    if (value.getToBeTerminatedProperties().size() > 0)
                        propertiesToCommit.addAll(value.getToBeTerminatedProperties());
                }
                if (value.hasRel1()) {
                    for (Map.Entry<String, List<MetaDataRel>> listEntry : value.getEND1RELATIONSHIPS().entrySet()) {
                        for (MetaDataRel dataRel : listEntry.getValue()) {
                            if (dataRel.getUpdateState() != objectUpdateState.none)
                                relsToCommit.add(dataRel);
                        }
                    }
                }
                if (value.hasRel2()) {
                    for (Map.Entry<String, List<MetaDataRel>> listEntry : value.getEND2RELATIONSHIPS().entrySet()) {
                        for (MetaDataRel dataRel : listEntry.getValue()) {
                            if (dataRel.getUpdateState() != objectUpdateState.none)
                                relsToCommit.add(dataRel);
                        }
                    }
                }
            }
            this.removeDuplicateKeys(objectsToCommit, interfacesToCommit, propertiesToCommit, relsToCommit);

            log.info("********** parse details:" +
                    "object(s) count: " + objectsToCommit.size() +
                    ", total interface(s) count: " + interfacesToCommit.size() +
                    ", total property(s) count: " + propertiesToCommit.size() +
                    ", relationship(s) count: " + relsToCommit.size()
                    + "**********");

            ProgressLatch progressLatch = new ProgressLatch();
            ConcurrentHashMap<String, JobWrapper> dropJobWrappers = new ConcurrentHashMap<>();
            ConcurrentHashMap<String, JobWrapper> genJobWrappers = new ConcurrentHashMap<>();
            this.setMetaDataObjOperation(objectsToCommit, progressLatch, genJobWrappers, dropJobWrappers);
            this.setMetaDataInterfaceOperation(interfacesToCommit, progressLatch, genJobWrappers, dropJobWrappers);
            this.setMetaDataPropertyOperation(propertiesToCommit, progressLatch, genJobWrappers, dropJobWrappers);
            this.setMetaDataRelOperation(relsToCommit, progressLatch, genJobWrappers, dropJobWrappers);
            this.dataProviderService.submit(progressLatch, genJobWrappers, dropJobWrappers);
        }
    }

    protected <T extends MetaData> void doRemoveDuplication(List<T> objs) {
        if (CommonUtility.hasValue(objs)) {
            Map<String, T> mapObjs = new HashMap<>();
            for (T obj : objs) {
                String obid = obj.getObid();
                mapObjs.putIfAbsent(obid, obj);
            }
            objs.clear();
            objs.addAll(mapObjs.values());
        }
    }

    private void removeDuplicateKeys(List<MetaDataObj> objectsToCommit, List<MetaDataObjInterface> interfacesToCommit, List<MetaDataObjProperty> propertiesToCommit, List<MetaDataRel> relsToCommit) {
        this.doRemoveDuplication(objectsToCommit);
        this.doRemoveDuplication(interfacesToCommit);
        this.doRemoveDuplication(propertiesToCommit);
        this.doRemoveDuplication(relsToCommit);
    }

    protected Map<objectUpdateState, List<MetaDataRel>> toMapMetadataRelByUpdateState(List<MetaDataRel> items) {
        Map<objectUpdateState, List<MetaDataRel>> result = new HashMap<>();
        if (CommonUtility.hasValue(items)) {
            for (MetaDataRel item : items) {
                CommonUtility.doAddElementGeneral(result, item.getUpdateState(), item);
            }
        }
        return result;
    }

    protected void setMetaDataRelOperation(List<MetaDataRel> items, ProgressLatch progressLatch, ConcurrentHashMap<String, JobWrapper> genJobWrappers, ConcurrentHashMap<String, JobWrapper> dropJobWrappers) {
        if (items != null && items.size() > 0) {
            Map<String, List<MetaDataRel>> splitWithTablePrefix = MetaDataServiceImpl.splitWithTablePrefix(items);
            for (Map.Entry<String, List<MetaDataRel>> listEntry : splitWithTablePrefix.entrySet()) {
                String uniqueKey = listEntry.getKey() + ISharedCommon.COMMON_CONNECTOR + tableSuffix.OBJREL;
                Map<objectUpdateState, List<MetaDataRel>> collections = this.toMapMetadataRelByUpdateState(listEntry.getValue());
                if (collections.size() > 0) {
                    for (Map.Entry<objectUpdateState, List<MetaDataRel>> stateListEntry : collections.entrySet()) {
                        switch (stateListEntry.getKey()) {
                            case updated:
                                this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.U, stateListEntry.getValue(), progressLatch);
                                break;
                            case created:
                                this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.C, stateListEntry.getValue(), progressLatch);
                                break;
                            case terminated:
                                this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.T, stateListEntry.getValue(), progressLatch);
                                break;
                            case deleted:
                                this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.D, stateListEntry.getValue(), progressLatch);
                                break;
                        }
                    }
                }
            }
        }

    }

    protected Map<propertyValueUpdateState, List<MetaDataObjProperty>> toMapMetadataPropertyByUpdateState(List<MetaDataObjProperty> items) {
        Map<propertyValueUpdateState, List<MetaDataObjProperty>> result = new HashMap<>();
        if (CommonUtility.hasValue(items)) {
            for (MetaDataObjProperty item : items) {
                CommonUtility.doAddElementGeneral(result, item.getUpdateState(), item);
            }
        }
        return result;
    }

    protected void setMetaDataPropertyOperation(List<MetaDataObjProperty> items, ProgressLatch progressLatch, ConcurrentHashMap<String, JobWrapper> genJobWrappers, ConcurrentHashMap<String, JobWrapper> dropJobWrappers) {
        if (items != null && items.size() > 0) {
            Map<String, List<MetaDataObjProperty>> splitWithTablePrefix = MetaDataServiceImpl.splitWithTablePrefix(items);
            for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : splitWithTablePrefix.entrySet()) {
                String uniqueKey = listEntry.getKey() + ISharedCommon.COMMON_CONNECTOR + tableSuffix.OBJPR;
                Map<propertyValueUpdateState, List<MetaDataObjProperty>> collections = this.toMapMetadataPropertyByUpdateState(listEntry.getValue());
                if (collections.size() > 0) {
                    for (Map.Entry<propertyValueUpdateState, List<MetaDataObjProperty>> stateListEntry : collections.entrySet()) {
                        switch (stateListEntry.getKey()) {
                            case updated:
                            case revive:
                                this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.U, stateListEntry.getValue(), progressLatch);
                                break;
                            case created:
                                this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.C, stateListEntry.getValue(), progressLatch);
                                break;
                            case terminated:
                                this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.T, stateListEntry.getValue(), progressLatch);
                                break;
                            case deleted:
                                this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.D, stateListEntry.getValue(), progressLatch);
                                break;
                        }
                    }
                }
            }
        }

    }

    protected Map<interfaceUpdateState, List<MetaDataObjInterface>> toMapMetadataInterfaceByUpdateState(List<MetaDataObjInterface> items) {
        Map<interfaceUpdateState, List<MetaDataObjInterface>> result = new HashMap<>();
        if (CommonUtility.hasValue(items)) {
            for (MetaDataObjInterface item : items) {
                CommonUtility.doAddElementGeneral(result, item.getUpdateState(), item);
            }
        }
        return result;
    }

    protected void setMetaDataInterfaceOperation(List<MetaDataObjInterface> items, ProgressLatch progressLatch, ConcurrentHashMap<String, JobWrapper> genJobWrappers, ConcurrentHashMap<String, JobWrapper> dropJobWrappers) {
        if (items != null && items.size() > 0) {
            Map<String, List<MetaDataObjInterface>> splitWithTablePrefix = MetaDataServiceImpl.splitWithTablePrefix(items);
            for (Map.Entry<String, List<MetaDataObjInterface>> listEntry : splitWithTablePrefix.entrySet()) {
                String uniqueKey = listEntry.getKey() + ISharedCommon.COMMON_CONNECTOR + tableSuffix.OBJIF;
                Map<interfaceUpdateState, List<MetaDataObjInterface>> collections = this.toMapMetadataInterfaceByUpdateState(listEntry.getValue());
                if (collections.size() > 0) {
                    for (Map.Entry<interfaceUpdateState, List<MetaDataObjInterface>> stateListEntry : collections.entrySet()) {
                        switch (stateListEntry.getKey()) {
                            case revive:
                                this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.U, stateListEntry.getValue(), progressLatch);
                                break;
                            case created:
                                this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.C, stateListEntry.getValue(), progressLatch);
                                break;
                            case terminated:
                                this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.T, stateListEntry.getValue(), progressLatch);
                                break;
                            case deleted:
                                this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.D, stateListEntry.getValue(), progressLatch);
                                break;
                        }
                    }
                }
            }
        }
    }

    protected Map<objectUpdateState, List<MetaDataObj>> toMapMetadataObjectByUpdateState(List<MetaDataObj> items) {
        Map<objectUpdateState, List<MetaDataObj>> result = new HashMap<>();
        if (CommonUtility.hasValue(items)) {
            for (MetaDataObj item : items) {
                CommonUtility.doAddElementGeneral(result, item.getUpdateState(), item);
            }
        }
        return result;
    }

    protected <T extends MetaData> void setMetaDataObjOperation(List<MetaDataObj> items, ProgressLatch progressLatch, ConcurrentHashMap<String, JobWrapper> genJobWrappers, ConcurrentHashMap<String, JobWrapper> dropJobWrappers) {
        if (CommonUtility.hasValue(items)) {
            Map<String, List<MetaDataObj>> splitWithTablePrefix = MetaDataServiceImpl.splitWithTablePrefix(items);
            for (Map.Entry<String, List<MetaDataObj>> listEntry : splitWithTablePrefix.entrySet()) {
                String uniqueKey = listEntry.getKey() + ISharedCommon.COMMON_CONNECTOR + tableSuffix.OBJ;
                Map<objectUpdateState, List<MetaDataObj>> collections = this.toMapMetadataObjectByUpdateState(listEntry.getValue());
                for (Map.Entry<objectUpdateState, List<MetaDataObj>> stateListEntry : collections.entrySet()) {
                    switch (stateListEntry.getKey()) {
                        case updated:
                            this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.U, stateListEntry.getValue(), progressLatch);
                            break;
                        case created:
                            this.dataProviderService.addJob(genJobWrappers, uniqueKey, CRUD.C, stateListEntry.getValue(), progressLatch);
                            break;
                        case terminated:
                            this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.T, stateListEntry.getValue(), progressLatch);
                            break;
                        case deleted:
                            this.dataProviderService.addJob(dropJobWrappers, uniqueKey, CRUD.D, stateListEntry.getValue(), progressLatch);
                            break;
                    }
                }
            }
        }
    }

    @PostConstruct
    public void doInit() {
        Instance = this;
        Instance.sharedCacheService = this.sharedCacheService;
        Instance.sharedLocalService = this.sharedLocalService;
        Instance.dataProviderService = this.dataProviderService;
        Instance.schemaProviderService = this.schemaProviderService;
    }

    /*
    use by query engine
     */
    public PageResult<LiteObject> onQuery(QueryRequest queryRequest) throws Exception {
        if (queryRequest != null) {
            if (queryRequest.getQueryForRelationship())
                return this.dataProviderService.getRelationships(queryRequest, true);
            else
                return this.dataProviderService.getObjects(queryRequest, true);
        }
        return null;
    }

    /*
    use by query engine
     */
    public List<LiteObject> onExpansion(List<String> tablePrefixes, List<String> obids, String relDef, relDirection relDirection) {
        if (CommonUtility.hasValue(obids) && !StringUtils.isEmpty(relDef)) {
            return this.dataProviderService.getRelationships(new ExpansionWrapper() {{
                this.setPageRequest(null);
                this.setObids(obids);
                this.setRelDef(relDef);
                this.setRelDirection(relDirection);
                this.setTablePrefixes(tablePrefixes);
            }});
        }
        return null;
    }

    public int doExpansionCount(String startOBID, String relDef, relDirection relDirection, List<String> tablePrefixes) {
        if (!StringUtils.isEmpty(startOBID) && !StringUtils.isEmpty(relDef)) {
            return this.dataProviderService.getRelationshipsCount(startOBID, relDef, relDirection, tablePrefixes);
        }
        return 0;
    }
}
