package ccm.server.params;

import ccm.server.entity.MetaData;
import ccm.server.models.LiteObject;
import ccm.server.models.info.InfoIFAndPRDetail;
import ccm.server.util.PerformanceUtility;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StopWatch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@Slf4j
public class InfoDetailsCarrier<T extends MetaData> {

    private Class<T> tClass;
    private final List<T> source = new ArrayList<>();
    private final String tablePrefix;
    private final List<InfoIFAndPRDetail> finalResult = new ArrayList<>();

    public InfoDetailsCarrier() {
        this.tablePrefix = "";
        this.tClass = null;
    }

    public InfoDetailsCarrier(Class<T> tClass, T item, String tablePrefix) {
        this.tClass = tClass;
        if (item != null)
            this.source.add(item);
        this.tablePrefix = tablePrefix;
    }

    public InfoDetailsCarrier(Class<T> tClass, List<T> items, String tablePrefix) {
        this.tClass = tClass;
        if (items != null && items.size() > 0)
            this.source.addAll(items);
        this.tablePrefix = tablePrefix;
    }


    public List<LiteObject> toLiteObject() {
        StopWatch stopWatch = PerformanceUtility.start();
        List<LiteObject> result = new ArrayList<>();
        if (this.finalResult.size() > 0) {
            Map<String, List<InfoIFAndPRDetail>> listMap = this.finalResult.stream().collect(Collectors.groupingBy(c -> {
                if (c != null && c.getInterfaceObjObid() != null)
                    return c.getInterfaceObjObid();
                return "";
            }));
            for (T t : this.source) {
                LiteObject liteObject = new LiteObject(t);
                List<InfoIFAndPRDetail> infoIFAndPRDetails = listMap.get(liteObject.getOBID());
                liteObject.fillWithInfoDetail(infoIFAndPRDetails);
                result.add(liteObject);
            }
        }
        log.trace("construction from db record(s) into lite object(s) with " + result.size() + PerformanceUtility.stop(stopWatch));
        return result;
    }
}
