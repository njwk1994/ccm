package ccm.server.params;

import ccm.server.entity.MetaData;
import ccm.server.models.LiteObject;
import ccm.server.models.LiteObjectPart;
import ccm.server.util.PerformanceUtility;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StopWatch;

import java.util.ArrayList;
import java.util.List;

@Data
@Slf4j
public class LiteObjectPartCarrier<T extends MetaData> extends InfoDetailsCarrier<T> {

    public LiteObjectPartCarrier(Class<T> tClass, T item, String tablePrefix) {
        super(tClass, item, tablePrefix);
    }

    public LiteObjectPartCarrier(Class<T> tClass, List<T> items, String tablePrefix) {
        super(tClass, items, tablePrefix);
    }

    @Override
    public List<LiteObject> toLiteObject() {
        List<LiteObject> result = new ArrayList<>();
        StopWatch stopWatch = PerformanceUtility.start();


        log.trace("construction from db record(s) into lite object(s) with " + result.size() + PerformanceUtility.stop(stopWatch));
        return result;
    }

}
