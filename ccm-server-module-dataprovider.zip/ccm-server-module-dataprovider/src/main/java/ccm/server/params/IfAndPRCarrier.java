package ccm.server.params;

import ccm.server.entity.MetaData;
import ccm.server.entity.MetaDataObj;
import ccm.server.models.LiteObject;
import ccm.server.util.CollectionUtility;
import ccm.server.util.CommonUtility;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class IfAndPRCarrier<T extends MetaData> {
    private final List<T> source = new ArrayList<>();

    private final List<Map<String, Object>> result = new ArrayList<>();

    private String tablePrefix;

    public List<LiteObject> toAdvancedLiteObject() {
        List<LiteObject> result = new ArrayList<>();
        Map<String, List<Map<String, Object>>> items = CollectionUtility.mapByObid(this.getResult(), "interface_objObid");
        for (T obj : this.getSource()) {
            LiteObject liteObject = new LiteObject(obj);
            List<Map<String, Object>> itemSources = items.getOrDefault(obj.getObid(), null);
            if (CommonUtility.hasValue(itemSources)) {
                liteObject.fillWithMapList(itemSources);
            }
            result.add(liteObject);
        }
        return result;
    }

    public IfAndPRCarrier(T item, String tablePrefix) {
        this.setTablePrefix(tablePrefix);
        if (item != null) {
            this.source.add(item);
        }
    }

    public IfAndPRCarrier(List<T> items, String tablePrefix) {
        this.setTablePrefix(tablePrefix);
        if (CommonUtility.hasValue(items)) {
            this.source.addAll(items);
        }
    }
}
