package ccm.server.params;

import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataRel;
import ccm.server.enums.relDirection;
import ccm.server.helper.HardCodeHelper;
import ccm.server.models.LiteObject;
import ccm.server.util.CommonUtility;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class ObjRelationshipCarrier {
    private final List<String> relDefs = new ArrayList<>();
    private final Map<MetaDataObj, List<MetaDataRel>> list = new HashMap<>();
    private final Map<MetaDataObj, List<MetaDataRel>> end1Relationships = new HashMap<>();
    private final Map<MetaDataObj, List<MetaDataRel>> end2Relationships = new HashMap<>();

    public ObjRelationshipCarrier() {

    }

    public ObjRelationshipCarrier(List<String> relDefs, Map<MetaDataObj, List<MetaDataRel>> list) {
        if (CommonUtility.hasValue(relDefs))
            this.getRelDefs().addAll(relDefs);
        if (CommonUtility.hasValue(list))
            this.getList().putAll(list);
    }


    private void fill(Map<String, LiteObject> mapLite, Map<MetaDataObj, List<MetaDataRel>> items, relDirection relDirection) {
        if (mapLite == null)
            mapLite = new HashMap<>();
        if (CommonUtility.hasValue(items)) {
            for (Map.Entry<MetaDataObj, List<MetaDataRel>> entry : items.entrySet()) {
                LiteObject liteObject = null;
                if (!mapLite.containsKey(entry.getKey().getObid())) {
                    liteObject = new LiteObject(entry.getKey());
                    mapLite.put(entry.getKey().getObid(), liteObject);
                } else
                    liteObject = mapLite.get(entry.getKey().getObid());
                if (liteObject != null) {
                    for (MetaDataRel rel : entry.getValue()) {
                        switch (relDirection) {
                            case _1To2:
                                liteObject.collectEnd1Relationship(rel);
                                break;
                            case _2To1:
                                liteObject.collectEnd2Relationship(rel);
                                break;
                        }
                    }
                }
            }
        }
    }

    public List<LiteObject> toLiteObject() {
        Map<String, LiteObject> mapLite = new HashMap<>();
        if (CommonUtility.hasValue(this.getEnd1Relationships()))
            this.fill(mapLite, this.getEnd1Relationships(), relDirection._1To2);
        if (CommonUtility.hasValue(this.getEnd2Relationships()))
            this.fill(mapLite, this.getEnd2Relationships(), relDirection._2To1);
        return new ArrayList<>(mapLite.values());
    }

    private String parse(String relOrEdgeDef) {
        if (!StringUtils.isEmpty(relOrEdgeDef)) {
            if (relOrEdgeDef.startsWith(relDirection._1To2.getPrefix()) || relOrEdgeDef.startsWith(relDirection._2To1.getPrefix()))
                return relOrEdgeDef.substring(1);
            if (relOrEdgeDef.startsWith(HardCodeHelper.UNIQUE_EDGE_UID_PREFIX))
                return relOrEdgeDef.substring(HardCodeHelper.UNIQUE_EDGE_UID_PREFIX.length());
        }
        return "";
    }

    private List<String> getRelDef(relDirection relDirection) {
        if (CommonUtility.hasValue(relDefs)) {
            List<String> result = new ArrayList<>();
            for (String relDef : this.getRelDefs()) {
                if (relDef.startsWith(relDirection.getPrefix()))
                    result.add(relDef);
                else if (relDirection == ccm.server.enums.relDirection._1To2 && relDef.startsWith(HardCodeHelper.UNIQUE_EDGE_UID_PREFIX))
                    result.add(relDef);
            }
            return result;
        }
        return null;
    }

    public Map<relDirection, List<String>> groupByRelDirection() {
        Map<relDirection, List<String>> result = new HashMap<>();
        List<String> relDefs1 = this.getRelDef(relDirection._1To2);
        result.put(relDirection._1To2, relDefs1);
        List<String> relDefs2 = this.getRelDef(relDirection._2To1);
        result.put(relDirection._2To1, relDefs2);
        return result;
    }

    @Override
    public String toString() {
        return String.join(",", relDefs) + "," + CommonUtility.getSize(this.getList());
    }
}
