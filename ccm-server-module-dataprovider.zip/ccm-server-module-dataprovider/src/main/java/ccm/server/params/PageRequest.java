package ccm.server.params;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class PageRequest {
    private int pageIndex;
    private int pageSize;

    public PageRequest(int pageIndex, int pageSize) {
        this.setPageIndex(pageIndex);
        this.setPageSize(pageSize);
    }
}
