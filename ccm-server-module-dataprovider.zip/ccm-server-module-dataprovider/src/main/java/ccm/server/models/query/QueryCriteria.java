package ccm.server.models.query;

import ccm.server.enums.*;
import ccm.server.util.CommonUtility;
import ccm.server.util.SqlHelper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.enums.SqlKeyword;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.toolkit.Constant;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Data
@Slf4j
public class QueryCriteria implements Comparator<QueryCriteria> {
    private final QueryRequest queryRequest;
    private String relOrEdgeDefinitionUID;
    private String interfaceDefinitionUID;
    private String propertyDefinitionUID;
    private ccm.server.enums.operator operator;
    private String value;
    private Integer tableIndex = null;
    private boolean usedForOrdering = false;
    private boolean usedForRendering = false;
    private ExpansionMode expansionMode = ExpansionMode.none;
    private final List<String> tableNames = new ArrayList<>();
    private ccm.server.enums.orderMode orderMode = ccm.server.enums.orderMode.none;
    private ccm.server.enums.joinMode joinMode = ccm.server.enums.joinMode.Inner;
    private boolean useAsSelectClass = false;
    private String valueType;

    public void setUseAsSelectClass(boolean value) {
        this.useAsSelectClass = value;
    }

    public void setTableIndex(Integer value) {
        if (value != null) {
            this.tableIndex = new Integer(String.valueOf(value));
        } else
            this.tableIndex = null;
    }

    private void ensureOperator() {
        if (this.operator == null)
            this.operator = ccm.server.enums.operator.equal;
    }

    @Deprecated
    private void generateBaseRelOrderSql(StringBuilder stringBuilder, String table) {
        if (stringBuilder != null) {
            relDirection direction = this.direction();
            switch (direction) {
                case _1To2:
                    if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.Name.toString())) {
                        stringBuilder.append(propertyDefinitionType.Name2.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    } else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.OBID.toString())) {
                        stringBuilder.append(propertyDefinitionType.OBID2.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    } else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.UID.toString())) {
                        stringBuilder.append(propertyDefinitionType.UID2.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    } else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID.toString())) {
                        stringBuilder.append(propertyDefinitionType.ClassDefinitionUID2.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    }
                    break;
                case _2To1:
                    if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.Name.toString())) {
                        stringBuilder.append(propertyDefinitionType.Name1.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    } else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.OBID.toString())) {
                        stringBuilder.append(propertyDefinitionType.OBID1.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    } else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.UID.toString())) {
                        stringBuilder.append(propertyDefinitionType.UID1.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    } else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID.toString())) {
                        stringBuilder.append(propertyDefinitionType.ClassDefinitionUID1.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                    }
                    break;
            }
        }
    }

    public void generateOrderBy(MPJQueryWrapper<?> queryWrapper) throws Exception {
        if (queryWrapper != null) {
            if (this.usedForOrdering) {
                if (this.orderMode != null && this.orderMode != ccm.server.enums.orderMode.none) {
                    String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
                    List<String> columns = new ArrayList<>();
                    String column = null;
                    if (this.useBaseProperty())
                        columns.add(table + StringPool.DOT + getColumnName(this.propertyDefinitionUID));
                    else if (this.useAdvancedProperty()) {
                        column = table + StringPool.DOT + propertyDefinitionType.STRVALUE.getColumnName();
                        columns.add(column);
                        queryWrapper.select(column + " as " + table + "_" + propertyDefinitionType.STRVALUE.toString());
                    } else if (this.useRelationship()) {
                        relDirection direction = this.direction();
                        if (this.useRelationshipCustomProperty()) {
                            int index = 1;
                            for (String tableName : this.tableNames) {
                                String appendTable = this.generateAppendTable(table, index);
                                column = appendTable + StringPool.DOT + propertyDefinitionType.STRVALUE.getColumnName();
                                queryWrapper.select(column + " as " + table + "_" + propertyDefinitionType.STRVALUE.toString());
                                columns.add(column);
                                index++;
                            }
                        } else {
                            switch (direction) {
                                case _2To1:
                                    if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.Name.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.Name1.getColumnName();
                                    else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.UID1.getColumnName();
                                    else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.ClassDefinitionUID1.getColumnName();
                                    else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.OBID1.getColumnName();
                                    break;
                                case _1To2:
                                    if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.Name.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.Name2.getColumnName();
                                    else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.UID2.getColumnName();
                                    else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.ClassDefinitionUID2.getColumnName();
                                    else if (this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                                        column = table + StringPool.DOT + propertyDefinitionType.OBID2.getColumnName();
                                    break;
                            }
                            if (column != null) {
                                queryWrapper.select(column + " as " + table + "_" + propertyDefinitionType.STRVALUE.toString());
                                columns.add(column);
                            }

                        }
                    }
                    if (columns.size() == 0)
                        throw new Exception("invalid column as it is null for ordering");
                    columns = this.convertOrderColumnsExpression(columns);
                    switch (this.orderMode) {
                        case asc:
                            queryWrapper.orderByAsc(columns);
                            break;
                        case desc:
                            queryWrapper.orderByDesc(columns);
                            break;
                    }
                }
            }
        }
    }

    private List<String> convertOrderColumnsExpression(List<String> columns) {
        if (columns != null && !columns.isEmpty() && !StringUtils.isEmpty(this.valueType)) {
            List<String> result = new ArrayList<>();
            propertyValueType propertyValueType = ccm.server.enums.propertyValueType.valueOf(this.valueType);
            for (String column : columns) {
                switch (propertyValueType) {
                    case DoubleType:
                    case IntegerType:
                        String expressColumn = "CONVERT(" + column + ",SIGNED)";
                        result.add(expressColumn);
                        break;
                }
            }
            return result;
        }
        return columns;
    }

    @Deprecated
    public String generateOrderBySql() {
        if (this.usedForOrdering && this.orderMode != null && this.orderMode != ccm.server.enums.orderMode.none) {
            StringBuilder stringBuilder = new StringBuilder();
            String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
            if (this.useClassDef()) {
                stringBuilder.append(propertyDefinitionType.ClassDefinitionUID.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
            } else if (this.useInterface()) {
                stringBuilder.append(propertyDefinitionType.InterfaceDefinitionUID.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
            } else if (this.useAdvancedProperty()) {
                stringBuilder.append(propertyDefinitionType.STRVALUE.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
            } else if (this.useRelationship()) {
                if (this.isBaseRelTableProperty(this.propertyDefinitionUID)) {
                    this.generateBaseRelOrderSql(stringBuilder, table);
                } else {
                    String appendTable = table + table;
                    stringBuilder.append(propertyDefinitionType.STRVALUE.generateColumn(appendTable)).append(StringPool.SPACE).append(this.orderMode.toString());
                }
            } else if (this.useBaseProperty()) {
                propertyDefinitionType propertyDefinitionType = ccm.server.enums.propertyDefinitionType.ValueOf(this.propertyDefinitionUID);
                if (propertyDefinitionType != null)
                    stringBuilder.append(propertyDefinitionType.generateColumn(table)).append(StringPool.SPACE).append(this.orderMode.toString());
                else
                    stringBuilder.append(table).append(StringPool.DOT).append(this.propertyDefinitionUID).append(StringPool.SPACE).append(this.orderMode.toString());
            }
            return stringBuilder.toString();
        }
        return StringPool.EMPTY;
    }

    public String generateJoinSql() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.useInterface()) {
            this.generateIFJoinSql(stringBuilder);
        } else if (this.useAdvancedProperty()) {
            this.generatePRJoinSql(stringBuilder);
        } else if (this.useRelationship()) {
            this.generateRELJoinSql(stringBuilder);
        }
        return stringBuilder.toString();
    }

    public void generateWhereSql(MPJQueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            if (this.useBaseProperty()) {
                this.generateOBJWhereSql(queryWrapper);
            }
        }
    }

    public void generateIsNULLSql(MPJQueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            if (this.useRelationship()) {
                if (this.useRelationshipCustomProperty()) {
                    this.generateIsNULLAppendRelSql(queryWrapper);
                } else
                    this.generateIsNULLRELSql(queryWrapper);
            } else if (this.useAdvancedProperty()) {
                this.generateIsNULLPRSql(queryWrapper);
            } else if (this.useInterface()) {
                this.generateIsNULLIFSql(queryWrapper);
            }
        }
    }

    private void generateIsNULLAppendRelSql(MPJQueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            List<String> tableNames = this.tableNames.stream().distinct().collect(Collectors.toList());
            String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
            int index = 1;
            for (String tableName : tableNames) {
                String appendTable = this.generateAppendTable(table, index);
                List<String> segments = new ArrayList<>();
                segments.add(StringPool.LEFT_BRACKET);
                segments.add(StringPool.LEFT_BRACKET);
                segments.add(SqlHelper.sqlIsNull(appendTable));
                segments.add(SqlKeyword.OR.getSqlSegment());
                segments.add(SqlHelper.sqlPropertyStrValue(appendTable, propertyValueType.StringType.name(), this.operator, this.value));
                segments.add(StringPool.RIGHT_BRACKET);
//                segments.add(StringPool.AND);
//                segments.add(SqlHelper.sqlTerminationUser(appendTable));
                segments.add(StringPool.RIGHT_BRACKET);
                queryWrapper.where(true, String.join(StringPool.SPACE, segments));
                index++;
            }
        }
    }

    private void generateIsNULLRELSql(MPJQueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
            List<String> segments = new ArrayList<>();
            segments.add(StringPool.LEFT_BRACKET);
            segments.add(SqlHelper.sqlIsNull(table));
            segments.add(SqlKeyword.OR.getSqlSegment());
            segments.add(StringPool.LEFT_BRACKET);
            this.setBaseRelCondition(segments, table, this.direction(), this.propertyDefinitionUID);
            segments.add(StringPool.RIGHT_BRACKET);
            segments.add(StringPool.RIGHT_BRACKET);
            queryWrapper.where(true, String.join(StringPool.SPACE, segments));
        }
    }

    protected void generateIsNULLPRSql(MPJQueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
            List<String> segments = new ArrayList<>();
            segments.add(StringPool.LEFT_BRACKET);
            segments.add(StringPool.LEFT_BRACKET);
            segments.add(SqlHelper.sqlIsNull(table));
            segments.add(SqlKeyword.OR.getSqlSegment());
            segments.add(SqlHelper.sqlPropertyStrValue(table, propertyValueType.StringType.name(), this.operator, this.value));
            segments.add(StringPool.RIGHT_BRACKET);
//            segments.add(StringPool.AND);
//            segments.add(SqlHelper.sqlTerminationUser(table));
            segments.add(StringPool.RIGHT_BRACKET);
            queryWrapper.where(true, String.join(StringPool.SPACE, segments));
        }
    }

    protected void generateIsNULLIFSql(MPJQueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
            List<String> segments = new ArrayList<>();
            segments.add(StringPool.LEFT_BRACKET);
            segments.add(StringPool.LEFT_BRACKET);
            segments.add(SqlHelper.sqlIsNull(table));
            segments.add(SqlKeyword.OR.getSqlSegment());
            segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.InterfaceDefinitionUID, propertyValueType.StringType.name(), table, this.operator, this.value));
            segments.add(StringPool.AND);
            segments.add(StringPool.RIGHT_BRACKET);
//            segments.add(StringPool.AND);
//            segments.add(SqlHelper.sqlTerminationUser(table));
            segments.add(StringPool.RIGHT_BRACKET);
            queryWrapper.where(true, String.join(StringPool.SPACE, segments));
        }
    }

    @Deprecated
    protected void generateOBJWhereSql(QueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            this.ensureOperator();
            String column = Constant.TABLE_ALIAS + StringPool.DOT + getColumnName(this.propertyDefinitionUID);
            switch (this.operator) {
                case _isNOT:
                    queryWrapper.isNotNull(column);
                    break;
                case _is:
                    queryWrapper.isNull(column);
                    break;
                case like:
                    queryWrapper.like(column, SqlHelper.getReplacedValueFromSTARIntoPERCENT(this.value));
                    break;
                case notLike:
                    queryWrapper.notLike(column, SqlHelper.getReplacedValueFromSTARIntoPERCENT(this.value));
                    break;
                case between:
                    Object[] betweenArray = SqlHelper.getValueArrayWith2Elements(this.value);
                    queryWrapper.between(column, betweenArray[0], betweenArray[1]);
                    break;
                case notBetween:
                    Object[] notBetweenArray = SqlHelper.getValueArrayWith2Elements(this.value);
                    queryWrapper.notBetween(column, notBetweenArray[0], notBetweenArray[1]);
                    break;
                case notEqual:
                    queryWrapper.ne(column, this.value);
                    break;
                case equal:
                    queryWrapper.eq(column, this.value);
                    break;
                case lessThan:
                    queryWrapper.lt(column, this.value);
                    break;
                case largeThan:
                    queryWrapper.gt(column, this.value);
                    break;
                case lessOrEqualThan:
                    queryWrapper.le(column, this.value);
                    break;
                case largeOrEqualThan:
                    queryWrapper.ge(column, this.value);
                case notIn:
                    queryWrapper.notIn(column, Arrays.stream(SqlHelper.getValueArray(this.value)).collect(Collectors.toList()));
                    break;
                case in:
                    queryWrapper.in(column, Arrays.stream(SqlHelper.getValueArray(this.value)).collect(Collectors.toList()));
                    break;
            }
        }
    }

    protected void generateOBJWhereSql(MPJQueryWrapper<?> queryWrapper) {
        String table = Constant.TABLE_ALIAS;
        this.generateWhereSql(table, queryWrapper);
    }

    private void generateWhereSql(String table, MPJQueryWrapper<?> subQueryWrapper) {
        if (!StringUtils.isEmpty(table) && subQueryWrapper != null && this.validForQuerying(this.value)) {
            propertyDefinitionType propertyDefinitionType = ccm.server.enums.propertyDefinitionType.ValueOf(this.propertyDefinitionUID);
            String column = table + StringPool.DOT + this.propertyDefinitionUID;
            if (propertyDefinitionType != null)
                column = propertyDefinitionType.generateColumn(table);
            this.ensureOperator();
            switch (this.operator) {
                case _isNOT:
                    subQueryWrapper.isNotNull(column);
                    break;
                case _is:
                    subQueryWrapper.isNull(column);
                    break;
                case like:
                    subQueryWrapper.like(column, SqlHelper.getReplacedValueFromSTARIntoPERCENT(this.value));
                    break;
                case notLike:
                    subQueryWrapper.notLike(column, SqlHelper.getReplacedValueFromSTARIntoPERCENT(this.value));
                    break;
                case between:
                    Object[] betweenArray = SqlHelper.getValueArrayWith2Elements(this.value);
                    subQueryWrapper.between(column, betweenArray[0], betweenArray[1]);
                    break;
                case notBetween:
                    Object[] notBetweenArray = SqlHelper.getValueArrayWith2Elements(this.value);
                    subQueryWrapper.notBetween(column, notBetweenArray[0], notBetweenArray[1]);
                    break;
                case notEqual:
                    subQueryWrapper.ne(column, this.value);
                    break;
                case equal:
                    subQueryWrapper.eq(column, this.value);
                    break;
                case lessThan:
                    subQueryWrapper.lt(column, this.value);
                    break;
                case largeThan:
                    subQueryWrapper.gt(column, this.value);
                    break;
                case lessOrEqualThan:
                    subQueryWrapper.le(column, this.value);
                    break;
                case largeOrEqualThan:
                    subQueryWrapper.ge(column, this.value);
                case notIn:
                    subQueryWrapper.notIn(column, Arrays.stream(SqlHelper.getValueArray(this.value)).collect(Collectors.toList()));
                    break;
                case in:
                    subQueryWrapper.in(column, Arrays.stream(SqlHelper.getValueArray(this.value)).collect(Collectors.toList()));
                    break;
            }
        }
    }

    protected void generateIFJoinSql(StringBuilder stringBuilder) {
        if (this.validForQuerying(this.value)) {
            this.ensureOperator();
            String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
            List<String> segments = new ArrayList<>();
            segments.add(SqlHelper.TABLE_OBJ_IF);
            segments.add(table);
            segments.add(Constant.ON);
            segments.add(SqlHelper.sqlJoinOnOBIDToOBJOBID(table));
            segments.add(StringPool.AND);
            segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.InterfaceDefinitionUID, propertyValueType.StringType.name(), table, this.operator, this.value));
//            segments.add(StringPool.AND);
//            segments.add(SqlHelper.sqlTerminationUser(table));
            stringBuilder.append(String.join(StringPool.SPACE, segments)).append(StringPool.CRLF);
        }
    }

    protected void generatePRJoinSql(StringBuilder stringBuilder) {
        String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
        this.ensureOperator();
        List<String> segments = new ArrayList<>();
        segments.add(SqlHelper.TABLE_OBJ_PR);
        segments.add(table);
        segments.add(Constant.ON);
        segments.add(SqlHelper.sqlJoinOnOBIDToOBJOBID(table));
        segments.add(StringPool.AND);
        segments.add(SqlHelper.sqlPropertyDef(table, this.propertyDefinitionUID));
        if (this.validForQuerying(this.value)) {
            segments.add(StringPool.AND);
            segments.add(SqlHelper.sqlPropertyStrValue(table, propertyValueType.StringType.name(), this.operator, this.value));
//            segments.add(StringPool.AND);
//            segments.add(SqlHelper.sqlTerminationUser(table));
        }
        stringBuilder.append(String.join(StringPool.SPACE, segments)).append(StringPool.CRLF);
    }

    protected boolean isBaseRelTableProperty(String propertyDefinitionUID) {
        if (!StringUtils.isEmpty(propertyDefinitionUID)) {
            return propertyDefinitionType.relTableBaseProperty().stream().anyMatch(c -> c.equalsIgnoreCase(propertyDefinitionUID));
        }
        return false;
    }

    protected void setBaseRelCondition(List<String> segments, String table, relDirection direction, String propertyDefinitionUID) {
        switch (direction) {
            case _1To2:
                if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.Name.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.Name2, propertyValueType.StringType.name(), table, this.operator, this.value));
                } else if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.UID.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.UID2, propertyValueType.StringType.name(), table, this.operator, this.value));
                } else if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.ClassDefinitionUID2, propertyValueType.StringType.name(), table, this.operator, this.value));
                } else if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.OBID.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.OBID2, propertyValueType.StringType.name(), table, this.operator, this.value));
                }
                break;
            case _2To1:
                if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.Name.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.Name1, propertyValueType.StringType.name(), table, this.operator, this.value));
                } else if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.UID.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.UID1, propertyValueType.StringType.name(), table, this.operator, this.value));
                } else if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.ClassDefinitionUID1, propertyValueType.StringType.name(), table, this.operator, this.value));
                } else if (propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.OBID.toString())) {
                    segments.add(SqlHelper.sqlColumnValue(propertyDefinitionType.OBID1, propertyValueType.StringType.name(), table, this.operator, this.value));
                }
                break;
        }
//        segments.add(StringPool.AND);
//        segments.add(SqlHelper.sqlTerminationUser(table));
    }

    protected void setAppendRelCondition(List<String> segments, String table, relDirection direction, String propertyDefinitionUID, String value) {
        if (segments != null && !StringUtils.isEmpty(table) && !StringUtils.isEmpty(propertyDefinitionUID)) {
            if (this.validForQuerying(value)) {
                if (this.tableNames.size() > 0) {
                    List<String> tableNames = this.tableNames.stream().distinct().collect(Collectors.toList());
                    int index = 1;
                    for (String tableName : tableNames) {
                        String appendTable = this.generateAppendTable(table, index);
                        segments.add(Constant.INNER + StringPool.SPACE + Constant.JOIN);
                        segments.add(tableName + SqlHelper.TABLE_OBJ_PR);
                        segments.add(appendTable);
                        segments.add(Constant.ON);
                        switch (direction) {
                            case _1To2:
                                segments.add(SqlHelper.sqlJoinOnOBID2ToOBJOBID(table, appendTable));
                                break;
                            case _2To1:
                                segments.add(SqlHelper.sqlJoinOnOBID1ToOBJOBID(table, appendTable));
                                break;
                        }
                        segments.add(StringPool.AND);
                        segments.add(SqlHelper.sqlPropertyDef(appendTable, propertyDefinitionUID));
                        if (this.getJoinMode() == ccm.server.enums.joinMode.Inner) {
                            segments.add(StringPool.AND);
                            segments.add(SqlHelper.sqlPropertyStrValue(appendTable, propertyValueType.StringType.name(), this.operator, this.value));
//                            segments.add(StringPool.AND);
//                            segments.add(SqlHelper.sqlTerminationUser(appendTable));
                        }
                        segments.add(StringPool.CRLF);
                        index++;
                    }
                }
            }
        }
    }

    private String generateAppendTable(String table, int index) {
        if (!StringUtils.isEmpty(table)) {
            StringBuilder result = new StringBuilder(table);
            for (int i = 1; i <= index; i++) {
                result.append("_").append(index);
            }
            return result.toString();
        }
        return table;
    }

    protected void generateRELJoinSql(StringBuilder stringBuilder) {
        String table = Constant.TABLE_ALIAS + SqlHelper.tableSuffix(this.tableIndex);
        this.ensureOperator();
        relDirection direction = this.direction();
        String actualRelOrEdgeDef = this.relOrEdgeDefUID();
        boolean flag = this.isBaseRelTableProperty(this.propertyDefinitionUID);
        List<String> sqlSegments = new ArrayList<>();
        sqlSegments.add(SqlHelper.TABLE_OBJ_REL);
        sqlSegments.add(table);
        sqlSegments.add(Constant.ON);
        switch (direction) {
            case _1To2:
                sqlSegments.add(SqlHelper.sqlJoinOnOBIDToOBID1(table));
                break;
            case _2To1:
                sqlSegments.add(SqlHelper.sqlJoinOnOBIDToOBID2(table));
                break;
        }
        sqlSegments.add(StringPool.AND);
        sqlSegments.add(SqlHelper.sqlRelDef(table, actualRelOrEdgeDef));
        List<String> appendSqlSegments = new ArrayList<>();
        if (flag) {
            if (this.validForQuerying(this.value)) {
                sqlSegments.add(StringPool.AND);
                this.setBaseRelCondition(sqlSegments, table, direction, this.propertyDefinitionUID);
            }
        } else {
            this.setAppendRelCondition(appendSqlSegments, table, direction, this.propertyDefinitionUID, this.value);
        }
        stringBuilder.append(String.join(StringPool.SPACE, sqlSegments)).append(StringPool.CRLF);
        if (CommonUtility.hasValue(appendSqlSegments))
            stringBuilder.append(String.join(StringPool.SPACE, appendSqlSegments)).append(StringPool.CRLF);
    }

    public boolean validForQuerying(String value) {
        if (value == null)
            value = this.value;
        return !StringUtils.isEmpty(value) && !StringUtils.isEmpty(value.replace("*", "").trim());
    }

    public boolean useInterface() {
        return this.operator.equals(ccm.server.enums.operator.equal) &&
                StringUtils.isEmpty(this.relOrEdgeDefinitionUID) &&
                this.interfaceDefinitionUID.equalsIgnoreCase(interfaceDefinitionType.IObject.toString()) &&
                this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.InterfaceDefinitionUID.toString());
    }

    public boolean useClassDef() {
        return this.operator.equals(ccm.server.enums.operator.equal) &&
                StringUtils.isEmpty(this.relOrEdgeDefinitionUID) &&
                this.interfaceDefinitionUID.equalsIgnoreCase(interfaceDefinitionType.IObject.toString()) &&
                this.propertyDefinitionUID.equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID.toString());
    }

    public boolean useBaseProperty() {
        if (!this.useRelationship()) {
            List<String> arrIndicators = propertyDefinitionType.OBJORRELTableProperties();
            return arrIndicators.stream().anyMatch(c -> c.equalsIgnoreCase(this.propertyDefinitionUID));
        }
        return false;
    }

    public boolean useAdvancedProperty() {
        if (!this.useRelationship()) {
            List<String> arrIndicators = propertyDefinitionType.OBJORRELTableProperties();
            return arrIndicators.stream().noneMatch(c -> c.equalsIgnoreCase(this.propertyDefinitionUID));
        }
        return false;
    }

    public boolean useRelationship() {
        return !StringUtils.isEmpty(this.relOrEdgeDefinitionUID);
    }

    public boolean useRelationshipCustomProperty() {
        if (this.useRelationship()) {
            return !this.isBaseRelTableProperty(this.propertyDefinitionUID);
        }
        return false;
    }

    public relDirection direction() {
        return CommonUtility.toRelDirection(this.getRelOrEdgeDefinitionUID());
    }

    public String relOrEdgeDefUID() {
        return CommonUtility.toActualDefinition(this.getRelOrEdgeDefinitionUID());
    }

    @Deprecated
    public static String parseColumnNameByRELProperty(String propertyDefinitionUID) {
        if (!StringUtils.isEmpty(propertyDefinitionUID)) {
            try {
                propertyDefinitionType propertyDefinitionType = ccm.server.enums.propertyDefinitionType.valueOf(propertyDefinitionUID);
                return propertyDefinitionType.getColumnName();
            } catch (Exception exception) {
                log.error(exception.getMessage(), exception);
            }
        }
        return propertyDefinitionUID;
    }

    public static String getColumnName(String propertyDefinitionUID) {
        if (!StringUtils.isEmpty(propertyDefinitionUID)) {
            try {
                propertyDefinitionType propertyDefinitionType = ccm.server.enums.propertyDefinitionType.valueOf(propertyDefinitionUID);
                return propertyDefinitionType.getColumnName();
            } catch (Exception exception) {
                log.error(exception.getMessage(), exception);
            }
        }
        return propertyDefinitionUID;
    }

    public QueryCriteria(QueryRequest queryRequest, String relOrEdgeDefUid, String interfaceDefinitionUID, String propertyDefinitionUID, String propertyValueType, ccm.server.enums.operator operator, String value, ExpansionMode expansionMode) {
        this.relOrEdgeDefinitionUID = relOrEdgeDefUid;
        this.interfaceDefinitionUID = interfaceDefinitionUID;
        this.propertyDefinitionUID = propertyDefinitionUID;
        this.operator = operator;
        this.value = value;
        this.expansionMode = expansionMode;
        this.queryRequest = queryRequest;
        this.valueType = propertyValueType;
    }

    public String expansionModePlusIdentity() {
        return this.expansionMode + "->>>" + this.identity();
    }

    public String identity() {
        if (!StringUtils.isEmpty(this.relOrEdgeDefinitionUID))
            return this.direction().getPrefix() + this.relOrEdgeDefinitionUID + "." + this.propertyDefinitionUID;
        return this.propertyDefinitionUID;
    }

    public QueryCriteria(QueryRequest queryRequest, String interfaceDefinitionUid, String propertyDefinitionUid, String propertyValueType, ccm.server.enums.operator pstrOperator, String value, ExpansionMode expansionMode) {
        this(queryRequest, "", interfaceDefinitionUid, propertyDefinitionUid, propertyValueType, pstrOperator, value, expansionMode);
    }

    @Override
    public int compare(QueryCriteria o1, QueryCriteria o2) {
        if (o1 != null && o2 != null) {
            Integer hashCode1 = o1.hashCode();
            Integer hashCode2 = o2.hashCode();
            return hashCode1.compareTo(hashCode2);
        }
        return -1;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null)
            return false;
        if (this == o)
            return true;
        if (o.getClass().getName().equalsIgnoreCase(this.getClass().getName())) {
            QueryCriteria that = (QueryCriteria) o;
            return relOrEdgeDefinitionUID.equals(that.relOrEdgeDefinitionUID) &&
                    propertyDefinitionUID.equals(that.propertyDefinitionUID) &&
                    this.getOperator().equals(that.getOperator());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(relOrEdgeDefinitionUID, propertyDefinitionUID, this.getOperator());
    }

    @Override
    public String toString() {
        return "QueryCriteria{" +
                "expansionMode='" + expansionMode + '\'' +
                "relOrEdgeDefinition='" + relOrEdgeDefinitionUID + '\'' +
                ", interfaceDefinition='" + interfaceDefinitionUID + '\'' +
                ", propertyDefinition='" + propertyDefinitionUID + '\'' +
                ", operator=" + operator +
                ", value='" + value + '\'' +
                '}';
    }
}
