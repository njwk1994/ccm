package ccm.server.models.query;

import ccm.server.enums.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class QueryInterface {
    private String interfaceDefinition = "";

    public QueryInterface(String pstrInterfaceDefinition) {
        this.interfaceDefinition = pstrInterfaceDefinition;
    }

    public QueryCriteria Criteria(QueryRequest queryRequest) {
        String[] strings = interfaceDefinition.split(",");
        if (strings.length == 1)
            return new QueryCriteria(queryRequest, interfaceDefinitionType.IObject.toString(), propertyDefinitionType.InterfaceDefinitionUID.toString(), propertyValueType.StringType.name(),operator.equal, this.interfaceDefinition, ExpansionMode.none);
        else
            return new QueryCriteria(queryRequest, interfaceDefinitionType.IObject.toString(), propertyDefinitionType.InterfaceDefinitionUID.toString(), propertyValueType.StringType.name(),operator.in, this.interfaceDefinition, ExpansionMode.none);
    }
}
