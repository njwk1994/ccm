package ccm.server.models.info;

import lombok.Data;

import java.io.Serializable;

@Data
public class InfoIFAndPRDetail implements Serializable {
    private static final long serialVersionUID = 1L;
    private String interfaceObid;
    private String interfaceObjObid;
    private String interfaceInterfaceDefUid;
    private String interfaceCreationDate;
    private String interfaceTerminationDate;
    private String interfaceCreationUser;
    private String interfaceTerminationUser;
    private String propertyObid;
    private String propertyObjObid;
    private String propertyPropertyDefUid;
    private String propertyInterfaceObid;
    private String propertyInterfaceDefUid;
    private String propertyStrValue;
    private String propertyUom;
    private String propertyCreationDate;
    private String propertyTerminationDate;
    private String propertyCreationUser;
    private String propertyTerminationUser;
}
