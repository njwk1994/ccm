package ccm.server.models;

import ccm.server.entity.MetaDataRel;
import ccm.server.enums.dataType;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Data
@Slf4j
public class LiteObjectCollection extends HashMap<String, LiteObject> {
    private String userName;
    public void add(LiteObjectCollection liteObjectCollection) {
        if (liteObjectCollection != null && liteObjectCollection.size() > 0) {
            for (Entry<String, LiteObject> objectEntry : liteObjectCollection.entrySet()) {
                this.putIfAbsent(objectEntry.getKey(), objectEntry.getValue());
            }
        }
    }

    public LiteObjectCollection(String userName) {
        this.userName = userName;
    }

    public List<LiteObject> getEnd1RelsByProvidedOBIDOrUIDDomainUID(String pstrOBID, String pstrUID, String pstrDomainUID) {
        List<LiteObject> result = new ArrayList<>();
        for (Entry<String, LiteObject> entry : this.entrySet()) {
            LiteObject liteObject = entry.getValue();
            if (liteObject.DataType() == dataType.rel) {
                MetaDataRel rel = liteObject.getREL();
                if (!StringUtils.isEmpty(pstrOBID)) {
                    if (rel.getObid1().equalsIgnoreCase(pstrOBID))
                        result.add(liteObject);
                } else if (!StringUtils.isEmpty(pstrUID)) {
                    if (rel.getUid1().equalsIgnoreCase(pstrUID)) {
                        if (!StringUtils.isEmpty(pstrDomainUID)) {
                            if (rel.getUid1().equalsIgnoreCase(pstrUID) && rel.getDomainUid1().equalsIgnoreCase(pstrDomainUID))
                                result.add(liteObject);
                        } else
                            result.add(liteObject);
                    }
                }
            }
        }
        return result;
    }

    public List<LiteObject> getEnd2RelsByProvidedOBIDOrUIDDomainUID(String pstrOBID, String pstrUID, String pstrDomainUID) {
        List<LiteObject> result = new ArrayList<>();
        for (Entry<String, LiteObject> entry : this.entrySet()) {
            LiteObject liteObject = entry.getValue();
            if (liteObject.DataType() == dataType.rel) {
                MetaDataRel rel = liteObject.getREL();
                if (!StringUtils.isEmpty(pstrOBID)) {
                    if (rel.getObid2().equalsIgnoreCase(pstrOBID))
                        result.add(liteObject);
                } else if (!StringUtils.isEmpty(pstrUID)) {
                    if (rel.getUid2().equalsIgnoreCase(pstrUID)) {
                        if (!StringUtils.isEmpty(pstrDomainUID)) {
                            if (rel.getUid2().equalsIgnoreCase(pstrUID) && rel.getDomainUid2().equalsIgnoreCase(pstrDomainUID))
                                result.add(liteObject);
                        } else
                            result.add(liteObject);
                    }
                }
            }
        }
        return result;
    }

    public List<LiteObject> getRelsByProvidedOBIDOrUIDDomainUID(String pstrOBID, String pstrUID, String pstrDomainUID) {
        List<LiteObject> result = new ArrayList<>();
        for (Entry<String, LiteObject> entry : this.entrySet()) {
            LiteObject liteObject = entry.getValue();
            if (liteObject.DataType() == dataType.rel) {
                MetaDataRel rel = liteObject.getREL();
                if (!StringUtils.isEmpty(pstrOBID)) {
                    if (rel.getObid1().equalsIgnoreCase(pstrOBID) || rel.getObid2().equalsIgnoreCase(pstrOBID))
                        result.add(liteObject);
                } else if (!StringUtils.isEmpty(pstrUID)) {
                    if (rel.getUid1().equalsIgnoreCase(pstrUID) || rel.getUid2().equalsIgnoreCase(pstrUID)) {
                        if (!StringUtils.isEmpty(pstrDomainUID)) {
                            if (rel.getUid1().equalsIgnoreCase(pstrUID) && rel.getDomainUid1().equalsIgnoreCase(pstrDomainUID))
                                result.add(liteObject);
                            else if (rel.getUid2().equalsIgnoreCase(pstrUID) && rel.getDomainUid2().equalsIgnoreCase(pstrDomainUID))
                                result.add(liteObject);
                        } else
                            result.add(liteObject);
                    }
                }
            }
        }
        return result;
    }

    protected List<LiteObject> toList() {
        return new ArrayList<>(this.values());
    }

    public void refreshUserInfo(LiteObject liteObject) {
        if (liteObject != null) {
            liteObject.refreshUserInfo(this.userName);
        }
    }

    public void add(LiteObject liteObject) {
        if (liteObject != null) {
            this.refreshUserInfo(liteObject);
            super.put(liteObject.globalUniqueCode(), liteObject);
        }
    }
}
