package ccm.server.models;

import ccm.server.convert.impl.ValueConvertService;
import ccm.server.entity.*;
import ccm.server.enums.*;
import ccm.server.helper.HardCodeHelper;
import ccm.server.models.info.InfoIFAndPRDetail;
import ccm.server.util.CommonUtility;
import ccm.server.util.ISharedCommon;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Data
@Slf4j
public class LiteObject {
    private final MetaDataObj OBJ;
    private final MetaDataRel REL;
    private final ConcurrentHashMap<String, List<MetaDataObjProperty>> PROPERTIES = new ConcurrentHashMap<>();
    private final List<MetaDataObjInterface> INTERFACES = new ArrayList<>();
    private final ConcurrentHashMap<String, List<MetaDataRel>> END1RELATIONSHIPS = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, List<MetaDataRel>> END2RELATIONSHIPS = new ConcurrentHashMap<>();
    private final List<MetaDataObjProperty> toBeTerminatedProperties = new ArrayList<>();
    private final List<MetaDataRel> toBeTerminatedRelationships = new ArrayList<>();
    private final List<MetaDataObjInterface> toBeTerminatedInterfaces = new ArrayList<>();

    private final static String PREFIX_INTERFACE = "interface" + ISharedCommon.UNDER_SCOPE;
    private final static String PREFIX_PROPERTY = "property" + ISharedCommon.UNDER_SCOPE;
    private final static String SUFFIX_OBID = "obid";
    private final static String INTERFACE_IDENTITY = "interfaceDefUid";
    private final static String PROPERTY_IDENTITY = "propertyDefUid";

    public void fillWithMapList(List<Map<String, Object>> source) {
        if (CommonUtility.hasValue(source)) {
            for (Map<String, Object> objectMap : source) {
                this.tryToAddInterface(objectMap.getOrDefault(PREFIX_INTERFACE + INTERFACE_IDENTITY, null), objectMap);
                this.tryToAddProperty(objectMap.getOrDefault(PREFIX_INTERFACE + INTERFACE_IDENTITY, null), objectMap.getOrDefault(PREFIX_PROPERTY + PROPERTY_IDENTITY, null), objectMap);
            }
        }
    }

    public void fillWithInfoDetail(List<InfoIFAndPRDetail> infoIFAndPRDetails) {
        if (infoIFAndPRDetails != null && infoIFAndPRDetails.size() > 0) {
            String obid = this.getOBID();
            for (InfoIFAndPRDetail infoIFAndPRDetail : infoIFAndPRDetails) {
                if (infoIFAndPRDetail.getInterfaceObjObid().equalsIgnoreCase(obid)) {
                    this.tryToAddInterface(infoIFAndPRDetail.getInterfaceObid(), infoIFAndPRDetail.getInterfaceObjObid(), infoIFAndPRDetail.getInterfaceInterfaceDefUid(), infoIFAndPRDetail.getInterfaceCreationDate(), infoIFAndPRDetail.getInterfaceCreationUser(), infoIFAndPRDetail.getInterfaceTerminationDate(), infoIFAndPRDetail.getInterfaceTerminationUser());
                    this.tryToAddProperty(infoIFAndPRDetail.getPropertyPropertyDefUid(), infoIFAndPRDetail.getPropertyObid(), infoIFAndPRDetail.getPropertyObjObid(), infoIFAndPRDetail.getPropertyInterfaceObid(), infoIFAndPRDetail.getPropertyInterfaceDefUid(), infoIFAndPRDetail.getPropertyStrValue(), infoIFAndPRDetail.getPropertyUom(), infoIFAndPRDetail.getPropertyCreationUser(), infoIFAndPRDetail.getPropertyCreationDate(), infoIFAndPRDetail.getPropertyTerminationUser(), infoIFAndPRDetail.getPropertyTerminationDate());
                }
            }
        }
    }

    private void tryToAddProperty(String propertyDefUid, String propertyObid, String propertyObjObid, String propertyInterfaceObid, String propertyInterfaceDefUid, String propertyStrValue, String propertyUom, String propertyCreationUser, String propertyCreationDate, String propertyTerminationUser, String propertyTerminationDate) {
        if (!StringUtils.isEmpty(propertyDefUid) && !StringUtils.isEmpty(propertyObid) && !this.hasProperty(propertyDefUid)) {
            MetaDataObjProperty metaDataObjProperty = new MetaDataObjProperty();
            metaDataObjProperty.setTerminationUser(propertyTerminationUser);
            metaDataObjProperty.setObjObid(propertyObjObid);
            metaDataObjProperty.setCreationUser(propertyCreationUser);
            metaDataObjProperty.setTerminationDate(ValueConvertService.Instance.DateTime(propertyTerminationDate));
            metaDataObjProperty.setCreationDate(ValueConvertService.Instance.DateTime(propertyCreationDate));
            metaDataObjProperty.setObid(propertyObid);
            metaDataObjProperty.setPropertyDefUid(propertyDefUid);
            metaDataObjProperty.setInterfaceDefUid(propertyInterfaceDefUid);
            metaDataObjProperty.setInterfaceObid(propertyInterfaceObid);
            metaDataObjProperty.setStrValue(propertyStrValue);
            metaDataObjProperty.setUom(propertyUom);
            metaDataObjProperty.setUpdateState(propertyValueUpdateState.none);
            this.collectProperty(metaDataObjProperty);
        }
    }

    private void tryToAddProperty(Object interfaceDef, Object key, Map<String, Object> objectMap) {
        if (interfaceDef != null && key != null && objectMap != null) {
            if (!this.hasProperty(key.toString())) {
                MetaDataObjProperty metaDataObjProperty = new MetaDataObjProperty();
                metaDataObjProperty.setPropertyDefUid(key.toString());
                metaDataObjProperty.setObjObid(this.getOBID());
                metaDataObjProperty.setObid(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "obid").toString());
                metaDataObjProperty.setUom(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "uom").toString());
                metaDataObjProperty.setStrValue(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "strValue").toString());
                metaDataObjProperty.setInterfaceObid(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "interfaceObid").toString());
                metaDataObjProperty.setInterfaceDefUid(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "interfaceDefUid").toString());
                metaDataObjProperty.setCreationUser(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "creationUser").toString());
                metaDataObjProperty.setTerminationUser(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "terminationUser").toString());
                metaDataObjProperty.setTerminationDate(ValueConvertService.Instance.DateTime(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "terminationDate")));
                metaDataObjProperty.setTerminationDate(ValueConvertService.Instance.DateTime(CommonUtility.getMapValue(objectMap, PREFIX_PROPERTY + "creationDate")));
                this.collectProperty(metaDataObjProperty);
            }
        }
    }

    private void tryToAddInterface(Object key, Map<String, Object> objectMap) {
        if (key != null && !StringUtils.isEmpty(key.toString()) && objectMap != null) {
            if (!this.hasInterface(key.toString())) {
                MetaDataObjInterface metaDataObjInterface = new MetaDataObjInterface();
                metaDataObjInterface.setInterfaceDefUid(key.toString());
                metaDataObjInterface.setObjObid(this.getOBID());
                metaDataObjInterface.setObid(CommonUtility.getMapValue(objectMap, PREFIX_INTERFACE + "obid").toString());
                metaDataObjInterface.setUpdateState(interfaceUpdateState.none);
                metaDataObjInterface.setCreationUser(CommonUtility.getMapValue(objectMap, PREFIX_INTERFACE + "creationUser").toString());
                metaDataObjInterface.setTerminationUser(CommonUtility.getMapValue(objectMap, PREFIX_INTERFACE + "terminationUser").toString());
                metaDataObjInterface.setTerminationDate(ValueConvertService.Instance.DateTime(CommonUtility.getMapValue(objectMap, PREFIX_INTERFACE + "terminationDate")));
                metaDataObjInterface.setTerminationDate(ValueConvertService.Instance.DateTime(CommonUtility.getMapValue(objectMap, PREFIX_INTERFACE + "creationDate")));
                this.collectInterface(metaDataObjInterface);
            }
        }
    }

    protected void tryToAddInterface(String interfaceObid, String interfaceObjObid, String interfaceDefUid, String interfaceCreationDate, String interfaceCreationUser, String interfaceTerminationDate, String interfaceTerminationUser) {
        if (!StringUtils.isEmpty(interfaceDefUid) && !StringUtils.isEmpty(interfaceObid) && !this.hasInterface(interfaceDefUid)) {
            MetaDataObjInterface metaDataObjInterface = new MetaDataObjInterface();
            metaDataObjInterface.setInterfaceDefUid(interfaceDefUid);
            metaDataObjInterface.setObjObid(interfaceObjObid);
            metaDataObjInterface.setObid(interfaceObid);
            metaDataObjInterface.setTerminationDate(ValueConvertService.Instance.DateTime(interfaceTerminationDate));
            metaDataObjInterface.setCreationDate(ValueConvertService.Instance.DateTime(interfaceCreationDate));
            metaDataObjInterface.setTerminationUser(interfaceTerminationUser);
            metaDataObjInterface.setCreationUser(interfaceCreationUser);
            metaDataObjInterface.setUpdateState(interfaceUpdateState.none);
            this.collectInterface(metaDataObjInterface);
        }
    }

    public void setDateForMeta(Date date) {
        if (this.OBJ != null) {
            this.OBJ.setDateForMeta(date);
        } else if (this.REL != null) {
            this.REL.setDateForMeta(date);
        }
        if (this.PROPERTIES.size() > 0) {
            for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : this.PROPERTIES.entrySet()) {
                for (MetaDataObjProperty objProperty : listEntry.getValue()) {
                    objProperty.setDateForMeta(date);
                }
            }
        }

        if (this.INTERFACES.size() > 0) {
            for (MetaDataObjInterface anInterface : this.INTERFACES) {
                anInterface.setDateForMeta(date);
            }
        }
    }

    public objectUpdateState getObjectUpdateState() {
        if (this.REL != null)
            return this.REL.getUpdateState();
        else if (this.OBJ != null)
            return this.OBJ.getUpdateState();
        return null;
    }

    public void setObjectUpdateState(objectUpdateState objectUpdateState) {
        if (objectUpdateState != null) {
            objectUpdateState currentState = this.ObjectUpdateState();
            if (!(currentState == ccm.server.enums.objectUpdateState.deleted || currentState == ccm.server.enums.objectUpdateState.created || currentState == ccm.server.enums.objectUpdateState.terminated)) {
                if (this.OBJ != null)
                    this.OBJ.setUpdateState(objectUpdateState);
                else if (this.REL != null)
                    this.REL.setUpdateState(objectUpdateState);
            }
        }
    }

    public objectUpdateState ObjectUpdateState() {
        if (this.OBJ != null)
            return this.OBJ.getUpdateState();
        else if (this.REL != null)
            return this.REL.getUpdateState();
        return null;
    }

    public String getPropertyOBID(String propertyDefUID) {
        if (!StringUtils.isEmpty(propertyDefUID)) {
            MetaDataObjProperty property = this.getProperty(propertyDefUID);
            if (property != null)
                return property.getObid();
        }
        return null;
    }

    public void setTablePrefix(String tablePrefix) {
        if (this.getREL() != null)
            this.getREL().setTablePrefix(tablePrefix);
        if (this.getOBJ() != null)
            this.getOBJ().setTablePrefix(tablePrefix);
        if (this.getINTERFACES().size() > 0)
            this.getINTERFACES().forEach(c -> c.setTablePrefix(tablePrefix));
        if (this.getPROPERTIES().size() > 0) {
            for (Map.Entry<String, List<MetaDataObjProperty>> entry : this.getPROPERTIES().entrySet()) {
                for (MetaDataObjProperty objProperty : entry.getValue()) {
                    objProperty.setTablePrefix(tablePrefix);
                }
            }
        }
        if (this.getEND1RELATIONSHIPS().size() > 0) {
            for (Map.Entry<String, List<MetaDataRel>> listEntry : this.getEND1RELATIONSHIPS().entrySet()) {
                for (MetaDataRel dataRel : listEntry.getValue()) {
                    dataRel.setTablePrefix(tablePrefix);
                }
            }
        }
        if (this.getEND2RELATIONSHIPS().size() > 0) {
            for (Map.Entry<String, List<MetaDataRel>> listEntry : this.getEND2RELATIONSHIPS().entrySet()) {
                for (MetaDataRel dataRel : listEntry.getValue()) {
                    dataRel.setTablePrefix(tablePrefix);
                }
            }
        }
    }

    public void refreshUserInfo(String userName) {
        if (!StringUtils.isEmpty(userName)) {
            if (this.getOBJ() != null) {
                this.getOBJ().refreshUserInfo(userName);
            }
            if (this.getREL() != null) {
                this.getREL().refreshUserInfo(userName);
            }
            if (this.INTERFACES.size() > 0) {
                for (MetaDataObjInterface anInterface : this.INTERFACES) {
                    anInterface.refreshUserInfo(userName);
                }
            }

            if (this.PROPERTIES.size() > 0) {
                for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : this.PROPERTIES.entrySet()) {
                    for (MetaDataObjProperty metaDataObjProperty : listEntry.getValue()) {
                        metaDataObjProperty.refreshUserInfo(userName);
                    }
                }
            }

        }
    }

    public String globalUniqueCode() {
        if (this.OBJ != null)
            return this.getOBJ().getObid();
        else if (this.REL != null)
            return this.REL.toString();
        return UUID.randomUUID().toString();
    }

    public dataType DataType() {
        if (this.getClassDefinitionUid().equalsIgnoreCase(HardCodeHelper.CLASSDEF_REL))
            return dataType.rel;
        return dataType.data;
    }

    public List<MetaDataRel> relationships1() {
        List<MetaDataRel> result = new ArrayList<>();
        for (Map.Entry<String, List<MetaDataRel>> stringListEntry : this.END1RELATIONSHIPS.entrySet()) {
            result.addAll(stringListEntry.getValue());
        }
        return result;
    }

    public List<MetaDataRel> relationships2() {
        List<MetaDataRel> result = new ArrayList<>();
        for (Map.Entry<String, List<MetaDataRel>> stringListEntry : this.END2RELATIONSHIPS.entrySet()) {
            result.addAll(stringListEntry.getValue());
        }
        return result;
    }

    public List<MetaDataObjProperty> properties() {
        List<MetaDataObjProperty> result = new ArrayList<>();
        for (Map.Entry<String, List<MetaDataObjProperty>> stringListEntry : this.PROPERTIES.entrySet()) {
            if (CommonUtility.hasValue(stringListEntry.getValue()))
                result.addAll(stringListEntry.getValue());
        }
        return result;
    }

    public void setOBID() {
        String obid = null;
        String objUID = null;
        String domainUID = null;
        if (this.OBJ != null) {
            obid = this.OBJ.getObid();
            objUID = this.OBJ.getObjUid();
            domainUID = this.OBJ.getDomainUid();
        } else if (this.REL != null) {
            obid = this.REL.getObid();
            objUID = this.REL.getObjUid();
            domainUID = this.REL.getDomainUid();
        }
        if (CommonUtility.hasValue(this.INTERFACES)) {
            String finalObid1 = obid;
            this.INTERFACES.forEach(c -> c.setObjObid(finalObid1));
        }

        if (CommonUtility.hasValue(this.PROPERTIES)) {
            String finalObid = obid;
            for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : this.PROPERTIES.entrySet()) {
                MetaDataObjInterface anInterface = this.getInterface(listEntry.getKey());
                if (anInterface != null) {
                    listEntry.getValue().forEach(c -> {
                        c.setInterfaceObid(anInterface.getObid());
                        c.setInterfaceDefUid(anInterface.getInterfaceDefUid());
                        c.setObjObid(finalObid);
                    });
                }
            }
        }

        if (CommonUtility.hasValue(this.END1RELATIONSHIPS)) {
            for (Map.Entry<String, List<MetaDataRel>> listEntry : this.END1RELATIONSHIPS.entrySet()) {
                for (MetaDataRel dataRel : listEntry.getValue()) {
                    dataRel.setUid1(objUID);
                    dataRel.setObid1(obid);
                    dataRel.setDomainUid1(domainUID);
                    dataRel.setDomainUid(domainUID);
                }
            }
        }
        if (CommonUtility.hasValue(this.END2RELATIONSHIPS)) {
            for (Map.Entry<String, List<MetaDataRel>> listEntry : this.END2RELATIONSHIPS.entrySet()) {
                for (MetaDataRel dataRel : listEntry.getValue()) {
                    dataRel.setUid2(objUID);
                    dataRel.setObid2(obid);
                    dataRel.setDomainUid2(domainUID);
                }
            }
        }
    }

    public int OrderValue() {
        if (this.getREL() != null)
            return this.getREL().getOrderValue();
        String value = this.getValue(propertyDefinitionType.OrderValue.toString());
        return Integer.parseInt(value);
    }

    public boolean isRequired() {
        if (this.getREL() != null)
            return this.getREL().getIsRequired() != 0;
        String value = this.getValue(propertyDefinitionType.IsRequired.toString());
        return Boolean.parseBoolean(value);
    }

    public String getPrefix() {
        if (this.REL != null)
            return this.REL.getPrefix();
        return "";
    }

    public String UID1() {
        if (this.REL != null)
            return this.REL.getUid1();
        return "";
    }

    public String UID2() {
        if (this.REL != null)
            return this.REL.getUid2();
        return "";
    }

    public String OBID1() {
        if (this.REL != null)
            return this.REL.getObid1();
        return "";
    }

    public String OBID2() {
        if (this.REL != null)
            return this.REL.getObid2();
        return "";
    }

    public String Name1() {
        if (this.REL != null)
            return this.REL.getName1();
        return "";
    }

    public String Name2() {
        if (this.REL != null)
            return this.REL.getName2();
        return "";
    }

    public String RelDefUID() {
        if (this.REL != null)
            return this.REL.getRelDefUid();
        return "";
    }

    public void collectInterface(MetaDataObjInterface metaDataObjInterface) {
        if (metaDataObjInterface != null) {
            this.getINTERFACES().add(metaDataObjInterface);
        }
    }

    public void setInterface(MetaDataObjInterface metaDataObjInterface) {
        if (metaDataObjInterface != null && metaDataObjInterface.getObjObid().equalsIgnoreCase(this.getOBID())) {
            MetaDataObjInterface objInterface = this.getInterface(metaDataObjInterface.getInterfaceDefUid());
            if (objInterface == null) {
                if (metaDataObjInterface.getTerminationDate() != null && metaDataObjInterface.fromDb()) {
                    metaDataObjInterface.setUpdateState(interfaceUpdateState.terminated);
                    this.toBeTerminatedInterfaces.add(metaDataObjInterface);
                } else
                    this.getINTERFACES().add(metaDataObjInterface);
            } else {
                if (objInterface.getObid().equalsIgnoreCase(metaDataObjInterface.getObid()) && metaDataObjInterface.fromDb() && objInterface.fromDb()) {
                    if (metaDataObjInterface.getTerminationDate() != null) {
                        objInterface.setUpdateState(interfaceUpdateState.terminated);
                        this.toBeTerminatedInterfaces.add(objInterface);
                        this.removeInterface(metaDataObjInterface.getInterfaceDefUid());
                    }
                } else {
                    if (objInterface.fromDb()) {
                        objInterface.setUpdateState(interfaceUpdateState.terminated);
                        this.toBeTerminatedInterfaces.add(objInterface);
                    }
                    this.removeInterface(metaDataObjInterface.getInterfaceDefUid());
                    if (metaDataObjInterface.getTerminationDate() == null)
                        this.getINTERFACES().add(metaDataObjInterface);
                }
            }
        }
    }

    public void merge(LiteObject liteObject) {
        if (liteObject != null) {
            List<MetaDataObjInterface> interfaces = liteObject.getINTERFACES();
            if (CommonUtility.hasValue(interfaces)) {
                this.INTERFACES.addAll(interfaces);
            }
            ConcurrentHashMap<String, List<MetaDataObjProperty>> properties = liteObject.getPROPERTIES();
            if (CommonUtility.hasValue(properties)) {
                for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : properties.entrySet()) {
                    List<MetaDataObjProperty> propertyList = this.PROPERTIES.getOrDefault(listEntry.getKey(), new ArrayList<>());
                    propertyList.addAll(listEntry.getValue());
                    if (this.PROPERTIES.containsKey(listEntry.getKey()))
                        this.PROPERTIES.replace(listEntry.getKey(), propertyList);
                    else
                        this.PROPERTIES.put(listEntry.getKey(), propertyList);
                }
            }

            ConcurrentHashMap<String, List<MetaDataRel>> end1RELATIONSHIPS = liteObject.getEND1RELATIONSHIPS();
            if (CommonUtility.hasValue(end1RELATIONSHIPS)) {
                for (Map.Entry<String, List<MetaDataRel>> listEntry : end1RELATIONSHIPS.entrySet()) {
                    List<MetaDataRel> relList = this.END1RELATIONSHIPS.getOrDefault(listEntry.getKey(), new ArrayList<>());
                    relList.addAll(listEntry.getValue());
                    if (this.END1RELATIONSHIPS.containsKey(listEntry.getKey()))
                        this.END1RELATIONSHIPS.replace(listEntry.getKey(), relList);
                    else
                        this.END1RELATIONSHIPS.put(listEntry.getKey(), relList);
                }
            }

            ConcurrentHashMap<String, List<MetaDataRel>> end2RELATIONSHIPS = liteObject.getEND2RELATIONSHIPS();
            if (CommonUtility.hasValue(end2RELATIONSHIPS)) {
                for (Map.Entry<String, List<MetaDataRel>> listEntry : end2RELATIONSHIPS.entrySet()) {
                    List<MetaDataRel> relList = this.END2RELATIONSHIPS.getOrDefault(listEntry.getKey(), new ArrayList<>());
                    relList.addAll(listEntry.getValue());
                    if (this.END2RELATIONSHIPS.containsKey(listEntry.getKey()))
                        this.END2RELATIONSHIPS.replace(listEntry.getKey(), relList);
                    else
                        this.END2RELATIONSHIPS.put(listEntry.getKey(), relList);
                }
            }
        }
    }

    public void setWithLiteObject(LiteObject liteObject) {
        if (liteObject != null && liteObject.getOBID().equalsIgnoreCase(this.getOBID())) {
            for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : liteObject.getPROPERTIES().entrySet()) {
                for (MetaDataObjProperty objProperty : listEntry.getValue()) {
                    this.setProperty(objProperty);
                }
            }
            for (MetaDataObjInterface anInterface : liteObject.getINTERFACES()) {
                this.setInterface(anInterface);
            }

            for (Map.Entry<String, List<MetaDataRel>> stringListEntry : liteObject.getEND1RELATIONSHIPS().entrySet()) {
                for (MetaDataRel metaDataRel : stringListEntry.getValue()) {
                    this.addEnd1Relationship(metaDataRel);
                }
            }

            for (Map.Entry<String, List<MetaDataRel>> stringListEntry : liteObject.getEND2RELATIONSHIPS().entrySet()) {
                for (MetaDataRel metaDataRel : stringListEntry.getValue()) {
                    this.addEnd2Relationship(metaDataRel);
                }
            }
        }
    }

    public boolean hasInterface() {
        return CommonUtility.hasValue(this.INTERFACES);
    }

    public boolean hasProperty() {
        return CommonUtility.hasValue(this.PROPERTIES);
    }

    public boolean hasRel1() {
        return CommonUtility.hasValue(this.END1RELATIONSHIPS);
    }

    public boolean hasRel2() {
        return CommonUtility.hasValue(this.END2RELATIONSHIPS);
    }


    public boolean hasInterface(String interfaceDefUid) {
        if (!StringUtils.isEmpty(interfaceDefUid))
            return this.getINTERFACES().stream().anyMatch(c -> c.getInterfaceDefUid().equalsIgnoreCase(interfaceDefUid));
        return false;
    }

    public void removeInterface(String interfaceDefUid) {
        MetaDataObjInterface dataObjInterface = this.getInterface(interfaceDefUid);
        if (dataObjInterface != null) {
            if (dataObjInterface.fromDb())
                this.getToBeTerminatedInterfaces().add(dataObjInterface);
            this.getINTERFACES().remove(dataObjInterface);
        }
    }

    public MetaDataObjInterface getInterface(String interfaceDefUid) {
        if (!StringUtils.isEmpty(interfaceDefUid))
            return this.getINTERFACES().stream().filter(c -> c.getInterfaceDefUid().equalsIgnoreCase(interfaceDefUid)).findFirst().orElse(null);
        return null;
    }

    public <T> LiteObject(T obj) {
        if (obj instanceof MetaDataObj) {
            this.OBJ = (MetaDataObj) obj;
            this.REL = null;
        } else if (obj instanceof MetaDataRel) {
            this.OBJ = null;
            this.REL = (MetaDataRel) obj;
        } else {
            this.OBJ = null;
            this.REL = null;
        }
    }

    public LiteObject(MetaDataObj OBJ) {
        this.OBJ = OBJ;
        this.REL = null;
    }

    public LiteObject(MetaDataRel REL) {
        this.REL = REL;
        this.OBJ = null;
    }

    public String getName() {
        if (this.getOBJ() != null)
            return this.getOBJ().getName();
        return "";
    }

    public String getOBID() {
        if (this.getREL() != null)
            return this.getREL().getObid();
        if (this.getOBJ() != null)
            return this.getOBJ().getObid();
        return "";
    }

    public String getClassDefinitionUid() {
        if (this.getOBJ() != null)
            return this.getOBJ().getClassDefinitionUid();
        if (this.getREL() != null)
            return HardCodeHelper.CLASSDEF_REL;
        return "";
    }

    public String getDomainUID() {
        if (this.getOBJ() != null)
            return this.getOBJ().getDomainUid();
        else if (this.getREL() != null)
            return this.getREL().getDomainUid();
        return "";
    }

    public Date getCreationDate() {
        if (this.OBJ != null && this.OBJ.getCreationDate() != null)
            return this.OBJ.getCreationDate();
        else if (this.REL != null && this.REL.getCreationDate() != null)
            return this.REL.getCreationDate();
        return null;
    }

    public String getCreationUser() {
        if (this.OBJ != null)
            return this.OBJ.getCreationUser();
        if (this.REL != null)
            return this.REL.getCreationUser();
        return "";
    }

    public String getLastUpdateUser() {
        if (this.OBJ != null)
            return this.OBJ.getLastUpdateUser();
        return "";
    }

    public Date getLastUpdateDate() {
        if (this.OBJ != null && this.OBJ.getLastUpdateDate() != null)
            return this.OBJ.getLastUpdateDate();
        return null;
    }

    public Date getTerminationDate() {
        if (this.OBJ != null && this.OBJ.getTerminationDate() != null)
            return this.OBJ.getTerminationDate();
        if (this.REL != null && this.getREL().getTerminationDate() != null)
            return this.REL.getTerminationDate();
        return null;
    }

    public String getTerminationUser() {
        if (this.OBJ != null)
            return this.OBJ.getTerminationUser();
        if (this.REL != null)
            return this.REL.getTerminationUser();
        return "";
    }


    public String getConfig() {
        if (this.getOBJ() != null)
            return this.getOBJ().getConfig();
        else if (this.getREL() != null)
            return this.getREL().getConfig();
        return "";
    }

    public String getDescription() {
        if (this.getOBJ() != null)
            return this.getOBJ().getDescription();
        return "";
    }

    public String getObjUID() {
        if (this.getOBJ() != null)
            return this.getOBJ().getObjUid();
        else if (this.getREL() != null)
            return this.getREL().getObjUid();
        return "";
    }

    public String getUniqueKey() {
        return this.getOBJ() != null ? this.getOBJ().getUniqueKey() : "";
    }

    public boolean hasProperty(String propertyDefUid) {
        if (!StringUtils.isEmpty(propertyDefUid)) {
            for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : this.PROPERTIES.entrySet()) {
                for (MetaDataObjProperty objProperty : listEntry.getValue()) {
                    if (objProperty.getPropertyDefUid().equalsIgnoreCase(propertyDefUid))
                        return true;
                }
            }
        }
        return false;
    }

    public void removeProperty(String propertyDefUid) {
        if (!StringUtils.isEmpty(propertyDefUid)) {
            MetaDataObjProperty property = this.getProperty(propertyDefUid);
            if (property != null) {
                for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : this.PROPERTIES.entrySet()) {
                    listEntry.getValue().remove(property);
                }
                if (property.fromDb())
                    this.getToBeTerminatedProperties().add(property);
            }
        }
    }

    public String getValue(String propertyDefUid) {
        MetaDataObjProperty property = this.getProperty(propertyDefUid);
        if (property != null)
            return property.getStrValue();
        return "";
    }

    public MetaDataObjProperty getProperty(String propertyDefUid) {
        if (!StringUtils.isEmpty(propertyDefUid)) {
            for (Map.Entry<String, List<MetaDataObjProperty>> listEntry : this.PROPERTIES.entrySet()) {
                for (MetaDataObjProperty objProperty : listEntry.getValue()) {
                    if (objProperty.getPropertyDefUid().equalsIgnoreCase(propertyDefUid))
                        return objProperty;
                }
            }
        }
        return new MetaDataObjProperty();
    }

    public void collectProperty(MetaDataObjProperty metaDataObjProperty) {
        if (metaDataObjProperty != null) {
            String interfaceDefUID = metaDataObjProperty.getInterfaceDefUid();
            if (this.getPROPERTIES().containsKey(interfaceDefUID)) {
                List<MetaDataObjProperty> properties = this.getPROPERTIES().get(interfaceDefUID);
                properties.add(metaDataObjProperty);
                this.getPROPERTIES().replace(interfaceDefUID, properties);
            } else {
                List<MetaDataObjProperty> tempCollection = new ArrayList<>();
                tempCollection.add(metaDataObjProperty);
                this.getPROPERTIES().put(interfaceDefUID, tempCollection);
            }
        }
    }

    public void setProperty(MetaDataObjProperty metaDataObjProperty) {
        if (metaDataObjProperty != null && metaDataObjProperty.getObjObid().equalsIgnoreCase(this.getOBID())) {
            if (this.hasProperty(metaDataObjProperty.getPropertyDefUid())) {
                MetaDataObjProperty property = this.getProperty(metaDataObjProperty.getPropertyDefUid());
                if (property.getObid().equalsIgnoreCase(metaDataObjProperty.getObid())) {
                    if (metaDataObjProperty.getTerminationDate() != null && property.fromDb()) {
                        property.setUpdateState(propertyValueUpdateState.terminated);
                        this.toBeTerminatedProperties.add(property);
                    }
                }
                if (property.fromDb()) {
                    property.setUpdateState(propertyValueUpdateState.terminated);
                    this.getToBeTerminatedProperties().add(property);
                }
                this.removeProperty(metaDataObjProperty.getPropertyDefUid());
            }
            if (this.getPROPERTIES().containsKey(metaDataObjProperty.getInterfaceDefUid())) {
                List<MetaDataObjProperty> dataObjProperties = this.getPROPERTIES().get(metaDataObjProperty.getInterfaceDefUid());
                dataObjProperties.add(metaDataObjProperty);
                this.getPROPERTIES().replace(metaDataObjProperty.getInterfaceDefUid(), dataObjProperties);
            } else {
                List<MetaDataObjProperty> collections = new ArrayList<>();
                collections.add(metaDataObjProperty);
                this.getPROPERTIES().putIfAbsent(metaDataObjProperty.getInterfaceDefUid(), collections);
            }

        }
    }

    public boolean hasRelDef1(String relDef) {
        if (!StringUtils.isEmpty(relDef)) {
            if (this.getEND1RELATIONSHIPS().containsKey(relDef))
                return CommonUtility.hasValue(this.getEND1RELATIONSHIPS().get(relDef));
            else {
                String existRelDef = this.getEND1RELATIONSHIPS().keySet().stream().filter(c -> c.equalsIgnoreCase(relDef)).findAny().orElse("");
                if (!StringUtils.isEmpty(existRelDef))
                    return CommonUtility.hasValue(this.getEND1RELATIONSHIPS().get(existRelDef));
            }
        }
        return false;
    }

    public boolean hasRelDef2(String relDef) {
        if (!StringUtils.isEmpty(relDef)) {
            if (this.getEND2RELATIONSHIPS().containsKey(relDef))
                return CommonUtility.hasValue(this.getEND2RELATIONSHIPS().get(relDef));
            else {
                String existRelDef = this.getEND2RELATIONSHIPS().keySet().stream().filter(c -> c.equalsIgnoreCase(relDef)).findAny().orElse("");
                if (!StringUtils.isEmpty(existRelDef))
                    return CommonUtility.hasValue(this.getEND2RELATIONSHIPS().get(existRelDef));
            }
        }
        return false;
    }

    public boolean hasRelDef(String relDef) {
        return this.hasRelDef1(relDef) || this.hasRelDef2(relDef);
    }

    public boolean hasRelationship1(MetaDataRel rel) {
        if (rel != null) {
            List<MetaDataRel> end1Relationships = this.getEnd1Relationships(rel.getRelDefUid());
            if (CommonUtility.hasValue(end1Relationships))
                return end1Relationships.stream().filter(c -> c.toString().equalsIgnoreCase(rel.toString())).findAny().orElse(null) != null;
        }
        return false;
    }

    public boolean hasRelationship2(MetaDataRel rel) {
        if (rel != null) {
            List<MetaDataRel> end2Relationships = this.getEnd2Relationships(rel.getRelDefUid());
            if (CommonUtility.hasValue(end2Relationships))
                return end2Relationships.stream().filter(c -> c.toString().equalsIgnoreCase(rel.toString())).findAny().orElse(null) != null;
        }
        return false;
    }

    public MetaDataRel getRelationship1(MetaDataRel rel) {
        if (rel != null) {
            List<MetaDataRel> relationships = this.getEnd1Relationships(rel.getRelDefUid());
            if (CommonUtility.hasValue(relationships)) {
                return relationships.stream().filter(c -> c.toString().equalsIgnoreCase(rel.toString())).findAny().orElse(null);
            }
        }
        return null;
    }

    public MetaDataRel getRelationship2(MetaDataRel rel) {
        if (rel != null) {
            List<MetaDataRel> relationships = this.getEnd2Relationships(rel.getRelDefUid());
            if (CommonUtility.hasValue(relationships)) {
                return relationships.stream().filter(c -> c.toString().equalsIgnoreCase(rel.toString())).findAny().orElse(null);
            }
        }
        return null;
    }

    public boolean hasRelationship(MetaDataRel rel) {
        if (rel != null)
            return this.hasRelationship1(rel) || this.hasRelationship2(rel);
        return false;
    }

    public MetaDataRel getEnd1Relationship(String relDef) {
        if (!StringUtils.isEmpty(relDef)) {
            List<MetaDataRel> metaDataRels = this.getEND1RELATIONSHIPS().getOrDefault(relDef, null);
            if (metaDataRels != null) {
                String finalRelDef = relDef;
                relDef = this.getEND1RELATIONSHIPS().keySet().stream().filter(c -> c.equalsIgnoreCase(finalRelDef)).findAny().orElse("");
                metaDataRels = this.getEND1RELATIONSHIPS().getOrDefault(relDef, new ArrayList<>());
            }
            if (CommonUtility.hasValue(metaDataRels))
                return metaDataRels.get(0);
        }
        return null;
    }

    public List<MetaDataRel> getEnd1Relationships(String relDef) {
        if (!StringUtils.isEmpty(relDef)) {
            List<MetaDataRel> metaDataRels = this.getEND1RELATIONSHIPS().getOrDefault(relDef, null);
            if (metaDataRels != null) {
                String finalRelDef = relDef;
                relDef = this.getEND1RELATIONSHIPS().keySet().stream().filter(c -> c.equalsIgnoreCase(finalRelDef)).findAny().orElse("");
                return this.getEND1RELATIONSHIPS().getOrDefault(relDef, new ArrayList<>());
            }
        }
        return new ArrayList<>();
    }

    public MetaDataRel getEnd2Relationship(String relDef) {
        if (!StringUtils.isEmpty(relDef)) {
            List<MetaDataRel> metaDataRels = this.getEND2RELATIONSHIPS().getOrDefault(relDef, null);
            if (metaDataRels != null) {
                String finalRelDef = relDef;
                relDef = this.getEND2RELATIONSHIPS().keySet().stream().filter(c -> c.equalsIgnoreCase(finalRelDef)).findAny().orElse("");
                metaDataRels = this.getEND2RELATIONSHIPS().getOrDefault(relDef, new ArrayList<>());
            }
            if (CommonUtility.hasValue(metaDataRels))
                return metaDataRels.get(0);
        }
        return null;
    }

    public List<MetaDataRel> getEnd2Relationships(String relDef) {
        if (!StringUtils.isEmpty(relDef)) {
            List<MetaDataRel> metaDataRels = this.getEND2RELATIONSHIPS().getOrDefault(relDef, null);
            if (metaDataRels != null) {
                String finalRelDef = relDef;
                relDef = this.getEND2RELATIONSHIPS().keySet().stream().filter(c -> c.equalsIgnoreCase(finalRelDef)).findAny().orElse("");
                return this.getEND2RELATIONSHIPS().getOrDefault(relDef, new ArrayList<>());
            }
        }
        return new ArrayList<>();
    }

    public void removeRelationship(MetaDataRel metaDataRel) {
        if (metaDataRel != null) {
            MetaDataRel metaDataRel1 = this.getRelationship1(metaDataRel);
            if (metaDataRel1 != null) {
                if (metaDataRel1.fromDb())
                    this.getToBeTerminatedRelationships().add(metaDataRel);
            }
            MetaDataRel metaDataRel2 = this.getRelationship2(metaDataRel);
            if (metaDataRel2 != null) {
                if (metaDataRel2.fromDb())
                    this.getToBeTerminatedRelationships().add(metaDataRel2);
            }
        }
    }

    public void collectEnd1Relationship(Collection<MetaDataRel> rels) {
        if (CommonUtility.hasValue(rels)) {
            for (MetaDataRel rel : rels)
                this.collectEnd1Relationship(rel);
        }
    }

    public void collectEnd2Relationship(Collection<MetaDataRel> rels) {
        if (CommonUtility.hasValue(rels)) {
            for (MetaDataRel rel : rels)
                this.collectEnd2Relationship(rel);
        }
    }

    public void addEnd1Relationship(Collection<MetaDataRel> rels) {
        if (CommonUtility.hasValue(rels)) {
            for (MetaDataRel rel : rels) {
                this.addEnd1Relationship(rel);
            }
        }
    }

    public void collectEnd1Relationship(MetaDataRel metaDataRel) {
        if (metaDataRel != null) {
            if (!this.getEND1RELATIONSHIPS().containsKey(metaDataRel.getRelDefUid()))
                this.getEND1RELATIONSHIPS().put(metaDataRel.getRelDefUid(), new ArrayList<>());
            List<MetaDataRel> metaDataRels = this.getEND1RELATIONSHIPS().get(metaDataRel.getRelDefUid());
            metaDataRels.add(metaDataRel);
            this.getEND1RELATIONSHIPS().replace(metaDataRel.getRelDefUid(), metaDataRels);
        }
    }

    public void collectEnd2Relationship(MetaDataRel metaDataRel) {
        if (metaDataRel != null) {
            if (!this.getEND2RELATIONSHIPS().containsKey(metaDataRel.getRelDefUid()))
                this.getEND2RELATIONSHIPS().put(metaDataRel.getRelDefUid(), new ArrayList<>());
            List<MetaDataRel> metaDataRels = this.getEND2RELATIONSHIPS().get(metaDataRel.getRelDefUid());
            metaDataRels.add(metaDataRel);
            this.getEND2RELATIONSHIPS().replace(metaDataRel.getRelDefUid(), metaDataRels);
        }
    }

    public void addEnd1Relationship(MetaDataRel metaDataRel) {
        if (metaDataRel != null) {
            MetaDataRel relationship1 = this.getRelationship1(metaDataRel);
            if (relationship1 == null) {
                if (!this.getEND1RELATIONSHIPS().containsKey(metaDataRel.getRelDefUid()))
                    this.getEND1RELATIONSHIPS().put(metaDataRel.getRelDefUid(), new ArrayList<>());
                List<MetaDataRel> metaDataRels = this.getEND1RELATIONSHIPS().get(metaDataRel.getRelDefUid());
                metaDataRels.add(metaDataRel);
                this.getEND1RELATIONSHIPS().replace(metaDataRel.getRelDefUid(), metaDataRels);
            }
        }
    }

    public void addEnd2Relationship(Collection<MetaDataRel> rels) {
        if (CommonUtility.hasValue(rels)) {
            for (MetaDataRel rel : rels) {
                this.addEnd2Relationship(rel);
            }
        }
    }

    public void addEnd2Relationship(MetaDataRel metaDataRel) {
        if (metaDataRel != null) {
            MetaDataRel relationship2 = this.getRelationship2(metaDataRel);
            if (relationship2 == null) {
                if (!this.getEND2RELATIONSHIPS().containsKey(metaDataRel.getRelDefUid()))
                    this.getEND2RELATIONSHIPS().put(metaDataRel.getRelDefUid(), new ArrayList<>());
                List<MetaDataRel> metaDataRels = this.getEND2RELATIONSHIPS().get(metaDataRel.getRelDefUid());
                metaDataRels.add(metaDataRel);
                this.getEND2RELATIONSHIPS().replace(metaDataRel.getRelDefUid(), metaDataRels);
            }
        }
    }

    public List<MetaDataRel> getRelationships(String relDef) {
        List<MetaDataRel> result = new ArrayList<>();
        List<MetaDataRel> end1Relationships = this.getEnd1Relationships(relDef);
        if (CommonUtility.hasValue(end1Relationships))
            result.addAll(end1Relationships);
        List<MetaDataRel> end2Relationships = this.getEnd2Relationships(relDef);
        if (CommonUtility.hasValue(end2Relationships))
            result.addAll(end2Relationships);
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LiteObject that = (LiteObject) o;
        if (this.getOBJ() == null)
            return Objects.equals(this.getREL(), that.getREL());
        else if (this.getREL() == null)
            return Objects.equals(OBJ, that.OBJ);
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(OBJ != null ? OBJ.toString() : "", REL != null ? REL.toString() : "");
    }

    public static List<MetaDataObjInterface> allInterfaces(List<LiteObject> liteObjects) {
        if (CommonUtility.hasValue(liteObjects)) {
            List<MetaDataObjInterface> lcolResult = new ArrayList<>();
            for (LiteObject liteObject : liteObjects) {
                if (liteObject.hasInterface())
                    lcolResult.addAll(liteObject.getINTERFACES());
            }
            return lcolResult;
        }
        return null;
    }

    public static List<MetaDataObjProperty> allProperties(List<LiteObject> liteObjects) {
        if (CommonUtility.hasValue(liteObjects)) {
            List<MetaDataObjProperty> lcolResult = new ArrayList<>();
            for (LiteObject liteObject : liteObjects) {
                if (liteObject.hasProperty())
                    lcolResult.addAll(liteObject.properties());
            }
            return lcolResult;
        }
        return null;
    }

    public static List<MetaDataRel> allRel1s(List<LiteObject> liteObjects) {
        if (CommonUtility.hasValue(liteObjects)) {
            List<MetaDataRel> lcolResult = new ArrayList<>();
            for (LiteObject liteObject : liteObjects) {
                if (liteObject.hasRel1())
                    lcolResult.addAll(liteObject.relationships1());
            }
            return lcolResult;
        }
        return null;
    }

    public static List<MetaDataRel> allRel2s(List<LiteObject> liteObjects) {
        if (CommonUtility.hasValue(liteObjects)) {
            List<MetaDataRel> lcolResult = new ArrayList<>();
            for (LiteObject liteObject : liteObjects) {
                if (liteObject.hasRel2())
                    lcolResult.addAll(liteObject.relationships2());
            }
            return lcolResult;
        }
        return null;
    }

    public static boolean isObjOrRelTableProperty(String propertyDefinitionUID, String classDefinitionUID) {
        if (!StringUtils.isEmpty(propertyDefinitionUID)) {
            List<String> properties = new ArrayList<>();
            if (classDefinitionUID.equalsIgnoreCase(HardCodeHelper.CLASSDEF_REL))
                properties = propertyDefinitionType.RELTableProperties();
            else {
                properties = propertyDefinitionType.OBJTableProperties();
                properties.remove(propertyDefinitionType.Name.toString());
                properties.remove(propertyDefinitionType.Description.toString());
                properties.remove(propertyDefinitionType.ContainerID.toString());
            }
            return properties.contains(propertyDefinitionUID);
        }
        return false;
    }
}
