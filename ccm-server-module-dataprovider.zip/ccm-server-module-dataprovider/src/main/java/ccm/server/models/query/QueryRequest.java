package ccm.server.models.query;

import ccm.server.dto.base.ObjectDTO;
import ccm.server.dto.base.ObjectItemDTO;
import ccm.server.enums.*;
import ccm.server.helper.HardCodeHelper;
import ccm.server.model.LiteCriteria;
import ccm.server.model.OrderByWrapper;
import ccm.server.params.PageRequest;
import ccm.server.util.CommonUtility;
import ccm.server.util.ISharedCommon;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Data
@Slf4j
public class QueryRequest {

    public void setScopePrefix(String value) {
        this.scopePrefix = value;
        // log.info("query request's configuration scope:" + value);
    }

    private String scopePrefix;
    private boolean queryOne = false;
    private QueryMode queryMode = QueryMode.general;
    private ccm.server.enums.joinMode joinMode = ccm.server.enums.joinMode.Inner;
    private PageRequest pageRequest = new PageRequest(0, 0);
    private final List<String> domains = new ArrayList<>();
    private final List<ObjectItemDTO> renderColumns = new ArrayList<>();
    private QueryClassDef queryClassDef;
    private final List<QueryInterface> queryInterface = new ArrayList<>();
    private final List<QueryCriteria> queryCriterions = new ArrayList<>();
    private Boolean queryForRelationship = false;
    private final List<OrderByWrapper> orderByWrappers = new ArrayList<>();
    private final List<String> scopeWisedDomains = new ArrayList<>();

    public QueryCriteria getCriteria(String relOrEdge, String interfaceDef, String propertyDef) {
        if (!StringUtils.isEmpty(relOrEdge) && !StringUtils.isEmpty(propertyDef) && !StringUtils.isEmpty(interfaceDef)) {
            return this.queryCriterions.stream().filter(c -> c.getInterfaceDefinitionUID().equalsIgnoreCase(interfaceDef) && c.getPropertyDefinitionUID().equalsIgnoreCase(propertyDef) && c.getRelOrEdgeDefinitionUID().equalsIgnoreCase(relOrEdge)).findFirst().orElse(null);
        }
        return null;
    }

    public boolean getQueryOne() {
        return this.queryOne;
    }

    public List<String> getTablePrefixes() {
        List<String> result = new ArrayList<>();
        if (CommonUtility.hasValue(this.domains)) {
            List<String> scopePrefixes = this.getScopePrefixes();
            for (String scope : scopePrefixes) {
                for (String domain : this.domains) {
                    if (this.getScopeWisedDomains().contains(domain)) {
                        if (!StringUtils.isEmpty(scope))
                            result.add(scope + ISharedCommon.COMMON_CONNECTOR + domain);
                    } else
                        result.add(domain);
                }
            }
        }
        result = result.stream().distinct().collect(Collectors.toList());
        return result;
    }

    private List<String> getScopePrefixes() {
        List<String> result = new ArrayList<>();
        if (!StringUtils.isEmpty(this.scopePrefix)) {
            String[] prefixes = this.scopePrefix.split(";");
            result.addAll(Arrays.asList(prefixes));
        }
        result.add("");
        return result;
    }

    public void setRenderStyle(ObjectDTO objectDTO) {
        if (objectDTO != null) {
            List<ObjectItemDTO> items = objectDTO.getItems();
            if (CommonUtility.hasValue(items)) {
                this.getRenderColumns().addAll(items);
                this.setQueryMode(QueryMode.lite);
            }
        }
    }

    public void addOrderBy(orderMode orderMode, String definition) {
        if (!StringUtils.isEmpty(definition)) {
            OrderByWrapper order = new OrderByWrapper(orderMode, definition);
            if (!this.orderByWrappers.contains(order))
                this.orderByWrappers.add(order);
        }
    }

    public boolean queryByClassDefinition() {
        return this.queryClassDef != null;
    }

    public static boolean useJoinQuery(QueryRequest queryRequest) {
        boolean result = false;
        if (queryRequest != null) {
            if (queryRequest.useInterface())
                result = true;
            else if (queryRequest.useRelationship())
                result = true;
            else if (queryRequest.useAdvanceProperty())
                result = true;
        }
        return result;
    }

    public Map<String, String> getRelDefUids() {
        Map<String, String> result = new HashMap<>();
        if (this.queryForRelationship) {
            for (QueryCriteria criteria : this.getQueryCriterions()) {
                if (!StringUtils.isEmpty(criteria.getRelOrEdgeDefinitionUID())) {
                    String relDef = CommonUtility.toActualDefinition(criteria.getRelOrEdgeDefinitionUID());
                    if (!StringUtils.isEmpty(relDef)) {
                        String directionValue = StringPool.EMPTY;
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString())) {
                            if (result.containsKey(relDef)) {
                                directionValue = result.get(relDef);
                                directionValue += StringPool.COMMA + StringPool.PLUS;
                                result.replace(relDef, directionValue);
                            } else
                                result.put(relDef, StringPool.PLUS);
                        } else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString())) {
                            if (result.containsKey(relDef)) {
                                directionValue = result.get(relDef);
                                directionValue += StringPool.COMMA + StringPool.DASH;
                                result.replace(relDef, directionValue);
                            } else
                                result.put(relDef, StringPool.DASH);
                        } else
                            result.putIfAbsent(relDef, StringPool.PLUS);
                    }
                } else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString())) {
                    String relDefUIDs = criteria.getValue();
                    if (!StringUtils.isEmpty(relDefUIDs) && (criteria.getOperator() == operator.equal || criteria.getOperator() == operator.in)) {
                        String[] relDefs = relDefUIDs.split(StringPool.COMMA);
                        for (String relDef : relDefs) {
                            String directionValue = StringPool.EMPTY;
                            if (result.containsKey(relDef)) {
                                directionValue = result.get(relDef);
                                directionValue += StringPool.COMMA + StringPool.PLUS;
                                result.replace(relDef, directionValue);
                            } else
                                result.put(relDef, StringPool.PLUS);
                        }
                    }
                }
            }
        }
        return result;
    }

    public String getOBID() {
        if (this.queryCriterions.size() > 0) {
            for (QueryCriteria queryCriterion : this.queryCriterions) {
                if (queryCriterion.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                    return queryCriterion.getValue();
            }
        }
        return "";
    }

    protected void setCriteriaUsedForOrderingOrNot(QueryCriteria criteria, List<OrderByWrapper> orderingColumns) {
        if (orderingColumns != null && criteria != null) {
            OrderByWrapper order = orderingColumns.stream().filter(c -> c.expansionModePlusIdentity().equalsIgnoreCase(criteria.expansionModePlusIdentity())).findFirst().orElse(null);
            if (order == null)
                order = orderingColumns.stream().filter(c -> c.getIdentity().equalsIgnoreCase(criteria.identity())).findFirst().orElse(null);
            if (order != null) {
                criteria.setUsedForOrdering(true);
                criteria.setOrderMode(order.getOrderMode());
                orderingColumns.remove(order);
            }
        }
    }

    protected void onGetCriterionsCaseClassDef(List<QueryCriteria> result, List<OrderByWrapper> orderByWrapperList) {
        if (this.getQueryClassDef() != null && result != null) {
            QueryCriteria criteria = this.getQueryClassDef().Criteria(this);
            this.setCriteriaUsedForOrderingOrNot(criteria, orderByWrapperList);
            result.add(criteria);
        }
    }

    protected void onGetCriterionsCaseInterfaceDefs(List<QueryCriteria> result, AtomicInteger tableIndex) {
        if (this.getQueryInterface().size() > 0) {
            for (QueryInterface anInterface : this.getQueryInterface()) {
                QueryCriteria criteria = anInterface.Criteria(this);
                criteria.setTableIndex(tableIndex.get());
                result.add(criteria);
                tableIndex.incrementAndGet();
            }
        }
    }

    protected void onGetCriterionsCaseDefault(List<QueryCriteria> result, AtomicInteger tableIndex, List<OrderByWrapper> orderByWrapperList) {
        if (this.getQueryCriterions().size() > 0) {
            for (QueryCriteria criteria : this.getQueryCriterions()) {
                boolean flag = false;
                if (criteria.useRelationship()) {
                    criteria.setTableIndex(tableIndex.get());
                    flag = true;
                } else if (criteria.useAdvancedProperty()) {
                    criteria.setTableIndex(tableIndex.get());
                    flag = true;
                    this.setCriteriaUsedForOrderingOrNot(criteria, orderByWrapperList);
                }
                result.add(criteria);
                if (flag)
                    tableIndex.incrementAndGet();
            }
        }
    }

    protected void onGetCriterionsCaseAdditionalOrdering(List<QueryCriteria> result, List<OrderByWrapper> orderByWrapperList, AtomicInteger tableIndex) {
        if (result != null && orderByWrapperList != null) {
            if (orderByWrapperList.size() > 0) {
                for (OrderByWrapper orderByWrapper : orderByWrapperList) {
                    LiteCriteria liteCriteria = orderByWrapper.liteCriteria();
                    if (!propertyDefinitionType.OBJORRELTableProperties().contains(liteCriteria.getPropertyDefinition())) {
                        QueryCriteria criteria = new QueryCriteria(this, liteCriteria.expansionPath(), interfaceDefinitionType.ICustomObject.toString(), liteCriteria.getPropertyDefinition(), liteCriteria.getPropertyValueType(), operator.equal, "*", liteCriteria.getExpansionMode());
                        criteria.setTableIndex(tableIndex.get());
                        criteria.setUsedForOrdering(true);
                        criteria.setOrderMode(orderByWrapper.getOrderMode());
                        tableIndex.incrementAndGet();
                        result.add(criteria);
                    } else {
                        QueryCriteria criteria = new QueryCriteria(this, liteCriteria.expansionPath(), interfaceDefinitionType.IObject.toString(), liteCriteria.getPropertyDefinition(), liteCriteria.getPropertyValueType(), operator.equal, "*", liteCriteria.getExpansionMode());
                        criteria.setUsedForOrdering(true);
                        result.add(criteria);
                    }
                }
            }
        }
    }

    protected void onGetCriterionsCaseRender(List<QueryCriteria> result, AtomicInteger tableIndex) {
        if (result != null) {
            List<ObjectItemDTO> renderColumns1 = this.getRenderColumns();
            if (CommonUtility.hasValue(renderColumns1)) {
                for (ObjectItemDTO itemDTO : renderColumns1) {
                    LiteCriteria liteCriteria = itemDTO.liteCriteria();
                    QueryCriteria queryCriteria = result.stream().filter(c -> c.expansionModePlusIdentity().equalsIgnoreCase(liteCriteria.expansionModePlusIdentity())).findFirst().orElse(null);
                    if (queryCriteria != null) {
                        queryCriteria.setUsedForRendering(true);
                    } else {
                        queryCriteria = new QueryCriteria(this, liteCriteria.expansionPath(), liteCriteria.getInterfaceDefinitionUID(), liteCriteria.getPropertyDefinition(), liteCriteria.getPropertyValueType(), operator.equal, "*", liteCriteria.getExpansionMode());
                        queryCriteria.setUsedForRendering(true);
                        queryCriteria.setTableIndex(tableIndex.get());
                        result.add(queryCriteria);
                        tableIndex.incrementAndGet();
                    }
                }
            }
        }
    }

    public List<QueryCriteria> getCriterions() {
        List<QueryCriteria> result = new ArrayList<>();
        List<OrderByWrapper> orderByWrapperList = new ArrayList<>(this.getOrderByWrappers());
        this.orderByWrappers.clear();
        AtomicInteger tableIndex = new AtomicInteger(1);
        this.onGetCriterionsCaseClassDef(result, orderByWrapperList);
        this.onGetCriterionsCaseInterfaceDefs(result, tableIndex);
        this.onGetCriterionsCaseDefault(result, tableIndex, orderByWrapperList);
        this.onGetCriterionsCaseAdditionalOrdering(result, orderByWrapperList, tableIndex);
        this.onGetCriterionsCaseRender(result, tableIndex);
        return result;
    }

    public boolean useInterface() {
        return this.getQueryInterface().size() > 0;
    }

    public boolean useBaseProperty() {
        List<String> arrIndicators = propertyDefinitionType.OBJORRELTableProperties();
        for (QueryCriteria queryCriterion : this.getQueryCriterions()) {
            if (!queryCriterion.useRelationship()) {
                if (arrIndicators.stream().anyMatch(c -> c.equalsIgnoreCase(queryCriterion.getPropertyDefinitionUID())))
                    return true;
            }
        }
        return false;
    }

    public boolean useRelationship() {
        return this.getQueryCriterions().stream().anyMatch(QueryCriteria::useRelationship);
    }

    public List<QueryCriteria> getCriterionsUseRelationships() {
        return this.getQueryCriterions().stream().filter(QueryCriteria::useRelationship).collect(Collectors.toList());
    }

    public boolean useAdvanceProperty() {
        String[] arrIndicators = HardCodeHelper.OBJ_QUERY_INDICATORS;
        for (QueryCriteria queryCriterion : this.getQueryCriterions()) {
            if (!queryCriterion.useRelationship()) {
                if (Arrays.stream(arrIndicators).noneMatch(c -> c.equalsIgnoreCase(queryCriterion.getPropertyDefinitionUID())))
                    return true;
            }
        }
        return false;
    }

    public List<QueryCriteria> criteriaByOBJProperty() {
        String[] arrIndicators = HardCodeHelper.OBJ_QUERY_INDICATORS;
        return this.getQueryCriterions().stream().filter(c -> {
            if (!c.useRelationship())
                return Arrays.stream(arrIndicators).anyMatch(k -> k.equalsIgnoreCase(c.getPropertyDefinitionUID()));
            return false;
        }).collect(Collectors.toList());
    }

    public List<QueryCriteria> criteriaByAdvancedProperty() {
        String[] arrIndicators = HardCodeHelper.OBJ_QUERY_INDICATORS;
        return this.getQueryCriterions().stream().filter(c -> {
            if (!c.useRelationship())
                return Arrays.stream(arrIndicators).noneMatch(k -> k.equalsIgnoreCase(c.getPropertyDefinitionUID()));
            return false;
        }).collect(Collectors.toList());
    }


    public void addQueryInterface(String interfaceDefUid) {
        if (!StringUtils.isEmpty(interfaceDefUid)) {
            if (queryInterface.stream().noneMatch(c -> c.getInterfaceDefinition().equalsIgnoreCase(interfaceDefUid))) {
                QueryInterface anInterface = new QueryInterface(interfaceDefUid);
                this.queryInterface.add(anInterface);
            }
        }
    }

    public void addQueryInterface(String... parrInterfaceDefUIDs) {
        if (parrInterfaceDefUIDs != null) {
            for (String interfaceDefUID : parrInterfaceDefUIDs) {
                this.addQueryInterface(interfaceDefUID);
            }
        }
    }

    public void useClassDefForQuery(String classDefUID) {
        if (!StringUtils.isEmpty(classDefUID)) {
            this.queryClassDef = new QueryClassDef(classDefUID);
        }
    }

    public QueryCriteria addQueryCriteria(String relOrEdgeDefUid, String interfaceDefinitionUid, String propertyDefinitionUid, String propertyValueType, operator pstrOperator, String value, ExpansionMode expansionMode) {
        if (relOrEdgeDefUid == null)
            relOrEdgeDefUid = "";

        if (interfaceDefinitionUid == null || StringUtils.isEmpty(interfaceDefinitionUid))
            interfaceDefinitionUid = interfaceDefinitionType.IObject.toString();

        if (propertyDefinitionUid == null || StringUtils.isEmpty(propertyDefinitionUid))
            propertyDefinitionUid = propertyDefinitionType.Name.toString();

        if (pstrOperator == null)
            pstrOperator = operator.equal;

        QueryCriteria currentCriteria = new QueryCriteria(this, relOrEdgeDefUid, interfaceDefinitionUid, propertyDefinitionUid, propertyValueType, pstrOperator, value, expansionMode);
        String finalRelOrEdgeDefUID = relOrEdgeDefUid;
        String finalPropertyDefUID = propertyDefinitionUid;
        this.queryCriterions.stream().filter(c -> c.getRelOrEdgeDefinitionUID().equalsIgnoreCase(finalRelOrEdgeDefUID) && c.getPropertyDefinitionUID().equalsIgnoreCase(finalPropertyDefUID)).findFirst().ifPresent(this.queryCriterions::remove);
        this.queryCriterions.add(currentCriteria);
        return currentCriteria;
    }


    public void setQueryForRelationship(boolean queryForRelationship) {
        this.queryForRelationship = queryForRelationship;
        if (queryForRelationship) {
            this.queryInterface.clear();
        }
    }
}
