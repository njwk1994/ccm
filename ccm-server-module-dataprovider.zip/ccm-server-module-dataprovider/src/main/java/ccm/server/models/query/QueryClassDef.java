package ccm.server.models.query;

import ccm.server.enums.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public class QueryClassDef {
    private String classDefinition;

    public QueryClassDef(String pstrClassDefinition) {
        this.classDefinition = pstrClassDefinition;
    }

    public QueryClassDef() {
    }

    public QueryCriteria Criteria(QueryRequest queryRequest) {
        String[] strings = classDefinition.split(",");
        if (strings.length == 1)
            return new QueryCriteria(queryRequest, interfaceDefinitionType.IObject.toString(), propertyDefinitionType.ClassDefinitionUID.toString(), propertyValueType.StringType.name(), operator.equal, this.classDefinition, ExpansionMode.none);
        else
            return new QueryCriteria(queryRequest, interfaceDefinitionType.IObject.toString(), propertyDefinitionType.ClassDefinitionUID.toString(), propertyValueType.StringType.name(), operator.in, this.classDefinition, ExpansionMode.none);
    }
}
