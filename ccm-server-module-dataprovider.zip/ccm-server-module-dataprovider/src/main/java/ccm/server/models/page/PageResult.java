package ccm.server.models.page;

import ccm.server.util.CommonUtility;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Data
@Slf4j
public class PageResult<T> {
    private int current = 0;
    private int size = 0;
    private long total = 0;

    public void setResultList(List<T> items) {
        if (items != null && items.size() > 0)
            this.getResultList().addAll(items);
    }
    // 2022.03.18 HT 临时修复多usedDomain时GetEnd2s数据填充错误问题
    /**
     * 判断是否使用分页功能(默认使用)
     */
    private boolean usePageSelector = true;
    // 2022.03.18 HT 临时修复多usedDomain时GetEnd2s数据填充错误问题
    private final List<T> resultList = new ArrayList<>();

    public boolean hasValue() {
        return this.getResultList() != null && this.getResultList().size() > 0;
    }

    public int getQuantity() {
        if (CommonUtility.hasValue(resultList))
            return resultList.size();
        return 0;
    }

    public void setCurrent(int i) {
        this.current = i;
    }

    public void setSize(int i) {
        this.size = i;
    }

    public boolean full() {
        boolean result = false;
        int capacity = this.size * this.current;
        result = total - capacity <= 0;
        return result;
    }

    public PageResult(List<T> resultList) {
        if (CommonUtility.hasValue(resultList))
            this.resultList.addAll(resultList);
        this.setCurrent(1);
        this.setSize(resultList.size());
        this.setTotal(Long.parseLong(String.valueOf(resultList.size())));
    }

    /**
     * 构造分页Result并判断是否使用分页
     * <p>
     * 用于修复不使用分页时多usedDomain数据填充错误问题
     * </p>
     *
     * @param resultList
     * @param usePageSelector
     */
    // 2022.03.18 HT 临时修复多usedDomain时GetEnd2s数据填充错误问题
    public PageResult(List<T> resultList, boolean usePageSelector) {
        if (CommonUtility.hasValue(resultList))
            this.resultList.addAll(resultList);
        this.setUsePageSelector(usePageSelector);
        if (usePageSelector) {
            this.setCurrent(1);
            this.setSize(resultList.size());
        } else {
            this.setCurrent(0);
            this.setSize(0);
        }
        this.setTotal(Long.parseLong(String.valueOf(resultList.size())));
    }
    // 2022.03.18 HT 临时修复多usedDomain时GetEnd2s数据填充错误问题

    public PageResult() {

    }

    public void addList(List<T> sourceItems, long partialQuantity) {
        if (CommonUtility.hasValue(sourceItems)) {
            this.total += partialQuantity;
            // 2022.03.18 HT 临时修复多usedDomain时GetEnd2s数据填充错误问题
            if (usePageSelector) {
                if (resultList.size() < this.size) {
                    int diff = this.size - resultList.size();
                    for (int i = 0; i < sourceItems.size(); i++) {
                        if (diff - i <= 0)
                            break;
                        T t = sourceItems.get(i);
                        resultList.add(t);
                    }
                }
            } else {
                resultList.addAll(sourceItems);
            }
            // 2022.03.18 HT 临时修复多usedDomain时GetEnd2s数据填充错误问题
        }
    }
}
