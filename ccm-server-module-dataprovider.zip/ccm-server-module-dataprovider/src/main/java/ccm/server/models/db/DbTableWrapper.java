package ccm.server.models.db;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.util.Date;

@Data
@Slf4j
public class DbTableWrapper {
    private String name;
    private String objectId;
    private String type;
    private String typeDesc;
    private Date createDate;
    private Date modifyDate;

    public void setValue(String key, Object value) {
        if (!StringUtils.isEmpty(key)) {
            try {
                Field field = this.getClass().getField(key);
                field.setAccessible(true);
                field.set(this, value);
            } catch (NoSuchFieldException e) {
                log.error("no field was found in " + this.getClass().getName() + " with " + key, e);
            } catch (IllegalAccessException e) {
                log.error("set value failed for field " + key, e);
            }
        }
    }
}
