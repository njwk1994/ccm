package ccm.server.models.scope;

import ccm.server.entity.MetaDataObj;
import ccm.server.enums.domainInfo;
import ccm.server.models.LiteObject;
import ccm.server.util.CommonUtility;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Data
public class ScopeConfiguration implements Serializable {
    private static final long serialVersionUID = 1L;
    private final List<LiteObject> queryConfigs = new ArrayList<>();
    private LiteObject createConfig;
    public static final String CLASSDEF_CONFIGURATIONITEM = "CIMPlant";
    public static final String SCOPE_NOT_SET = "Scope Not Set";
    public static final String SCOPE_NOT_SET_UID = "PL_SCOPE_NOT_SET";
    public static ScopeConfiguration ScopeNotSet;

    public static LiteObject getDefaultScopedNotSet() {
        return new LiteObject(new MetaDataObj() {
            {
                this.setName(SCOPE_NOT_SET);
                this.setDomainUid(SCOPE_NOT_SET_UID);
                this.setClassDefinitionUid(CLASSDEF_CONFIGURATIONITEM);
                this.setDescription("No Plant or Project selected by user");
                this.setDomainUid(domainInfo.ADMIN.toString());
                this.setObjUid(SCOPE_NOT_SET_UID);
            }
        });
    }

    public static ScopeConfiguration getNotSetScope() {
        if (ScopeNotSet == null) {
            ScopeNotSet = new ScopeConfiguration() {{
                LiteObject scopeNotSet = getDefaultScopedNotSet();
                setCreateConfig(scopeNotSet);
                getQueryConfigs().clear();
                getQueryConfigs().add(scopeNotSet);
            }};
        }
        return ScopeNotSet;
    }

    public List<LiteObject> getQueryConfigs() {
        List<LiteObject> queryConfigsWithOutDuplicate = this.queryConfigs.stream().filter(Objects::nonNull).distinct().collect(Collectors.toList());
        this.queryConfigs.clear();
        this.queryConfigs.addAll(queryConfigsWithOutDuplicate);
        return this.queryConfigs;
    }

    public boolean hasCreateConfig() {
        return this.getCreateConfig() != null && !this.getCreateConfig().getObjUID().equalsIgnoreCase(SCOPE_NOT_SET_UID);
    }

    public boolean hasQueryConfig() {
        return CommonUtility.hasValue(this.queryConfigs) && this.queryConfigs.stream().filter(Objects::nonNull).noneMatch(c -> c.getObjUID().equalsIgnoreCase(SCOPE_NOT_SET_UID));
    }

    public ScopeConfiguration() {
//        this.setCreateConfig(ScopeNotSet.getCreateConfig());
//        this.queryConfigs.addAll(ScopeNotSet.getQueryConfigs());
    }

    public void addCreateConfig(LiteObject createConfig) throws Exception {
        if (createConfig != null) {
            this.setCreateConfig(createConfig);
            this.addQueryConfig(createConfig);
        }
    }

    public void addQueryConfig(List<LiteObject> queryConfigs) {
        if (CommonUtility.hasValue(queryConfigs)) {
            for (LiteObject queryConfig : queryConfigs) {
                if (queryConfig != null)
                    this.addQueryConfig(queryConfig);
            }
        }
    }

    public void addQueryConfig(LiteObject queryConfig) {
        if (queryConfig != null) {
            if (this.queryConfigs.stream().anyMatch(c -> c.getObjUID().equalsIgnoreCase(SCOPE_NOT_SET_UID)))
                this.queryConfigs.clear();
            if (this.queryConfigs.stream().noneMatch(c -> c.getOBID().equalsIgnoreCase(queryConfig.getOBID())))
                this.queryConfigs.add(queryConfig);
        }
    }

    public String getCreateConfigDisplayAs() {
        return this.getCreateConfig() != null ? this.getCreateConfig().getName() : SCOPE_NOT_SET;
    }

    public String getQueryConfigDisplayAs() {
        if (CommonUtility.hasValue(this.queryConfigs)) {
            return this.queryConfigs.stream().filter(Objects::nonNull).map(LiteObject::getName).collect(Collectors.joining(","));
        }
        return SCOPE_NOT_SET;
    }

    @Override
    public String toString() {
        return "Create Config:" + this.getCreateConfigDisplayAs() + ",Query Config(s):" + this.getQueryConfigDisplayAs();
    }
}
