package ccm.server.models.db;

import com.baomidou.mybatisplus.annotation.DbType;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Data
@Slf4j
public class DbColumnWrapper {
    private String tableId;
    private String fieldName;
    private String sortIndex;
    private String isKey;
    private String keyRule;
    private String fieldType;
    private String length;
    private String notNull;
    private String defaultValue;
    private String fieldDesc;
    private DbType dbType = DbType.SQL_SERVER;

    private final static String CHAR_MAX = "MAX";
    private final static String CHAR_NULL = "NULL";

    public String generateNullableSql() {
        if (this.notNull != null) {
            if (this.notNull.equalsIgnoreCase("Y"))
                return "NOT " + CHAR_NULL;
            return CHAR_NULL;
        }
        return "";
    }

    protected List<String> fieldTypeWithoutLength() {
        List<String> result = new ArrayList<>();
        result.add("int");
        result.add("bit");
        result.add("date");
        result.add("datetime");
        result.add("float");
        result.add("image");
        result.add("money");
        result.add("ntext");
        result.add("real");
        result.add("text");
        result.add("timestamp");
        result.add("tinyint");
        result.add("xml");
        return result;
    }

    protected boolean isFiledTypeHasLength() {
        List<String> items = this.fieldTypeWithoutLength();
        return items.stream().anyMatch(c -> c.equalsIgnoreCase(this.fieldType));
    }

    public String generateFieldTypeSql() {
        String lstrLength = this.length;
        if (this.length != null && this.length.equals("-1")) {
            lstrLength = CHAR_MAX;
        }
        String lstrFieldType = this.fieldType;
        if (this.isFiledTypeHasLength())
            lstrLength = "";
        return lstrFieldType + (StringUtils.isEmpty(lstrLength) ? "" : "(" + lstrLength + ")");
    }

    public void setValue(String key, Object value) {
        if (!StringUtils.isEmpty(key)) {
            try {
                Field field = this.getClass().getField(key);
                field.setAccessible(true);
                field.set(this, value);
            } catch (NoSuchFieldException e) {
                log.error("no field was found in " + this.getClass().getName() + " with " + key, e);
            } catch (IllegalAccessException e) {
                log.error("set value failed for field " + key, e);
            }
        }
    }
}
