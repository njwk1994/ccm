package ccm.server.models;

import ccm.server.util.CommonUtility;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Slf4j
public class ResultSet<T> {
    private final List<T> list = new ArrayList<>();
    private Boolean result = true;
    private final List<Exception> exceptions = new ArrayList<>();

    public void setResult(boolean result) {
        if (this.getResult())
            this.result = result;
    }

    public void setList(List<T> items) {
        this.list.clear();
        this.list.addAll(items);
    }

    public int size() {
        return this.list.size();
    }

    public T get() {
        if (CommonUtility.hasValue(this.getList()))
            return this.getList().get(0);
        return null;
    }

    public void setException(Exception e) {
        this.exceptions.add(e);
    }

    public void Throw() throws Exception {
        if (CommonUtility.hasValue(this.getExceptions())) {
            throw new Exception("process result error:" + exceptions.stream().map(Exception::getMessage).collect(Collectors.joining(";" + StringPool.CRLF)));
        }
    }
}