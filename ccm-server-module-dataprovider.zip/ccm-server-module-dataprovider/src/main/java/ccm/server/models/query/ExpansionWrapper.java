package ccm.server.models.query;

import ccm.server.enums.relDirection;
import ccm.server.params.PageRequest;
import lombok.Data;

import java.util.List;
import java.util.stream.Collectors;

@Data
public class ExpansionWrapper {
    String relDef;
    List<String> Obids;
    relDirection relDirection;
    PageRequest pageRequest;
    List<String> tablePrefixes;

    public List<String> getTablePrefixes() {
        if (this.tablePrefixes != null)
            return this.tablePrefixes.stream().distinct().collect(Collectors.toList());
        return null;
    }
}
