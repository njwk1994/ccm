package ccm.server.models.db;

import com.baomidou.mybatisplus.annotation.DbType;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class DbWrapper {
    private DbType dbType;

    private String name;
    private String dbAlias;
}
