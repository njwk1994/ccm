package ccm.server.models;

import ccm.server.models.info.InfoIFAndPRDetail;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@Slf4j
public class LiteObjectPart extends InfoIFAndPRDetail {
    private String obid;
    private String objUid;
    private String name;
    private String description;
    private String domainUid;
    private String uniqueKey;
    private String config;
    private String classDefinitionUid;
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date lastUpdateDate;
    private String lastUpdateUser;
    private String creationUser;
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date creationDate;
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date terminationDate;
    private String terminationUser;
}
