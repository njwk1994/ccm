package ccm.server.shared.impl;

import ccm.server.business.IDataProviderService;
import ccm.server.business.ISchemaProviderService;
import ccm.server.enums.classDefinitionType;
import ccm.server.enums.domainInfo;
import ccm.server.enums.relDefinitionType;
import ccm.server.module.impl.general.SharedServiceImpl;
import ccm.server.shared.ISharedCacheService;
import ccm.server.util.PerformanceUtility;
import ccm.server.util.ReentrantLockUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Service("sharedCacheServiceImpl")
@Slf4j
public class SharedCacheServiceImpl extends SharedServiceImpl implements ISharedCacheService {
    public final static String DEFAULT_DOMAIN = domainInfo.SCHEMA.toString();
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final AtomicBoolean initialized = new AtomicBoolean(false);

    @Override
    public boolean initialized() {
        return this.initialized.get();
    }

    @Override
    public void reset() {
        this.initialized.set(false);
    }

    @Override
    public void cache() throws Exception {
        Exception ex = null;
        StopWatch stopWatch = PerformanceUtility.start();
        try {
            ReentrantLockUtility.tryToAcquireWriteLock(this.lock);
            this.reset();
            this.initialized.set(true);
        } catch (Exception exception) {
            ex = exception;
            this.reset();
            log.error("cache under shared service progress failed", exception);
        } finally {
            ReentrantLockUtility.tryToUnlockWriteLock(this.lock);
        }
        log.info("complete to cache from database" + PerformanceUtility.stop(stopWatch));
        if (ex != null)
            throw ex;
    }

    @Override
    public List<String> getForceCachedClassDefs() {
        return classDefinitionType.getRequiredToCachedClassDefinitionForRunner();
    }

    @Override
    public List<String> getForceCachedRelDefs() {
        return relDefinitionType.getRequiredToCachedRelDefs();
    }
}
