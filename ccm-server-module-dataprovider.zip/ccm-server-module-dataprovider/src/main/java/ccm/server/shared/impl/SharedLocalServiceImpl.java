package ccm.server.shared.impl;

import ccm.server.module.impl.general.SharedServiceImpl;
import ccm.server.shared.ISharedLocalService;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.jeecg.common.system.vo.LoginUser;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Service("sharedLocalServiceImpl")
@Slf4j
public class SharedLocalServiceImpl extends SharedServiceImpl implements ISharedLocalService {
    public static ISharedLocalService Instance;
    public final static ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final static ThreadLocal<String> userNameThreadLocal = new ThreadLocal<>();

    @PostConstruct
    public void doInit() {
        Instance = this;
    }

    @Override
    public String getCurrentLoginUser() {
        String userName = "";
        try {
            LoginUser loginUser = (LoginUser) SecurityUtils.getSubject().getPrincipal();
            userName = loginUser.getUsername();
            log.trace("set current login user into thread local with " + userName);
        } catch (Exception exception) {
            log.trace("get current login user failed");
        } finally {
            if (StringUtils.isEmpty(userName))
                userName = userNameThreadLocal.get();
        }
        return userName;
    }

    @Override
    public void setCurrentLoginUser(String userName) {
        userNameThreadLocal.set(userName);
    }
}
