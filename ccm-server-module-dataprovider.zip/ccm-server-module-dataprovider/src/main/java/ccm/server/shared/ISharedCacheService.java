package ccm.server.shared;

import ccm.server.module.service.base.ISharedService;

import java.util.List;

public interface ISharedCacheService extends ISharedService {

    boolean initialized();

    void reset();

    void cache() throws Exception;

    List<String> getForceCachedClassDefs();

    List<String> getForceCachedRelDefs();
}
