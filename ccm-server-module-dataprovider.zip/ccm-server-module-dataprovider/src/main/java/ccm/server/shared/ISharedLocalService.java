package ccm.server.shared;

import ccm.server.module.service.base.ISharedService;

public interface ISharedLocalService extends ISharedService {
    String getCurrentLoginUser();

    void setCurrentLoginUser(String userName);
}
