package ccm.server.injectors;

import ccm.server.methods.mySql.insertBatchMethod;
import ccm.server.methods.mySql.updateBatchMethod;
import com.baomidou.mybatisplus.core.injector.AbstractMethod;
import com.baomidou.mybatisplus.core.metadata.TableInfo;
import com.github.yulichang.injector.MPJSqlInjector;

import java.util.List;

public class MySqlInjector extends MPJSqlInjector {
    @Override
    public List<AbstractMethod> getMethodList(Class<?> mapperClass, TableInfo tableInfo) {
        List<AbstractMethod> methodList = super.getMethodList(mapperClass, tableInfo);
        methodList.add(new updateBatchMethod());
        methodList.add(new insertBatchMethod());
        return methodList;
    }
}
