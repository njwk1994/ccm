package ccm.server.business;

import ccm.server.enums.classDefinitionType;
import ccm.server.models.LiteObject;
import ccm.server.module.service.base.IInternalService;

import java.util.List;

public interface ISchemaProviderService extends IInternalService {

    void refreshSchemaObjs() throws Exception;

    List<LiteObject> getCachedSchemaInfo(classDefinitionType classDefinitionType);

    List<LiteObject> getPropertyValueTypes();

    IDataProviderService dataProvider();

    List<LiteObject> getSchemaRels();

    LiteObject getSchemaObject(String uid);

    String getImpliesInfo(String interfaceDefinitionUID);

}
