package ccm.server.business;

import ccm.server.enums.CRUD;
import ccm.server.models.db.DbColumnWrapper;
import ccm.server.models.db.DbTableWrapper;
import ccm.server.models.db.DbWrapper;
import ccm.server.module.service.base.IUtilityService;
import com.baomidou.mybatisplus.annotation.DbType;

import java.util.List;

public interface IDbManagementBusinessService extends IUtilityService {

    boolean createTable(DbWrapper dataBase, String table) throws Exception;

    boolean tableExistOrNot(DbWrapper dataBase, String table) throws Exception;

    boolean dropTable(DbWrapper dataBase, String table) throws Exception;

    boolean alterColumn(DbWrapper dataBase, CRUD crud, DbColumnWrapper dbColumnWrapper) throws Exception;

    List<DbTableWrapper> getTables(DbWrapper dataBase) throws Exception;

    List<DbColumnWrapper> getColumns(DbWrapper dataBase, String table) throws Exception;
}
