    package ccm.server.business.impl;

import ccm.server.business.IDbManagementBusinessService;
import ccm.server.enums.CRUD;
import ccm.server.enums.tableSuffix;
import ccm.server.handlers.db.ISqlWrapper;
import ccm.server.models.db.DbColumnWrapper;
import ccm.server.models.db.DbTableWrapper;
import ccm.server.models.db.DbWrapper;
import ccm.server.module.impl.general.UtilityServiceImpl;
import com.alibaba.druid.pool.DruidDataSource;
import com.baomidou.dynamic.datasource.DynamicRoutingDataSource;
import com.baomidou.dynamic.datasource.ds.ItemDataSource;
import com.baomidou.mybatisplus.annotation.DbType;
import lombok.extern.slf4j.Slf4j;
import org.jeecg.common.util.dynamic.db.DynamicDBUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DbManagementBusinessServiceImpl extends UtilityServiceImpl implements IDbManagementBusinessService {

    @Autowired
    private ISqlWrapper[] sqlWrappers;

    protected ISqlWrapper getSqlWrapper(DbWrapper database) {
        if (database != null && sqlWrappers != null && sqlWrappers.length > 0) {
            DbType dbType = database.getDbType();
            List<ISqlWrapper> sqlWrappers1 = new ArrayList<>();
            for (ISqlWrapper sqlWrapper : sqlWrappers) {
                if (sqlWrapper.getDbType() == dbType) {
                    sqlWrappers1.add(sqlWrapper);
                }
            }
            if (sqlWrappers.length > 0) {
                Optional<ISqlWrapper> sqlWrapper = sqlWrappers1.stream().max(Comparator.comparingInt(ISqlWrapper::getOrder));
                return sqlWrapper.orElse(null);
            }
        }
        return null;
    }

    protected tableSuffix getTableSuffix(String table) {
        if (!StringUtils.isEmpty(table)) {
            if (table.endsWith(tableSuffix.OBJ.toString()))
                return tableSuffix.OBJ;
            else if (table.endsWith(tableSuffix.OBJPR.toString()))
                return tableSuffix.OBJPR;
            else if (table.endsWith(tableSuffix.OBJIF.toString()))
                return tableSuffix.OBJIF;
            else if (table.endsWith(tableSuffix.OBJPRDETAILS.toString()))
                return tableSuffix.OBJPRDETAILS;
            else if (table.endsWith(tableSuffix.OBJREL.toString()))
                return tableSuffix.OBJREL;
        }
        return null;
    }

    protected String getTablePrefix(String table) {
        if (!StringUtils.isEmpty(table)) {
            if (table.endsWith(tableSuffix.OBJ.toString()))
                return table.substring(0, table.length() - tableSuffix.OBJ.toString().length());
            else if (table.endsWith(tableSuffix.OBJPR.toString()))
                return table.substring(0, table.length() - tableSuffix.OBJPR.toString().length());
            else if (table.endsWith(tableSuffix.OBJIF.toString()))
                return table.substring(0, table.length() - tableSuffix.OBJIF.toString().length());
            else if (table.endsWith(tableSuffix.OBJPRDETAILS.toString()))
                return table.substring(0, table.length() - tableSuffix.OBJPRDETAILS.toString().length());
            else if (table.endsWith(tableSuffix.OBJREL.toString()))
                return table.substring(0, table.length() - tableSuffix.OBJREL.toString().length());
        }
        return table;
    }

    @Override
    public boolean createTable(DbWrapper dataBase, String table) throws Exception {
        ISqlWrapper sqlWrapper = this.getSqlWrapper(dataBase);
        if (sqlWrapper == null)
            throw new Exception("cannot find sql wrapper for " + dataBase.getDbType().toString());

        List<Exception> exceptions = new ArrayList<>();
        tableSuffix tableSuffix = this.getTableSuffix(table);
        String sqlTemplate = sqlWrapper.getCreateTableSql(tableSuffix);
        if (sqlTemplate != null && !StringUtils.isEmpty(sqlTemplate)) {
            JdbcTemplate jdbcTemplate = this.getJdbcTemplate(dataBase);
            String sql = sqlTemplate.replace(sqlWrapper.getTableNamePlaceHolder(), this.getTablePrefix(table));
            String[] strings = sql.split(";");
            for (String string : strings) {
                if ("NULL".equalsIgnoreCase(string)){
                    continue;
                }
                try {
                    jdbcTemplate.execute(string + ";");
                } catch (DataAccessException e) {
                    exceptions.add(e);
                }
            }
            if (exceptions.size() > 0)
                throw new Exception(exceptions.stream().map(Throwable::getMessage).collect(Collectors.joining("\r\n")));
            return true;
        } else
            throw new Exception("invalid sql template generated by sql wrapper ====" + sqlWrapper.getClass().getName() + "==========");
    }

    @Override
    public boolean tableExistOrNot(DbWrapper dataBase, String table) throws Exception {
        ISqlWrapper sqlWrapper = this.getSqlWrapper(dataBase);
        if (sqlWrapper == null)
            throw new Exception("cannot find sql wrapper for " + dataBase.getDbType().toString());
        String retrieveTablesSql = sqlWrapper.getRetrieveTablesSql(dataBase.getDbAlias(), table);
        if (!StringUtils.isEmpty(retrieveTablesSql)) {
            JdbcTemplate jdbcTemplate = this.getJdbcTemplate(dataBase);
            try {
                Map<String, Object> objectMap = jdbcTemplate.queryForMap(retrieveTablesSql);
                if (objectMap.size() == 1 && objectMap.values().stream().anyMatch(Objects::nonNull))
                    return true;
                else if (objectMap.size() > 1)
                    throw new Exception(table + "表存在多个，无法确定是否正确");
            } catch (DataAccessException e) {
                log.info(table + " is not exist");
            }
        }
        return false;
    }

    @Override
    public boolean dropTable(DbWrapper dataBase, String table) throws Exception {
        ISqlWrapper sqlWrapper = this.getSqlWrapper(dataBase);
        if (sqlWrapper == null)
            throw new Exception("cannot find sql wrapper for " + dataBase.getDbType().toString());

        tableSuffix tableSuffix = this.getTableSuffix(table);
        String dropTableSqlTemplate = sqlWrapper.getDropTableSql(tableSuffix);
        if (!StringUtils.isEmpty(dropTableSqlTemplate)) {
            String dropSql = dropTableSqlTemplate.replace(sqlWrapper.getTableNamePlaceHolder(), this.getTablePrefix(table));
            JdbcTemplate jdbcTemplate = this.getJdbcTemplate(dataBase);
            jdbcTemplate.execute(dropSql);
            return true;
        }
        return false;
    }

    @Override
    public boolean alterColumn(DbWrapper dataBase, CRUD crud, DbColumnWrapper dbColumnWrapper) throws Exception {
        ISqlWrapper sqlWrapper = this.getSqlWrapper(dataBase);
        if (sqlWrapper == null)
            throw new Exception("cannot find sql wrapper for " + dataBase.getDbType().toString());

        String alterColumnSqlTemplate = sqlWrapper.getAlterColumnSql(crud);
        if (!StringUtils.isEmpty(alterColumnSqlTemplate)) {
            String sql = alterColumnSqlTemplate.replace(sqlWrapper.getTableNamePlaceHolder(), dbColumnWrapper.getTableId());
            switch (crud) {
                case T:
                case D:
                    sql = sql.replace(sqlWrapper.getTableNameAlias(1), dbColumnWrapper.getFieldName());
                    break;
                case U:
                case C:
                    sql = sql.replace(sqlWrapper.getTableNameAlias(1), dbColumnWrapper.getFieldName());
                    sql = sql.replace(sqlWrapper.getTableNameAlias(2), dbColumnWrapper.generateFieldTypeSql());
                    sql = sql.replace(sqlWrapper.getTableNameAlias(3), dbColumnWrapper.generateNullableSql());
                    break;
                default:
            }
            JdbcTemplate jdbcTemplate = this.getJdbcTemplate(dataBase);
            jdbcTemplate.execute(sql);
            return true;
        }
        return false;
    }

    @Autowired
    private DynamicRoutingDataSource dynamicRoutingDataSource;

    protected JdbcTemplate getJdbcTemplate(DbWrapper dataBase) {
        DruidDataSource dataSource = null;
        String dataBaseName = dataBase.getName();
        ItemDataSource itemDataSource = (ItemDataSource) dynamicRoutingDataSource.getDataSource(dataBaseName);
        if (itemDataSource != null) {
            dataSource = (DruidDataSource) itemDataSource.getRealDataSource();
        }
        if (dataSource == null)
            dataSource = DynamicDBUtil.getDbSourceByDbKey(dataBaseName);
        return new JdbcTemplate(dataSource);
    }

    @Override
    public List<DbTableWrapper> getTables(DbWrapper dataBase) throws Exception {
        ISqlWrapper sqlWrapper = this.getSqlWrapper(dataBase);
        if (sqlWrapper == null)
            throw new Exception("cannot find sql wrapper for " + dataBase.getDbType().toString());

        String retrieveTablesSql = sqlWrapper.getRetrieveTablesSql(dataBase.getDbAlias());
        if (!StringUtils.isEmpty(retrieveTablesSql)) {
            JdbcTemplate jdbcTemplate = this.getJdbcTemplate(dataBase);
            List<Map<String, Object>> maps = jdbcTemplate.queryForList(retrieveTablesSql);
            if (maps.size() > 0) {
                List<DbTableWrapper> result = new ArrayList<>();
                for (Map<String, Object> map : maps) {
                    DbTableWrapper dbTableWrapper = new DbTableWrapper();
                    for (Map.Entry<String, Object> objectEntry : map.entrySet()) {
                        dbTableWrapper.setValue(objectEntry.getKey(), objectEntry.getValue());
                    }
                    result.add(dbTableWrapper);
                }
                return result;
            }
        }
        return null;
    }

    @Override
    public List<DbColumnWrapper> getColumns(DbWrapper dataBase, String table) throws Exception {
        ISqlWrapper sqlWrapper = this.getSqlWrapper(dataBase);
        if (sqlWrapper == null)
            throw new Exception("cannot find sql wrapper for " + dataBase.getDbType().toString());

        String retrieveTablesSql = sqlWrapper.getColumnsUnderTableSql(table);
        if (!StringUtils.isEmpty(retrieveTablesSql)) {
            String dataBaseName = dataBase.getName();
            DruidDataSource sourceByDbKey = DynamicDBUtil.getDbSourceByDbKey(dataBaseName);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(sourceByDbKey);
            List<Map<String, Object>> maps = jdbcTemplate.queryForList(retrieveTablesSql);
            if (maps.size() > 0) {
                List<DbColumnWrapper> result = new ArrayList<>();
                for (Map<String, Object> map : maps) {
                    DbColumnWrapper columnWrappers = new DbColumnWrapper();
                    columnWrappers.setDbType(dataBase.getDbType());
                    for (Map.Entry<String, Object> objectEntry : map.entrySet()) {
                        columnWrappers.setValue(objectEntry.getKey(), objectEntry.getValue());
                    }
                    result.add(columnWrappers);
                }
                return result;
            }
        }
        return null;
    }
}
