package ccm.server.business.impl;

import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataObjInterface;
import ccm.server.entity.MetaDataObjProperty;
import ccm.server.entity.MetaDataRel;
import ccm.server.enums.operator;
import ccm.server.enums.propertyDefinitionType;
import ccm.server.enums.relDirection;
import ccm.server.models.query.QueryCriteria;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static ccm.server.enums.relDirection._1To2;
import static ccm.server.enums.relDirection._2To1;

@Slf4j
public class DataProviderServiceImpExtension {

    private static void appendUIDForREL(MPJLambdaWrapper<?> lambdaWrapper, relDirection direction, operator operator, String lstrValue) {
        if (lambdaWrapper != null) {
            if (direction == null) direction = _1To2;
            if (operator == null) operator = ccm.server.enums.operator.equal;
            List<String> valueList = Arrays.stream(lstrValue.split(",")).collect(Collectors.toList());
            switch (operator) {
                case notEqual:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.ne(MetaDataRel::getUid2, lstrValue).or().isNull(MetaDataRel::getObid1));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.ne(MetaDataRel::getUid1, lstrValue).or().isNull(MetaDataRel::getObid2));
                    }
                    break;
                case notLike:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.notLike(MetaDataRel::getUid2, lstrValue.replace("*", "%")).or().isNull(MetaDataRel::getObid1));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.notLike(MetaDataRel::getUid1, lstrValue.replace("*", "%")).or().isNull(MetaDataRel::getObid2));
                    }
                    break;
                case like:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.like(MetaDataRel::getUid2, lstrValue.replace("*", "%")).or().isNull(MetaDataRel::getObid1));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.like(MetaDataRel::getUid1, lstrValue.replace("*", "%")).or().isNull(MetaDataRel::getObid2));
                    }
                    break;
                case in:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.in(MetaDataRel::getUid2, valueList).or().isNull(MetaDataRel::getObid1));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.in(MetaDataRel::getUid1, valueList).or().isNull(MetaDataRel::getObid2));
                    }
                    break;
                case equal:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.eq(MetaDataRel::getUid2, lstrValue).or().isNull(MetaDataRel::getObid1));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.eq(MetaDataRel::getUid1, lstrValue).or().isNull(MetaDataRel::getObid2));
                    }
                    break;
                case notIn:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.notIn(MetaDataRel::getUid2, valueList).or().isNull(MetaDataRel::getObid1));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.notIn(MetaDataRel::getUid1, valueList).or().isNull(MetaDataRel::getObid2));
                    }
                    break;
            }
        }
    }

    private static void appendOBIDForREL(MPJLambdaWrapper<?> lambdaWrapper, relDirection direction, operator operator, String lstrValue) {
        if (lambdaWrapper != null) {
            if (direction == null) direction = _1To2;
            if (operator == null) operator = ccm.server.enums.operator.equal;
            List<String> valueList = Arrays.stream(lstrValue.split(",")).collect(Collectors.toList());
            switch (operator) {
                case notEqual:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.ne(MetaDataRel::getObid2, lstrValue));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.ne(MetaDataRel::getObid1, lstrValue));
                    }
                    break;
                case notLike:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.notLike(MetaDataRel::getObid2, lstrValue.replace("*", "%")));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.notLike(MetaDataRel::getObid1, lstrValue.replace("*", "%")));
                    }
                    break;
                case like:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.like(MetaDataRel::getObid2, lstrValue.replace("*", "%")));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.like(MetaDataRel::getObid1, lstrValue.replace("*", "%")));
                    }
                    break;
                case in:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.in(MetaDataRel::getObid2, valueList));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.in(MetaDataRel::getObid1, valueList));
                    }
                    break;
                case equal:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.eq(MetaDataRel::getObid2, lstrValue));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.eq(MetaDataRel::getObid1, lstrValue));
                    }
                    break;
                case notIn:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.notIn(MetaDataRel::getObid2, valueList));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.notIn(MetaDataRel::getObid1, valueList));
                    }
                    break;
            }
        }
    }


    private static void appendNameForREL(MPJLambdaWrapper<?> lambdaWrapper, relDirection direction, operator operator, String lstrValue) {
        if (lambdaWrapper != null) {
            if (direction == null)
                direction = _1To2;
            if (operator == null)
                operator = ccm.server.enums.operator.equal;
            List<String> valueList = Arrays.stream(lstrValue.split(",")).collect(Collectors.toList());
            switch (operator) {
                case notEqual:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.ne(MetaDataRel::getName2, lstrValue));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.ne(MetaDataRel::getName1, lstrValue));
                    }
                    break;
                case notLike:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.notLike(MetaDataRel::getName2, lstrValue.replace("*", "%")));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.notLike(MetaDataRel::getName1, lstrValue.replace("*", "%")));
                    }
                    break;
                case like:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.like(MetaDataRel::getName2, lstrValue.replace("*", "%")));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.like(MetaDataRel::getName1, lstrValue.replace("*", "%")));
                    }
                    break;
                case in:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.in(MetaDataRel::getName2, valueList));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.in(MetaDataRel::getName1, valueList));
                    }
                    break;
                case equal:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.eq(MetaDataRel::getName2, lstrValue));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.eq(MetaDataRel::getName1, lstrValue));
                    }
                    break;
                case notIn:
                    if (direction == _1To2) {
                        lambdaWrapper.and(c -> c.notIn(MetaDataRel::getName2, valueList));
                    } else if (direction == _2To1) {
                        lambdaWrapper.and(c -> c.notIn(MetaDataRel::getName1, valueList));
                    }
                    break;
            }
        }
    }

    public static void setPRStatement(MPJLambdaWrapper<?> lambdaWrapper, QueryCriteria criteria) {
        if (lambdaWrapper != null && criteria != null && criteria.validForQuerying(null)) {
            String value = criteria.getValue().toString();
            switch (criteria.getOperator()) {
                case notEqual:
                    lambdaWrapper.and(c -> c.ne(MetaDataObjProperty::getStrValue, value));
                    break;
                case notLike:
                    lambdaWrapper.and(c -> c.notLike(MetaDataObjProperty::getStrValue, value.replace("*", "%")));
                    break;
                case like:
                    lambdaWrapper.and(c -> c.like(MetaDataObjProperty::getStrValue, value.replace("*", "%")));
                    break;
                case in:
                    lambdaWrapper.and(c -> c.in(MetaDataObjProperty::getStrValue, Arrays.stream(value.split(",")).collect(Collectors.toList())));
                    break;
                case between:
                    String value1 = value.split(",")[0];
                    String value2 = value.split(",")[1];
                    lambdaWrapper.and(c -> c.between(MetaDataObjProperty::getStrValue, value1, value2));
                    break;
                case largeOrEqualThan:
                    lambdaWrapper.and(c -> c.ge(MetaDataObjProperty::getStrValue, value));
                    break;
                case lessOrEqualThan:
                    lambdaWrapper.and(c -> c.le(MetaDataObjProperty::getStrValue, value));
                    break;
                case largeThan:
                    lambdaWrapper.and(c -> c.gt(MetaDataObjProperty::getStrValue, value));
                    break;
                case lessThan:
                    lambdaWrapper.and(c -> c.lt(MetaDataObjProperty::getStrValue, value));
                    break;
                case equal:
                    lambdaWrapper.and(c -> c.eq(MetaDataObjProperty::getStrValue, value));
                    break;
                case notIn:
                    lambdaWrapper.and(c -> c.notIn(MetaDataObjProperty::getStrValue, Arrays.stream(value.split(",")).collect(Collectors.toList())));
                    break;
            }
        }
    }

    public static void setIFStatement(MPJLambdaWrapper<?> lambdaWrapper, QueryCriteria criteria) {
        if (lambdaWrapper != null && criteria != null) {
            String interfaceDefinitionUID = criteria.getValue().toString();
            operator operator = criteria.getOperator();
            switch (operator) {
                case notEqual:
                    lambdaWrapper.and(c -> c.ne(MetaDataObjInterface::getInterfaceDefUid, interfaceDefinitionUID));
                    break;
                case notLike:
                    lambdaWrapper.and(c -> c.notLike(MetaDataObjInterface::getInterfaceDefUid, interfaceDefinitionUID.replace("*", "%")));
                    break;
                case like:
                    lambdaWrapper.and(c -> c.like(MetaDataObjInterface::getInterfaceDefUid, interfaceDefinitionUID.replace("*", "%")));
                    break;
                case in:
                    lambdaWrapper.and(c -> c.in(MetaDataObjInterface::getInterfaceDefUid, Arrays.stream(interfaceDefinitionUID.split(",")).collect(Collectors.toList())));
                    break;
                case equal:
                    lambdaWrapper.and(c -> c.eq(MetaDataObjInterface::getInterfaceDefUid, interfaceDefinitionUID));
                    break;
                case notIn:
                    lambdaWrapper.and(c -> c.notIn(MetaDataObjInterface::getInterfaceDefUid, Arrays.stream(interfaceDefinitionUID.split(",")).collect(Collectors.toList())));
                    break;
            }
        }
    }

    public static void setRELStatement(MPJLambdaWrapper<?> lambdaWrapper, QueryCriteria criteria) {
        if (lambdaWrapper != null && criteria != null) {
            operator operator = criteria.getOperator();
            String lstrValue = criteria.getValue();
            String propertyDefinitionUid = criteria.getPropertyDefinitionUID();
            relDirection direction = criteria.direction();
            if (propertyDefinitionUid.equalsIgnoreCase(propertyDefinitionType.Name.toString())) {
                appendNameForREL(lambdaWrapper, direction, operator, lstrValue);
            } else if (propertyDefinitionUid.equalsIgnoreCase(propertyDefinitionType.OBID.toString())) {
                appendOBIDForREL(lambdaWrapper, direction, operator, lstrValue);
            } else if (propertyDefinitionUid.equalsIgnoreCase(propertyDefinitionType.UID.toString())) {
                appendUIDForREL(lambdaWrapper, direction, operator, lstrValue);
            }
        }
    }

    public static void setOBJCondition(MPJLambdaWrapper<MetaDataObj> lambdaQueryWrapper, QueryCriteria criteria) {
        if (lambdaQueryWrapper != null && criteria != null) {
            operator operator = criteria.getOperator();
            List<String> valueList = Arrays.stream(criteria.getValue().split(",")).collect(Collectors.toList());
            String propertyDefinitionUID = criteria.getPropertyDefinitionUID();
            try {
                propertyDefinitionType propertyDefinitionType = ccm.server.enums.propertyDefinitionType.ValueOf(propertyDefinitionUID);
                if (propertyDefinitionType != null) {
                    switch (operator) {
                        case notIn:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getName, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getDescription, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getClassDefinitionUid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getDomainUid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getObjUid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getUniqueKey, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getObid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getCreationDate, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getCreationUser, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getLastUpdateDate, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.notIn(MetaDataObj::getLastUpdateUser, valueList);
                            break;
                        case equal:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getName, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getDescription, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getClassDefinitionUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getDomainUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getObjUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getUniqueKey, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getObid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getCreationDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getCreationUser, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getLastUpdateDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.eq(MetaDataObj::getLastUpdateUser, criteria.getValue());
                            break;
                        case notEqual:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getName, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getDescription, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getClassDefinitionUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getDomainUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getObjUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getUniqueKey, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getObid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getCreationDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getCreationUser, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getLastUpdateDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.ne(MetaDataObj::getLastUpdateUser, criteria.getValue());
                            break;
                        case lessThan:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getName, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getDescription, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getClassDefinitionUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getDomainUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getObjUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getUniqueKey, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getObid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getCreationDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getCreationUser, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getLastUpdateDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.lt(MetaDataObj::getLastUpdateUser, criteria.getValue());
                            break;
                        case largeThan:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getName, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getDescription, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getClassDefinitionUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getDomainUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getObjUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getUniqueKey, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getObid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getCreationDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getCreationUser, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getLastUpdateDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.gt(MetaDataObj::getLastUpdateUser, criteria.getValue());
                            break;
                        case lessOrEqualThan:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getName, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getDescription, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getClassDefinitionUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getDomainUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getObjUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getUniqueKey, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getObid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getCreationDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getCreationUser, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getLastUpdateDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.le(MetaDataObj::getLastUpdateUser, criteria.getValue());
                            break;
                        case largeOrEqualThan:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getName, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getDescription, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getClassDefinitionUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getDomainUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getObjUid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getUniqueKey, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getObid, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getCreationDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getCreationUser, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getLastUpdateDate, criteria.getValue());
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.ge(MetaDataObj::getLastUpdateUser, criteria.getValue());
                            break;
                        case between:
                            String value1 = criteria.getValue().split(",")[0];
                            String value2 = criteria.getValue().split(",")[1];
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getName, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getDescription, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getClassDefinitionUid, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getDomainUid, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getObjUid, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getUniqueKey, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getObid, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getCreationDate, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getCreationUser, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getLastUpdateDate, value1, value2);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.between(MetaDataObj::getLastUpdateUser, value1, value2);
                            break;
                        case in:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getName, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getDescription, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getClassDefinitionUid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getDomainUid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getObjUid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getUniqueKey, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getObid, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getCreationDate, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getCreationUser, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getLastUpdateDate, valueList);
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.in(MetaDataObj::getLastUpdateUser, valueList);
                            break;
                        case like:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getName, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getDescription, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getClassDefinitionUid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getDomainUid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getObjUid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getUniqueKey, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getObid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getCreationDate, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getCreationUser, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getLastUpdateDate, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.like(MetaDataObj::getLastUpdateUser, criteria.getValue().replace("*", "%"));
                            break;
                        case notLike:
                            if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Name.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getName, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.Description.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getDescription, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.ClassDefinitionUID.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getClassDefinitionUid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.DomainUID.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getDomainUid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UID.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getObjUid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.UniqueKey.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getUniqueKey, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.OBID.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getObid, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationDate.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getCreationDate, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.CreationUser.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getCreationUser, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateDate.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getLastUpdateDate, criteria.getValue().replace("*", "%"));
                            else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(ccm.server.enums.propertyDefinitionType.LastUpdateUser.toString()))
                                lambdaQueryWrapper.notLike(MetaDataObj::getLastUpdateUser, criteria.getValue().replace("*", "%"));
                            break;
                    }
                }
            } catch (IllegalArgumentException e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public static void setRELCondition(MPJLambdaWrapper<MetaDataRel> lambdaQueryWrapper, QueryCriteria criteria) {
        if (lambdaQueryWrapper != null && criteria != null) {
            operator operator = criteria.getOperator();
            List<String> valueList = Arrays.stream(criteria.getValue().split(",")).collect(Collectors.toList());
            try {
                switch (operator) {
                    case notIn:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getObid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getDomainUid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getDomainUid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getDomainUid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getObjUid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getUid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getUid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getObid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getObid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getName1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getName2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getClassDefinitionUid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getClassDefinitionUid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getDomainUid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getDomainUid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getPrefix, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getRelDefUid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getIsRequired, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.notIn(MetaDataRel::getOrderValue, valueList);
                        break;
                    case equal:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getObid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getDomainUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getObjUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getObid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getObid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getName1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getName2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getPrefix, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getRelDefUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getIsRequired, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getOrderValue, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getClassDefinitionUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getClassDefinitionUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getDomainUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.eq(MetaDataRel::getDomainUid2, criteria.getValue());
                        break;
                    case notEqual:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getObid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getDomainUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getObjUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getObid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getObid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getName1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getName2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getPrefix, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getRelDefUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getIsRequired, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getOrderValue, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getClassDefinitionUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getClassDefinitionUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getDomainUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.ne(MetaDataRel::getDomainUid2, criteria.getValue());
                        break;
                    case lessThan:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getObid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getDomainUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getObjUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getObid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getObid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getName1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getName2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getPrefix, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getRelDefUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getIsRequired, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getOrderValue, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getClassDefinitionUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getClassDefinitionUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getDomainUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.lt(MetaDataRel::getDomainUid2, criteria.getValue());
                        break;
                    case largeThan:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getObid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getDomainUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getObjUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getObid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getObid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getName1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getName2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getPrefix, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getRelDefUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getIsRequired, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getOrderValue, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getClassDefinitionUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getClassDefinitionUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getDomainUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.gt(MetaDataRel::getDomainUid2, criteria.getValue());
                        break;
                    case lessOrEqualThan:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getObid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getDomainUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getObjUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getObid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getObid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getName1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getName2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getPrefix, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getRelDefUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getIsRequired, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getOrderValue, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getClassDefinitionUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getClassDefinitionUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getDomainUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.le(MetaDataRel::getDomainUid2, criteria.getValue());
                        break;
                    case largeOrEqualThan:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getObid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getDomainUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getObjUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getObid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getObid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getName1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getName2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getPrefix, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getRelDefUid, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getIsRequired, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getOrderValue, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getClassDefinitionUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getClassDefinitionUid2, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getDomainUid1, criteria.getValue());
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.ge(MetaDataRel::getDomainUid2, criteria.getValue());
                        break;
                    case between:
                        String value1 = criteria.getValue().split(",")[0];
                        String value2 = criteria.getValue().split(",")[1];
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getObid, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getDomainUid, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getObjUid, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getUid1, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getUid2, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getObid1, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getObid2, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getName1, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getName2, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getPrefix, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getRelDefUid, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getIsRequired, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getOrderValue, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getClassDefinitionUid1, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getClassDefinitionUid2, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getDomainUid1, value1, value2);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.between(MetaDataRel::getDomainUid2, value1, value2);
                        break;
                    case in:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getObid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getDomainUid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getObjUid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getUid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getUid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getObid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getObid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getName1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getName2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getPrefix, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getRelDefUid, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getIsRequired, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getOrderValue, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getClassDefinitionUid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getClassDefinitionUid2, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getDomainUid1, valueList);
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.in(MetaDataRel::getDomainUid2, valueList);
                        break;
                    case like:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getObid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getDomainUid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getObjUid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getUid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getUid2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getObid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getObid2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getName1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getName2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getPrefix, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getRelDefUid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getIsRequired, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getOrderValue, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getClassDefinitionUid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getClassDefinitionUid2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getDomainUid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.like(MetaDataRel::getDomainUid2, criteria.getValue().replace("*", "%"));
                        break;
                    case notLike:
                        if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getObid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getDomainUid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getObjUid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID1.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getUid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.UID2.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getUid2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID1.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getObid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OBID2.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getObid2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name1.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getName1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Name2.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getName2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.Prefix.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getPrefix, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.RelDefUID.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getRelDefUid, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.IsRequired.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getIsRequired, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.OrderValue.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getOrderValue, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID1.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getClassDefinitionUid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.ClassDefinitionUID2.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getClassDefinitionUid2, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID1.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getDomainUid1, criteria.getValue().replace("*", "%"));
                        else if (criteria.getPropertyDefinitionUID().equalsIgnoreCase(propertyDefinitionType.DomainUID2.toString()))
                            lambdaQueryWrapper.notLike(MetaDataRel::getDomainUid2, criteria.getValue().replace("*", "%"));
                        break;
                }
            } catch (IllegalArgumentException e) {
                log.error(e.getMessage(), e);
            }
        }
    }
}
