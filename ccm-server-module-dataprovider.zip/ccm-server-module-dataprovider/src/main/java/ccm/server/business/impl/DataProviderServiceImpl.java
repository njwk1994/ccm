package ccm.server.business.impl;

import ccm.server.business.IDataProviderService;
import ccm.server.callables.DmlCallable;
import ccm.server.callables.base.CallableBase;
import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.*;
import ccm.server.entity.vo.Full;
import ccm.server.enums.CRUD;
import ccm.server.enums.joinMode;
import ccm.server.enums.propertyDefinitionType;
import ccm.server.enums.relDirection;
import ccm.server.handlers.ConfigurationPlusDomainTableNameParser;
import ccm.server.models.LiteObject;
import ccm.server.models.ResultSet;
import ccm.server.models.page.PageResult;
import ccm.server.models.query.ExpansionWrapper;
import ccm.server.models.query.QueryCriteria;
import ccm.server.models.query.QueryRequest;
import ccm.server.module.impl.general.InternalServiceImpl;
import ccm.server.params.IfAndPRCarrier;
import ccm.server.params.PageRequest;
import ccm.server.processors.ProgressLatch;
import ccm.server.processors.ThreadsProcessor;
import ccm.server.processors.TransactionQueue;
import ccm.server.service.*;
import ccm.server.shared.ISharedLocalService;
import ccm.server.util.CommonUtility;
import ccm.server.util.PerformanceUtility;
import ccm.server.util.SqlHelper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.incrementer.DefaultIdentifierGenerator;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.toolkit.Constant;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

@Service("dataProviderServiceImpl")
@Slf4j
public class DataProviderServiceImpl extends InternalServiceImpl implements IDataProviderService {
    private final CopyOnWriteArrayList<String> executingTransactionIdentities = new CopyOnWriteArrayList<>();
    private final ThreadLocal<TransactionQueue> transactionQueueThreadLocal = new ThreadLocal<>();
    @Autowired
    private TransactionQueue transactionQueue;
    @Autowired
    private IMetaDataObjService objService;
    @Autowired
    private IMetaDataObjInterfaceService interfaceService;
    @Autowired
    private IMetaDataObjPropertyService propertyService;
    @Autowired
    private IMetaDataRelService relService;
    @Autowired
    private ThreadsProcessor threadsProcessor;

    @Autowired
    private ISharedLocalService sharedLocalService;
    @Autowired
    private IInfoDetailsService infoDetailsService;

    @Override
    public IMetaDataRelService dataRelService() {
        return this.relService;
    }

    @Override
    public IMetaDataObjInterfaceService dataInterfaceService() {
        return this.interfaceService;
    }

    @Override
    public IMetaDataObjPropertyDetailsService dataPropertyDetailsService() {
        return null;
    }

    @Override
    public IMetaDataObjPropertyService dataPropertyService() {
        return this.propertyService;
    }

    @Override
    public IMetaDataObjService dataObjectService() {
        return this.objService;
    }

    protected void appendRelationshipParameter(MPJQueryWrapper<?> queryWrapper, QueryCriteria criteria) {
        if (queryWrapper != null && criteria != null) {
            String joinSql = criteria.generateJoinSql();
            this.appendJoinSql(queryWrapper, criteria.getJoinMode(), joinSql);
        }
    }

    private void appendJoinSql(MPJQueryWrapper<?> queryWrapper, joinMode joinMode, String joinSql) {
        if (queryWrapper != null && !StringUtils.isEmpty(joinSql)) {
            switch (joinMode) {
                case Left:
                    queryWrapper.leftJoin(joinSql);
                    break;
                case Inner:
                    queryWrapper.innerJoin(joinSql);
                    break;
                case Right:
                    queryWrapper.rightJoin(joinSql);
                    break;
            }
        }
    }

    private void appendInterfaceParameter(MPJQueryWrapper<?> queryWrapper, QueryCriteria criteria) {
        if (queryWrapper != null) {
            String joinSql = criteria.generateJoinSql();
            log.trace("generated join sql for parameter of interface:" + joinSql);
            this.appendJoinSql(queryWrapper, criteria.getJoinMode(), joinSql);
        }
    }

    protected void appendPropertyParameter(MPJQueryWrapper<?> queryWrapper, QueryCriteria criteria) {
        if (queryWrapper != null && criteria != null) {
            String joinSql = criteria.generateJoinSql();
            log.trace("generated join sql for parameter of property:" + joinSql);
            this.appendJoinSql(queryWrapper, criteria.getJoinMode(), joinSql);
        }
    }

    protected void appendOrderBy(MPJQueryWrapper<?> queryWrapper, List<QueryCriteria> queryCriteria) throws Exception {
        if (queryWrapper != null && CommonUtility.hasValue(queryCriteria)) {
            for (QueryCriteria criterion : queryCriteria) {
                criterion.generateOrderBy(queryWrapper);
            }
        }
    }

    protected void appendTerminationFilter(MPJQueryWrapper<?> queryWrapper) {
        String terminationUserColumn = propertyDefinitionType.TerminationUser.generateColumn(Constant.TABLE_ALIAS);
        queryWrapper.and(qw -> qw.isNull(terminationUserColumn).or().eq(terminationUserColumn, StringPool.EMPTY));
    }

    protected void setQueryWrapperCriterions(MPJQueryWrapper<?> queryWrapper, List<QueryCriteria> criterions) {
        if (queryWrapper != null && CommonUtility.hasValue(criterions)) {
            List<QueryCriteria> conditions = new ArrayList<>();
            List<QueryCriteria> leftJoinCriterions = criterions.stream().filter(c -> c.getJoinMode() != joinMode.Inner).collect(Collectors.toList());
            for (QueryCriteria criteria : criterions) {
                if (criteria.useBaseProperty()) {
                    conditions.add(criteria);
                } else if (criteria.useInterface())
                    this.appendInterfaceParameter(queryWrapper, criteria);
                else if (criteria.useRelationship()) {
                    this.appendRelationshipParameter(queryWrapper, criteria);
                } else if (criteria.useAdvancedProperty()) {
                    this.appendPropertyParameter(queryWrapper, criteria);
                }
            }
            if (CommonUtility.hasValue(conditions)) {
                for (QueryCriteria condition : conditions) {
                    condition.generateWhereSql(queryWrapper);
                }
            }
            if (CommonUtility.hasValue(leftJoinCriterions)) {
                for (QueryCriteria criterion : leftJoinCriterions) {
                    criterion.generateIsNULLSql(queryWrapper);
                }
            }
            this.appendTerminationFilter(queryWrapper);
        }
    }


    protected MPJQueryWrapper<MetaDataObj> constructJoinQueryForOBJ(List<QueryCriteria> criteriaList) {
        if (CommonUtility.hasValue(criteriaList)) {
            MPJQueryWrapper<MetaDataObj> queryWrapper = new MPJQueryWrapper<>();
            queryWrapper.setDistinct(true);
            queryWrapper.selectAll(MetaDataObj.class);
            queryWrapper.setEntityClass(MetaDataObj.class);
            this.setQueryWrapperCriterions(queryWrapper, criteriaList);
            return queryWrapper;
        }
        return null;
    }

    protected MPJQueryWrapper<MetaDataRel> constructJoinQueryForREL(List<QueryCriteria> criteriaList) {
        if (CommonUtility.hasValue(criteriaList)) {
            MPJQueryWrapper<MetaDataRel> queryWrapper = new MPJQueryWrapper<>();
            queryWrapper.setDistinct(true);
            queryWrapper.setEntityClass(MetaDataRel.class);
            queryWrapper.selectAll(MetaDataRel.class);
            this.setQueryWrapperCriterions(queryWrapper, criteriaList);
            return queryWrapper;
        }
        return null;
    }

    protected void setConfigForQueryWrapper(MPJQueryWrapper<?> queryWrapper, String config) {
    }

    @Override
    public PageResult<LiteObject> getObjects(QueryRequest request, boolean intactOrSingle) throws Exception {
        if (request != null) {
            boolean queryOne = request.getQueryOne();
            boolean useJoinQuery = QueryRequest.useJoinQuery(request);
            StopWatch stopWatch = PerformanceUtility.start();
            PageResult<LiteObject> result = null;
            if (useJoinQuery) {
                List<QueryCriteria> criterions = request.getCriterions();
                MPJQueryWrapper<MetaDataObj> queryWrapper = this.constructJoinQueryForOBJ(criterions);
                this.setConfigForQueryWrapper(queryWrapper, request.getScopePrefix());
                List<QueryCriteria> orderingCriterions = criterions.stream().filter(QueryCriteria::isUsedForOrdering).collect(Collectors.toList());
                this.appendOrderBy(queryWrapper, orderingCriterions);
                result = this.onQueryingObject(queryWrapper, request.getTablePrefixes(), request.getPageRequest(), intactOrSingle, queryOne);
            } else
                result = this.onQueryingObject(request, intactOrSingle);
            log.info("finish to get object(s):==============" + (result != null ? result.getTotal() : "0") + "================" + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }


    protected PageResult<LiteObject> onQueryingObject(QueryWrapper<MetaDataObj> lambdaWrapper, List<String> tablePrefixes, PageRequest pageRequest, boolean intactOrSingle, boolean queryOne) {
        PageResult<LiteObject> finalResult = new PageResult<>();
        if (lambdaWrapper != null) {
            if (CommonUtility.hasValue(tablePrefixes)) {
                tablePrefixes = tablePrefixes.stream().distinct().collect(Collectors.toList());
                for (String tablePrefix : tablePrefixes) {
                    PageResult<MetaDataObj> metaDataObjs = this.onQueryingObject(lambdaWrapper, pageRequest, tablePrefix);
                    List<LiteObject> result = this.toLiteObject(metaDataObjs.getResultList(), intactOrSingle, tablePrefix);
                    if (result != null) {
                        finalResult.setSize(metaDataObjs.getSize());
                        finalResult.setCurrent(metaDataObjs.getCurrent());
                        finalResult.setUsePageSelector(metaDataObjs.isUsePageSelector());
                        finalResult.addList(result, metaDataObjs.getTotal());
                        if (queryOne)
                            break;
                    }
                }
            }
        }
        return finalResult;
    }

    protected PageResult<LiteObject> onQueryingObject(MPJLambdaWrapper<MetaDataObj> lambdaWrapper, List<String> tablePrefixes, PageRequest pageRequest, boolean intactOrSingle, boolean queryOne) {
        PageResult<LiteObject> finalResult = new PageResult<>();
        if (lambdaWrapper != null) {
            if (CommonUtility.hasValue(tablePrefixes)) {
                tablePrefixes = tablePrefixes.stream().distinct().collect(Collectors.toList());
                for (String tablePrefix : tablePrefixes) {
                    PageResult<MetaDataObj> metaDataObjs = this.onQueryingObject(lambdaWrapper, pageRequest, tablePrefix);
                    List<LiteObject> result = this.toLiteObject(metaDataObjs.getResultList(), intactOrSingle, tablePrefix);
                    if (result != null) {
                        finalResult.setSize(metaDataObjs.getSize());
                        finalResult.setCurrent(metaDataObjs.getCurrent());
                        finalResult.setUsePageSelector(metaDataObjs.isUsePageSelector());
                        finalResult.addList(result, metaDataObjs.getTotal());
                        if (queryOne)
                            break;
                    }
                }
            }
        }
        return finalResult;
    }

    protected PageResult<LiteObject> onQueryingObject(MPJQueryWrapper<MetaDataObj> lambdaWrapper, List<String> tablePrefixes, PageRequest pageRequest, boolean intactOrSingle, boolean queryOne) {
        PageResult<LiteObject> finalResult = new PageResult<>();
        if (lambdaWrapper != null) {
            if (CommonUtility.hasValue(tablePrefixes)) {
                tablePrefixes = tablePrefixes.stream().distinct().collect(Collectors.toList());
                for (String tablePrefix : tablePrefixes) {
                    try {
                        StopWatch stopWatch = PerformanceUtility.start();
                        PageResult<MetaDataObj> metaDataObjs = this.onQueryingObject(lambdaWrapper, pageRequest, tablePrefix);
                        List<LiteObject> result = this.toLiteObject(metaDataObjs.getResultList(), intactOrSingle, tablePrefix);
                        if (CommonUtility.hasValue(result)) {
                            finalResult.setSize(metaDataObjs.getSize());
                            finalResult.setCurrent(metaDataObjs.getCurrent());
                            finalResult.setUsePageSelector(metaDataObjs.isUsePageSelector());
                            finalResult.addList(result, metaDataObjs.getTotal());
                        }
                        log.info("querying object completed for " + tablePrefix + PerformanceUtility.stop(stopWatch));
                        if (result != null && result.size() > 0 && queryOne)
                            break;
                    } catch (Exception exception) {
                        log.error("on querying object failed:" + exception.getMessage());
                    }
                }
            }
        }
        return finalResult;
    }

    protected List<MetaDataObjProperty> onQueryingPropertyValue(MPJQueryWrapper<MetaDataObjProperty> queryWrapper, List<String> tablePrefixes) {
        List<MetaDataObjProperty> result = new ArrayList<>();
        if (queryWrapper != null && tablePrefixes != null) {
            for (String tablePrefix : tablePrefixes) {
                ConfigurationPlusDomainTableNameParser.setTablePrefix(tablePrefix);
                List<MetaDataObjProperty> properties = this.propertyService.get(MetaDataObjProperty.class, queryWrapper);
                if (properties != null && properties.size() > 0)
                    result.addAll(properties);
            }
        }
        return result;
    }

    @Override
    public PageResult<LiteObject> getRelationships(QueryRequest queryRequest, boolean intactOrSingle) throws Exception {
        if (queryRequest != null) {
            boolean retrieveOne = queryRequest.getQueryOne();
            boolean useJoinQuery = QueryRequest.useJoinQuery(queryRequest);
            PageResult<LiteObject> result = null;
            StopWatch stopWatch = PerformanceUtility.start();
            if (useJoinQuery) {
                List<QueryCriteria> criteriaList = queryRequest.getCriterions();
                MPJQueryWrapper<MetaDataRel> queryWrapper = this.constructJoinQueryForREL(criteriaList);
                this.setConfigForQueryWrapper(queryWrapper, queryRequest.getScopePrefix());
                List<QueryCriteria> orderingCriterions = criteriaList.stream().filter(QueryCriteria::isUsedForOrdering).collect(Collectors.toList());
                this.appendOrderBy(queryWrapper, orderingCriterions);
                result = this.onQueryingRel(queryWrapper, queryRequest.getTablePrefixes(), queryRequest.getPageRequest(), intactOrSingle, retrieveOne);
            } else {
                result = this.onQueryingRel(queryRequest, intactOrSingle);
            }
            log.info("finish to get relationship(s):" + (result != null ? result.getTotal() : "0") + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }


    protected PageResult<LiteObject> onQueryingRel(MPJQueryWrapper<MetaDataRel> lambdaWrapper, List<String> tablePrefixes, PageRequest pageRequest, boolean intactOrSingle, boolean queryOne) {
        PageResult<LiteObject> finalResult = new PageResult<>();
        if (lambdaWrapper != null) {
            for (String tablePrefix : tablePrefixes) {
                try {
                    PageResult<MetaDataRel> dataRels = this.onQueryingRel(lambdaWrapper, pageRequest, tablePrefix);
                    List<LiteObject> tempResult = this.toLiteRel(dataRels.getResultList(), intactOrSingle, tablePrefix);
                    if (tempResult != null) {
                        finalResult.setSize(dataRels.getSize());
                        finalResult.setCurrent(dataRels.getCurrent());
                        finalResult.addList(tempResult, dataRels.getTotal());
                        if (queryOne)
                            break;
                    }
                } catch (Exception exception) {
                    log.error("on querying rel failed:" + exception.getMessage());
                }
            }
        }
        return finalResult;
    }

    @Override
    public List<LiteObject> getRelationships(ExpansionWrapper expansionWrapper) {
        List<LiteObject> result = null;
        if (CommonUtility.hasValue(expansionWrapper.getObids()) && !StringUtils.isEmpty(expansionWrapper.getRelDef())) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<MetaDataRel> metaDataRels = this.getEndRelationships(expansionWrapper.getObids(), expansionWrapper.getRelDef(), expansionWrapper.getRelDirection(), expansionWrapper.getTablePrefixes());
            if (metaDataRels != null && metaDataRels.size() > 0) {
                try {
                    result = this.toLiteRel(metaDataRels, true, CommonUtility.convertToArray(expansionWrapper.getTablePrefixes()));
                } catch (Exception exception) {
                    log.error("get Relationships failed", exception);
                }
            }
            log.trace("finish to get relationship(s) with expansion wrapper:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
        }
        if (result == null)
            result = new ArrayList<>();
        return result;
    }

    @Override
    public int getRelationshipsCount(String startOBID, String relDef, relDirection
            relDirection, List<String> tablePrefixes) {
        if (!StringUtils.isEmpty(relDef) && !StringUtils.isEmpty(startOBID)) {
            List<LiteObject> result = new ArrayList<>();
            if (CommonUtility.hasValue(tablePrefixes)) {
                StopWatch stopWatch = PerformanceUtility.start();
                String[] larrTablePrefixes = CommonUtility.convertToArray(tablePrefixes);
                switch (relDirection) {
                    case _1To2:
                        List<LiteObject> end1Relationships = this.getEnd1Relationships(startOBID, relDef, false, larrTablePrefixes);
                        if (end1Relationships != null)
                            result.addAll(end1Relationships);
                        break;
                    case _2To1:
                        List<LiteObject> end2Relationships = this.getEnd2Relationships(startOBID, relDef, false, larrTablePrefixes);
                        if (end2Relationships != null)
                            result.addAll(end2Relationships);
                        break;
                }
                //  log.info("finish to get relationship(s) quantity:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            }
            return CommonUtility.getSize(result);
        }
        return 0;
    }

    private PageResult<LiteObject> onQueryingRel(QueryRequest queryRequest, boolean intactOrSingle) throws Exception {
        if (queryRequest != null) {
            List<QueryCriteria> criteriaList = queryRequest.getCriterions();
            boolean queryOne = queryRequest.getQueryOne();
            StopWatch stopWatch = PerformanceUtility.start();
            MPJQueryWrapper<MetaDataRel> queryWrapper = this.constructJoinQueryForREL(criteriaList);
            this.setConfigForQueryWrapper(queryWrapper, queryRequest.getScopePrefix());
            this.appendOrderBy(queryWrapper, criteriaList.stream().filter(QueryCriteria::isUsedForOrdering).collect(Collectors.toList()));
            PageResult<LiteObject> liteObjects = this.onQueryingRel(queryWrapper, queryRequest.getTablePrefixes(), queryRequest.getPageRequest(), intactOrSingle, queryOne);
            // log.trace("finis to internal retrieve:" + liteObjects.getTotal() + PerformanceUtility.stop(stopWatch));
            return liteObjects;
        }
        return null;
    }

    private PageResult<LiteObject> onQueryingObject(QueryRequest queryRequest, boolean intactOrSingle) throws Exception {
        List<QueryCriteria> criteriaList = queryRequest.getCriterions();
        if (CommonUtility.hasValue(criteriaList)) {
            boolean queryOne = queryRequest.getQueryOne();
            StopWatch stopWatch = PerformanceUtility.start();
            MPJQueryWrapper<MetaDataObj> queryWrapper = this.constructJoinQueryForOBJ(criteriaList);
            this.setConfigForQueryWrapper(queryWrapper, queryRequest.getScopePrefix());
            this.appendOrderBy(queryWrapper, criteriaList.stream().filter(QueryCriteria::isUsedForOrdering).collect(Collectors.toList()));
            PageResult<LiteObject> liteObjects = this.onQueryingObject(queryWrapper, queryRequest.getTablePrefixes(), queryRequest.getPageRequest(), intactOrSingle, queryOne);
            log.trace("finis to internal retrieve:" + liteObjects.getTotal() + PerformanceUtility.stop(stopWatch));
            return liteObjects;
        }
        return null;
    }

    private QueryWrapper<MetaDataObj> generateQueryWrapper() {
        QueryWrapper<MetaDataObj> queryWrapper = this.objService.generateQueryWrapper();
        queryWrapper.lambda().isNull(MetaDataObj::getTerminationDate);
        return queryWrapper;
    }

    private QueryWrapper<MetaDataRel> generateRelQueryWrapper() {
        QueryWrapper<MetaDataRel> queryWrapper = this.relService.generateQueryWrapper();
        // 2022.11.24 HT TerminationDate isNull条件取消
        //queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate);
        return queryWrapper;
    }

    private void setNameOrDescriptionCondition(MPJLambdaWrapper<MetaDataObj> wrapper, String nameOrDesc) {
        if (wrapper != null) {
            if (!StringUtils.isEmpty(nameOrDesc)) {
                if (!StringUtils.isEmpty(nameOrDesc.replace("*", ""))) {
                    nameOrDesc = nameOrDesc.replace("*", "%");
                    if (nameOrDesc.contains("%")) {
                        String finalNameOrDesc = nameOrDesc;
                        wrapper.and(c -> c.like(MetaDataObj::getName, finalNameOrDesc).or().like(MetaDataObj::getDescription, finalNameOrDesc));
                    } else {
                        String finalNameOrDesc1 = nameOrDesc;
                        wrapper.and(c -> c.eq(MetaDataObj::getDescription, finalNameOrDesc1).or().eq(MetaDataObj::getName, finalNameOrDesc1));
                    }
                }
            }
        }
    }

    private void setNameOrDescriptionCondition(QueryWrapper<MetaDataObj> queryWrapper, String nameOrDesc) {
        if (queryWrapper != null) {
            if (!StringUtils.isEmpty(nameOrDesc)) {
                if (!StringUtils.isEmpty(nameOrDesc.replace("*", ""))) {
                    nameOrDesc = nameOrDesc.replace("*", "%");
                    if (nameOrDesc.contains("%")) {
                        String finalNameOrDesc = nameOrDesc;
                        queryWrapper.lambda().and(c -> c.like(MetaDataObj::getName, finalNameOrDesc).or().like(MetaDataObj::getDescription, finalNameOrDesc));
                    } else {
                        String finalNameOrDesc1 = nameOrDesc;
                        queryWrapper.lambda().and(c -> c.eq(MetaDataObj::getDescription, finalNameOrDesc1).or().eq(MetaDataObj::getName, finalNameOrDesc1));
                    }
                }
            }
        }
    }

    @Override
    public List<LiteObject> toLiteObject(List<MetaDataObj> objs, boolean intactOrSingle, String... parrTablePrefixes) {
        if (CommonUtility.hasValue(objs)) {
            if (intactOrSingle) {
                StopWatch stopWatch = PerformanceUtility.start();
                ResultSet<LiteObject> resultSet = this.threadsProcessor.fillingObjWithInfoDetails(objs, this.infoDetailsService.getInfoDetailsConsumer(), parrTablePrefixes);
                log.trace("to lite object completed" + PerformanceUtility.stop(stopWatch));
                if (resultSet.getResult())
                    return resultSet.getList();
                else {
                    try {
                        resultSet.Throw();
                    } catch (Exception exception) {
                        log.error(exception.getMessage());
                    }
                }
            } else
                return objs.stream().map(LiteObject::new).collect(Collectors.toList());
        }
        return null;
    }

    @Override
    public LiteObject toLiteObject(MetaDataObj metaDataObj, boolean intactOrSingle, String... parrTablePrefixes) {
        if (metaDataObj != null) {
            if (intactOrSingle) {
                StopWatch stopWatch = PerformanceUtility.start();
                ResultSet<LiteObject> resultSet = this.threadsProcessor.fillingObjWithInfoDetails(new ArrayList<MetaDataObj>() {{
                    this.add(metaDataObj);
                }}, this.infoDetailsService.getInfoDetailsConsumer(), parrTablePrefixes);
                log.trace("to lite object completed" + PerformanceUtility.stop(stopWatch));
                if (resultSet.getResult())
                    return resultSet.get();
                else
                    try {
                        resultSet.Throw();
                    } catch (Exception exception) {
                        log.error(exception.getMessage());
                    }
            } else
                return new LiteObject(metaDataObj);
        }
        return null;
    }

    private ThrowableConsumer<IfAndPRCarrier<MetaDataRel>> advancedFillingRelConsumer() {
        return new ThrowableConsumer<IfAndPRCarrier<MetaDataRel>>() {
            @Override
            public void accept0(IfAndPRCarrier<MetaDataRel> e) throws Exception {
                int tableIndexOfInterface = 1;
                int tableIndexOfProperty = 2;
                MPJQueryWrapper<MetaDataRel> queryWrapper = new MPJQueryWrapper<>();
                ConfigurationPlusDomainTableNameParser.setTablePrefix(e.getTablePrefix());
//                queryWrapper.selectAll(MetaDataRel.class);
                queryWrapper.select(CommonUtility.convertToArray(Full.generateSelectColumns()));
                queryWrapper.leftJoin(SqlHelper.joinInterfaceTable(Constant.TABLE_ALIAS, tableIndexOfInterface));
                queryWrapper.leftJoin(SqlHelper.joinPropertyTable(Constant.TABLE_ALIAS, tableIndexOfProperty, Constant.TABLE_ALIAS + tableIndexOfInterface));
                queryWrapper.in(Constant.TABLE_ALIAS + StringPool.DOT + propertyDefinitionType.OBID.getColumnName(), e.getSource().stream().map(MetaData::getObid).distinct().collect(Collectors.toList()));
                List<Map<String, Object>> maps = relService.get(queryWrapper);
                if (CommonUtility.hasValue(maps))
                    e.getResult().addAll(maps);
            }
        };
    }

    private ThrowableConsumer<IfAndPRCarrier<MetaDataObj>> advancedFillingObjConsumer() {
        return e -> {
            int tableIndexOfInterface = 1;
            int tableIndexOfProperty = 2;
            MPJQueryWrapper<MetaDataObj> queryWrapper = new MPJQueryWrapper<>();
            ConfigurationPlusDomainTableNameParser.setTablePrefix(e.getTablePrefix());
            queryWrapper.select(CommonUtility.convertToArray(Full.generateSelectColumns()));
            queryWrapper.leftJoin(SqlHelper.joinInterfaceTable(Constant.TABLE_ALIAS, tableIndexOfInterface));
            queryWrapper.leftJoin(SqlHelper.joinPropertyTable(Constant.TABLE_ALIAS, tableIndexOfProperty, Constant.TABLE_ALIAS + tableIndexOfInterface));
            queryWrapper.in(Constant.TABLE_ALIAS + StringPool.DOT + propertyDefinitionType.OBID.getColumnName(), e.getSource().stream().map(MetaData::getObid).distinct().collect(Collectors.toList()));
            List<Map<String, Object>> maps = objService.get(queryWrapper);
            if (CommonUtility.hasValue(maps))
                e.getResult().addAll(maps);
        };
    }

    @Override
    public List<LiteObject> toLiteRel(List<MetaDataRel> rels, boolean intactOrSingle, String... tablePrefixes) {
        if (CommonUtility.hasValue(rels)) {
            if (intactOrSingle) {
                List<LiteObject> result = new ArrayList<>();
                StopWatch stopWatch = PerformanceUtility.start();
                ResultSet<LiteObject> resultSet = this.threadsProcessor.fillingRelWithInfoDetails(rels, this.infoDetailsService.getInfoDetailsConsumer(), tablePrefixes);
                log.trace("to lite rel completed" + PerformanceUtility.stop(stopWatch));
                if (resultSet.getResult()) {
                    List<LiteObject> resultSetList = resultSet.getList();
                    if (CommonUtility.hasValue(resultSetList))
                        result.addAll(resultSetList);
                } else {
                    try {
                        resultSet.Throw();
                    } catch (Exception e) {
                        log.error(e.getMessage());
                    }
                }
                return result;
            } else
                return rels.stream().map(LiteObject::new).collect(Collectors.toList());
        }
        return null;
    }

    @Override
    public LiteObject toLiteRel(MetaDataRel metaDataRel, boolean intactOrSingle, String... tablePrefixes) {
        if (metaDataRel != null) {
            if (intactOrSingle) {
                StopWatch stopWatch = PerformanceUtility.start();
                ResultSet<LiteObject> resultSet = this.threadsProcessor.fillingRelWithInfoDetails(new ArrayList<MetaDataRel>() {{
                    this.add(metaDataRel);
                }}, this.infoDetailsService.getInfoDetailsConsumer(), tablePrefixes);
                log.trace("to lite rel completed" + PerformanceUtility.stop(stopWatch));
                if (resultSet.getResult())
                    return resultSet.get();
                else {
                    try {
                        resultSet.Throw();
                    } catch (Exception e) {
                        log.error(e.getMessage());
                    }
                }
            } else
                return new LiteObject(metaDataRel);
        }
        return null;
    }

    private <T extends MetaData> IMetaDataService getService(T obj) {
        if (obj != null) {
            if (obj.getClass().getName().equalsIgnoreCase(MetaDataObj.class.getName()))
                return this.objService;
            else if (obj.getClass().getName().equalsIgnoreCase(MetaDataObjProperty.class.getName()))
                return this.propertyService;
            else if (obj.getClass().getName().equalsIgnoreCase(MetaDataObjInterface.class.getName()))
                return this.interfaceService;
            else if (obj.getClass().getName().equalsIgnoreCase(MetaDataRel.class.getName()))
                return this.relService;
        }
        return null;
    }

    private <T extends MetaData> IMetaDataService getService(List<T> objs) {
        if (CommonUtility.hasValue(objs)) {
            return this.getService(objs.get(0));
        }
        return null;
    }

    protected <T extends MetaData> ThrowableConsumer<List<T>> getConsumer(IMetaDataService service, CRUD crud) {
        if (service != null) {
            switch (crud) {
                case T:
                    return service.terminateConsumer();
                case U:
                    return service.updateConsumer();
                case C:
                    return service.createConsumer();
                case D:
                    return service.deleteConsumer();
            }
        }
        return null;
    }

    @Override
    public <T extends MetaData> void addJob(ConcurrentHashMap<String, JobWrapper> jobWrappers, String uniqueKey, CRUD crud, List<T> items, ProgressLatch progressLatch) {
        if (CommonUtility.hasValue(items)) {
            IMetaDataService service = this.getService(items);
            if (service == null) {
                log.error("no service was found for " + items.get(0).getClass().getSimpleName());
                return;
            }

            if (progressLatch == null) {
                log.error("progress Latch is not initialized, please contact administrator to check it");
                return;
            }
            ThrowableConsumer throwableConsumer = this.getConsumer(service, crud);
            if (jobWrappers == null)
                jobWrappers = new ConcurrentHashMap<>();

            JobWrapper jobWrapper = jobWrappers.getOrDefault(uniqueKey, new JobWrapper());
            jobWrapper.setUniqueKey(uniqueKey);
            jobWrapper.add(crud, items, throwableConsumer);
            if (jobWrappers.containsKey(uniqueKey))
                jobWrappers.replace(uniqueKey, jobWrapper);
            else
                jobWrappers.put(uniqueKey, jobWrapper);
        }
    }

    private final DefaultIdentifierGenerator defaultIdentifierGenerator = new DefaultIdentifierGenerator();

    @Override
//    @Transactional(rollbackFor = Exception.class)
    public <T extends MetaData> void submit(ProgressLatch progressLatch, ConcurrentHashMap<String, JobWrapper> genWrappers, ConcurrentHashMap<String, JobWrapper> dropWrappers) throws Exception {
        if (CommonUtility.hasValue(genWrappers) || CommonUtility.hasValue(dropWrappers)) {
            List<DmlCallable<MetaData>> callables = new ArrayList<>();
            Map<String, DmlCallable<MetaData>> mapCallables = new HashMap<>();
            Thread currentThread = Thread.currentThread();
            String id = UUID.randomUUID() + "=====" + currentThread.getName();
            int executionOrder = 0;
            if (dropWrappers.size() > 0) {
                for (Map.Entry<String, JobWrapper> stringJobWrapperEntry : dropWrappers.entrySet()) {
                    String uniqueKey = stringJobWrapperEntry.getValue().getUniqueKey();
                    DmlCallable callable = this.threadsProcessor.generateCallable(stringJobWrapperEntry.getValue(), progressLatch, executionOrder);
                    if (callable != null) {
                        if (mapCallables.containsKey(uniqueKey))
                            mapCallables.replace(uniqueKey, callable);
                        else
                            mapCallables.put(uniqueKey, callable);
                    }
                }
            }

            if (genWrappers.size() > 0) {
                for (Map.Entry<String, JobWrapper> stringJobWrapperEntry : genWrappers.entrySet()) {
                    String uniqueKey = stringJobWrapperEntry.getValue().getUniqueKey();
                    DmlCallable<MetaData> dmlCallable = mapCallables.getOrDefault(uniqueKey, null);
                    if (mapCallables.containsKey(uniqueKey)) {
                        this.threadsProcessor.addCallableJob(dmlCallable, stringJobWrapperEntry.getValue());
                    } else {
                        dmlCallable = this.threadsProcessor.generateCallable(stringJobWrapperEntry.getValue(), progressLatch, executionOrder);
                        if (dmlCallable != null) {
                            mapCallables.put(uniqueKey, dmlCallable);
                        }
                    }
                }
            }

            if (mapCallables.size() > 0) {
                for (Map.Entry<String, DmlCallable<MetaData>> callableEntry : mapCallables.entrySet()) {
                    callables.add(callableEntry.getValue());
                }
            }

            // log.info(id + " generated thread processor(s) quantity is " + callables.size());
            this.transactionQueue.execute(new TransactionJob(this.threadsProcessor, id, callables, progressLatch));
        }
    }

    protected String[] generatePropertyColumns(String alias) {
        List<String> result = new ArrayList<>();
        result.add(alias + StringPool.DOT + "OBJ_OBID");
        result.add(alias + StringPool.DOT + "PROPERTY_DEF_UID");
        result.add(alias + StringPool.DOT + "STR_VALUE");
        result.add(alias + StringPool.DOT + "UOM");
        String[] arrayResult = new String[result.size()];
        result.toArray(arrayResult);
        return arrayResult;
    }

    @Override
    public List<MetaDataObjProperty> getPropertySummary(String propertyDefinitionUid, List<String> domainPrefixes) {
        List<MetaDataObjProperty> result = new ArrayList<>();
        if (!StringUtils.isEmpty(propertyDefinitionUid) && CommonUtility.hasValue(domainPrefixes)) {
            MPJQueryWrapper<MetaDataObjProperty> queryWrapper = new MPJQueryWrapper<>();
            queryWrapper.selectAll(MetaDataObjProperty.class);
            queryWrapper.eq(queryWrapper.getAlias() + StringPool.DOT + "PROPERTY_DEF_UID", propertyDefinitionUid);
            queryWrapper.and(c -> c.isNull(queryWrapper.getAlias() + StringPool.DOT + "TERMINATION_USER").or().eq(queryWrapper.getAlias() + StringPool.DOT + "TERMINATION_USER", ""));
            List<MetaDataObjProperty> values = this.onQueryingPropertyValue(queryWrapper, domainPrefixes);
            result.addAll(values);
        }
        if (result.size() > 0)
            result = result.stream().distinct().collect(Collectors.toList());
        return result;
    }

    protected void setClassDefCondition(MPJLambdaWrapper<MetaDataObj> queryWrapper, String classDef) {
        if (queryWrapper != null) {
            if (StringUtils.isEmpty(classDef) || classDef.equalsIgnoreCase("*"))
                return;
            classDef = classDef.replace("*", "%");
            if (classDef.contains("%"))
                queryWrapper.like(MetaDataObj::getClassDefinitionUid, classDef);
            else
                queryWrapper.eq(MetaDataObj::getClassDefinitionUid, classDef);
        }
    }

    private PageResult<MetaDataRel> onQueryingRel(QueryWrapper<MetaDataRel> queryWrapper, PageRequest
            pageRequest, String tablePrefix) {
        PageResult<MetaDataRel> result = null;
        try {
            if (queryWrapper != null) {
                StopWatch stopWatch = PerformanceUtility.start();
                boolean usePageSelector = this.usePageSelector(pageRequest);
                ConfigurationPlusDomainTableNameParser.setTablePrefix(tablePrefix);
                if (usePageSelector) {
                    PageResult<MetaDataRel> pageResult = this.relService.get(queryWrapper, pageRequest.getPageIndex(), pageRequest.getPageSize());
                    log.trace("query with page:" + CommonUtility.getSize(pageResult.getResultList()) + PerformanceUtility.stop(stopWatch));
                    result = pageResult;
                } else {
                    List<MetaDataRel> objs = this.relService.get(queryWrapper);
                    log.trace("query without page:" + CommonUtility.getSize(objs) + PerformanceUtility.stop(stopWatch));
                    result = new PageResult<>(objs);
                }
                ConfigurationPlusDomainTableNameParser.reset();
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
        }
        return result;
    }

    private PageResult<MetaDataRel> onQueryingRel(MPJQueryWrapper<MetaDataRel> queryWrapper, PageRequest pageRequest, String tablePrefix) {
        PageResult<MetaDataRel> result = null;
        try {
            if (queryWrapper != null) {
                StopWatch stopWatch = PerformanceUtility.start();
                boolean usePageSelector = this.usePageSelector(pageRequest);
                ConfigurationPlusDomainTableNameParser.setTablePrefix(tablePrefix);
                if (usePageSelector) {
                    PageResult<MetaDataRel> pageResult = this.relService.get(queryWrapper, pageRequest.getPageIndex(), pageRequest.getPageSize());
                    log.trace("query with page:" + CommonUtility.getSize(pageResult.getResultList()) + PerformanceUtility.stop(stopWatch));
                    result = pageResult;
                } else {
                    List<MetaDataRel> objs = this.relService.get(MetaDataRel.class, queryWrapper);
                    log.trace("query without page:" + CommonUtility.getSize(objs) + PerformanceUtility.stop(stopWatch));
                    result = new PageResult<>(objs);
                }
                ConfigurationPlusDomainTableNameParser.reset();
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
        }
        return result;
    }

    private PageResult<MetaDataObj> onQueryingObject(MPJQueryWrapper<MetaDataObj> queryWrapper, PageRequest pageRequest, String tablePrefix) {
        PageResult<MetaDataObj> result = null;
        try {
            if (queryWrapper != null) {
                StopWatch stopWatch = PerformanceUtility.start();
                boolean usePageSelector = this.usePageSelector(pageRequest);
                ConfigurationPlusDomainTableNameParser.setTablePrefix(tablePrefix);
                if (usePageSelector) {
                    PageResult<MetaDataObj> pageResult = this.objService.get(queryWrapper, pageRequest.getPageIndex(), pageRequest.getPageSize());
                    log.trace("query with page:" + CommonUtility.getSize(pageResult.getResultList()) + PerformanceUtility.stop(stopWatch));
                    result = pageResult;
                } else {
                    List<MetaDataObj> objs = this.objService.get(MetaDataObj.class, queryWrapper);
                    log.trace("query without page:" + CommonUtility.getSize(objs) + PerformanceUtility.stop(stopWatch));
                    result = new PageResult<>(objs, false);
                }
                ConfigurationPlusDomainTableNameParser.reset();
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
        }
        return result;
    }

    private PageResult<MetaDataObj> onQueryingObject(MPJLambdaWrapper<MetaDataObj> queryWrapper, PageRequest
            pageRequest, String tablePrefix) {
        PageResult<MetaDataObj> result = null;
        try {
            if (queryWrapper != null) {
                StopWatch stopWatch = PerformanceUtility.start();
                boolean usePageSelector = this.usePageSelector(pageRequest);
                ConfigurationPlusDomainTableNameParser.setTablePrefix(tablePrefix);
                if (usePageSelector) {
                    PageResult<MetaDataObj> pageResult = this.objService.get(queryWrapper, pageRequest.getPageIndex(), pageRequest.getPageSize());
                    log.trace("query with page:" + CommonUtility.getSize(pageResult.getResultList()) + PerformanceUtility.stop(stopWatch));
                    result = pageResult;
                } else {
                    List<MetaDataObj> objs = this.objService.get(MetaDataObj.class, queryWrapper);
                    log.trace("query without page:" + CommonUtility.getSize(objs) + PerformanceUtility.stop(stopWatch));
                    result = new PageResult<>(objs);
                }
                ConfigurationPlusDomainTableNameParser.reset();
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
        }
        return result;
    }

    protected boolean usePageSelector(PageRequest pageRequest) {
        if (pageRequest != null) {
            return pageRequest.getPageIndex() > 0 && pageRequest.getPageSize() > 0;
        }
        return false;
    }

    private PageResult<MetaDataObj> onQueryingObject(QueryWrapper<MetaDataObj> queryWrapper, PageRequest pageRequest, String tablePrefix) {
        PageResult<MetaDataObj> result = null;
        try {
            if (queryWrapper != null) {
                StopWatch stopWatch = PerformanceUtility.start();
                boolean usePageSelector = this.usePageSelector(pageRequest);
                ConfigurationPlusDomainTableNameParser.setTablePrefix(tablePrefix);
                if (usePageSelector) {
                    PageResult<MetaDataObj> pageResult = this.objService.get(queryWrapper, pageRequest.getPageIndex(), pageRequest.getPageSize());
                    log.trace("query with page:" + CommonUtility.getSize(pageResult.getResultList()) + PerformanceUtility.stop(stopWatch));
                    result = pageResult;
                } else {
                    List<MetaDataObj> objs = this.objService.get(queryWrapper);
                    log.trace("query without page:" + CommonUtility.getSize(objs) + PerformanceUtility.stop(stopWatch));
                    result = new PageResult<>(objs, false);
                }
                ConfigurationPlusDomainTableNameParser.reset();
            }
        } catch (Exception exception) {
            log.error(exception.getMessage());
        }
        return result;
    }

    @Override
    public PageResult<LiteObject> getObjectsByNameOrDescription(String nameOrDescription, String classDef, String
            interfaceDef, List<String> tablePrefixes) {
        StopWatch stopWatch = PerformanceUtility.start();
        MPJLambdaWrapper<MetaDataObj> lambdaWrapper = new MPJLambdaWrapper<MetaDataObj>()
                .selectAll(MetaDataObj.class)
                .innerJoin(MetaDataObjInterface.class, MetaDataObjInterface::getObjObid, MetaDataObj::getObid)
                .eq(MetaDataObjInterface::getInterfaceDefUid, interfaceDef);
        this.setNameOrDescriptionCondition(lambdaWrapper, nameOrDescription);
        this.setClassDefCondition(lambdaWrapper, classDef);
        PageResult<LiteObject> result = this.onQueryingObject(lambdaWrapper, tablePrefixes, null, false, false);
        log.info("get object(s) by name and description completed" + PerformanceUtility.stop(stopWatch));
        return result;
    }


    @Override
    public List<MetaDataRel> getEndRelationships(List<String> obids, String relDef, relDirection
            direction, List<String> tablePrefixes) {
        if (CommonUtility.hasValue(obids)) {
            List<Callable<List<MetaDataRel>>> processors = new ArrayList<>();
            List<List<String>> splitLists = CommonUtility.createList(obids);
            for (List<String> list : splitLists) {
                for (String tablePrefix : tablePrefixes) {
                    QueryWrapper<MetaDataRel> queryWrapper = this.generateRelQueryWrapper();
                    switch (direction) {
                        case _2To1:
                            queryWrapper.lambda().in(MetaDataRel::getObid2, list);
                            break;
                        case _1To2:
                            queryWrapper.lambda().in(MetaDataRel::getObid1, list);
                            break;
                    }
                    if (!StringUtils.isEmpty(relDef))
                        queryWrapper.lambda().eq(MetaDataRel::getRelDefUid, relDef);
                    List<MetaDataRel> lcolCollection = new ArrayList<>();
                    CallableBase<MetaDataRel> relCallableBase = new CallableBase<MetaDataRel>(lcolCollection, this.relService.queryConsumer(queryWrapper, tablePrefix));
                    processors.add(relCallableBase);
                }
            }
            return this.threadsProcessor.executeList(processors);
        }
        return null;
    }


    @Override
    public List<LiteObject> getEnd1Relationships(String startOBID, String relDef, boolean intactOrSingle, String...
            tablePrefixes) {
        List<LiteObject> result = new ArrayList<>();
        if (!StringUtils.isEmpty(startOBID) && !StringUtils.isEmpty(relDef) && CommonUtility.hasValue(tablePrefixes)) {
            List<MetaDataRel> rels = this.getEndRelationships(new ArrayList<String>() {{
                this.add(startOBID);
            }}, relDef, relDirection._1To2, Arrays.stream(tablePrefixes).collect(Collectors.toList()));
            try {
                List<LiteObject> liteObjects = this.toLiteRel(rels.stream().distinct().collect(Collectors.toList()), intactOrSingle, tablePrefixes);
                if (liteObjects != null)
                    result.addAll(liteObjects);
            } catch (Exception exception) {
                log.error(exception.getMessage());
            }
        }
        return result;
    }

    @Override
    public List<LiteObject> getEnd2Relationships(String startOBID, String relDef, boolean intactOrSingle, String...
            tablePrefixes) {
        List<LiteObject> result = new ArrayList<>();
        if (!StringUtils.isEmpty(startOBID) && !StringUtils.isEmpty(relDef) && CommonUtility.hasValue(tablePrefixes)) {
            List<MetaDataRel> rels = this.getEndRelationships(new ArrayList<String>() {{
                this.add(startOBID);
            }}, relDef, relDirection._2To1, Arrays.stream(tablePrefixes).collect(Collectors.toList()));
            try {
                List<LiteObject> liteObjects = this.toLiteRel(rels.stream().distinct().collect(Collectors.toList()), intactOrSingle, tablePrefixes);
                if (liteObjects != null)
                    result.addAll(liteObjects);
            } catch (Exception exception) {
                log.error(exception.getMessage());
            }
        }
        return result;
    }
}
