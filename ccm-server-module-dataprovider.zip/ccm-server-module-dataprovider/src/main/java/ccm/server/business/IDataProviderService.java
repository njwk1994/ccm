package ccm.server.business;

import ccm.server.entity.*;
import ccm.server.enums.CRUD;
import ccm.server.enums.relDirection;
import ccm.server.models.LiteObject;
import ccm.server.models.page.PageResult;
import ccm.server.models.query.ExpansionWrapper;
import ccm.server.models.query.QueryRequest;
import ccm.server.module.service.base.IInternalService;
import ccm.server.processors.ProgressLatch;
import ccm.server.service.*;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public interface IDataProviderService extends IInternalService {
    IMetaDataRelService dataRelService();

    IMetaDataObjInterfaceService dataInterfaceService();

    IMetaDataObjPropertyDetailsService dataPropertyDetailsService();

    IMetaDataObjPropertyService dataPropertyService();

    IMetaDataObjService dataObjectService();

    PageResult<LiteObject> getObjects(QueryRequest request, boolean intactOrSingle) throws Exception;

    PageResult<LiteObject> getRelationships(QueryRequest queryRequest, boolean intactOrSingle) throws Exception;

    List<LiteObject> getRelationships(ExpansionWrapper expansionWrapper);

    int getRelationshipsCount(String startOBID, String relDef, relDirection relDirection, List<String> tablePrefixes);

    PageResult<LiteObject> getObjectsByNameOrDescription(String nameOrDescription, String classDef, String interfaceDef, List<String> tablePrefixes) throws Exception;

    List<LiteObject> getEnd1Relationships(String startOBID, String relDef, boolean intactOrSingle, String... tablePrefixes);

    List<MetaDataRel> getEndRelationships(List<String> startOBID, String relDef, relDirection direction, List<String> tablePrefixes);

    List<LiteObject> getEnd2Relationships(String startOBID, String relDef, boolean intactOrSingle, String... tablePrefixes);

    List<LiteObject> toLiteObject(List<MetaDataObj> metaDataObjs, boolean intactOrSingle, String... parrTablePrefixes);

    LiteObject toLiteObject(MetaDataObj metaDataObj, boolean intactOrSingle, String... parrTablePrefixes);

    List<LiteObject> toLiteRel(List<MetaDataRel> metaDataRels, boolean intactOrSingle, String... parrTablePrefixes);

    LiteObject toLiteRel(MetaDataRel metaDataRel, boolean intactOrSingle, String... tablePrefixes);

    <T extends MetaData> void addJob(ConcurrentHashMap<String, JobWrapper> jobWrappers, String uniqueKey, CRUD crud, List<T> sourceItems, ProgressLatch progressLatch);

    <T extends MetaData> void submit(ProgressLatch progressLatch, ConcurrentHashMap<String, JobWrapper> genWrappers, ConcurrentHashMap<String, JobWrapper> dropWrappers) throws Exception;

    List<MetaDataObjProperty> getPropertySummary(String propertyDefinitionUid, List<String> domainPrefixes);
}
