package ccm.server.business.impl;

import ccm.server.business.IDataProviderService;
import ccm.server.business.ISchemaProviderService;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataRel;
import ccm.server.enums.classDefinitionType;
import ccm.server.enums.domainInfo;
import ccm.server.enums.interfaceDefinitionType;
import ccm.server.enums.relDefinitionType;
import ccm.server.handlers.ConfigurationPlusDomainTableNameParser;
import ccm.server.models.LiteObject;
import ccm.server.models.page.PageResult;
import ccm.server.module.impl.general.InternalServiceImpl;
import ccm.server.service.IMetaDataObjService;
import ccm.server.service.IMetaDataRelService;
import ccm.server.util.CommonUtility;
import ccm.server.util.GeneralUtility;
import ccm.server.util.PerformanceUtility;
import ccm.server.util.ReentrantLockUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.Collectors;

@Service("schemaProviderServiceImpl")
@Slf4j
public class SchemaProviderServiceImpl extends InternalServiceImpl implements ISchemaProviderService {
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    public static final ConcurrentHashMap<String, LiteObject> cachedClassDefs = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedInterfaceDefs = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedPropertyDefs = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedRelDefs = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedEnumListLevelTypes = new ConcurrentHashMap<>();
    public static final CopyOnWriteArrayList<LiteObject> cachedEnumListTypes = new CopyOnWriteArrayList<>();
    public static final CopyOnWriteArrayList<LiteObject> cachedEnumEnum = new CopyOnWriteArrayList<>();
    public static final ConcurrentHashMap<String, List<LiteObject>> cachedSchemaRels = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, List<LiteObject>> cachedPropertyValueTypes = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedDomain = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedForms = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedSections = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedDisplayItems = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> otherCachedInfo = new ConcurrentHashMap<>();
    public static final ConcurrentHashMap<String, LiteObject> cachedPlants = new ConcurrentHashMap<>();
    @Autowired
    private IMetaDataObjService metaObjService;
    @Autowired
    private IMetaDataRelService metaRelService;
    @Autowired
    private IDataProviderService dataProviderService;

    @Override
    public LiteObject getSchemaObject(String uid) {
        if (!StringUtils.isEmpty(uid)) {
            ConfigurationPlusDomainTableNameParser.setConfigurationAndDomainGroupAlias(null, domainInfo.SCHEMA.toString());
            MetaDataObj metaDataObj = this.metaObjService.getByUID(uid);
            if (metaDataObj != null)
                return this.dataProviderService.toLiteObject(metaDataObj, true);
        }
        return null;
    }

    @Override
    public String getImpliesInfo(String interfaceDefinitionUID) {
        if (!StringUtils.isEmpty(interfaceDefinitionUID)) {

        }
        return null;
    }

    @Override
    public void refreshSchemaObjs() throws Exception {
        Exception ex = null;
        StopWatch stopWatch = PerformanceUtility.start();
        try {
            ReentrantLockUtility.tryToAcquireWriteLock(this.lock);
            log.info("enter to refresh schema object(s)");
            List<LiteObject> schemaLiteObjects = this.dataProviderService.toLiteObject(this.metaObjService.getSchemaObjects(null), true);
            this.amountRelationships();
            if (CommonUtility.hasValue(schemaLiteObjects)) {
                List<LiteObject> classDefs = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.ClassDef);
                this.amountClassDef(classDefs);

                List<LiteObject> interfaceDefs = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.InterfaceDef);
                this.amountInterfaceDef(interfaceDefs);

                List<LiteObject> propertyDefs = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.PropertyDef);
                this.amountPropertyDef(propertyDefs);

                List<LiteObject> relDefs = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.RelDef);
                this.amountRelDef(relDefs);

                List<LiteObject> enumEnums = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.EnumEnum);
                this.amountEnumEnum(enumEnums);

                List<LiteObject> enumListLevelTypes = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.EnumListLevelType);
                this.amountEnumListLevelType(enumListLevelTypes);

                List<LiteObject> enumListTypes = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.EnumListType);
                this.amountEnumListType(enumListTypes);

                List<LiteObject> domains = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.Domain);
                this.amountDomainDetails(domains);

                List<LiteObject> forms = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.CIMForm);
                this.amountFormDetails(forms);

                List<LiteObject> sections = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.CIMSection);
                this.amountSectionDetails(sections);

                List<LiteObject> displayItems = this.getSchemaObjectsByClassDef(schemaLiteObjects, classDefinitionType.CIMDisplayItem);
                this.amountDisplayItemDetails(displayItems);

                if (CommonUtility.hasValue(schemaLiteObjects))
                    this.refreshOtherCachedInfo(schemaLiteObjects);
            }
            this.refreshPropertyValueTypes();
        } catch (Exception exception) {
            log.error("refresh schema object(s) failed", exception);
            ex = exception;
        } finally {
            this.lock.writeLock().unlock();
            log.info("finish to refresh schema object(s) into cached and application context" + PerformanceUtility.stop(stopWatch));
        }
        if (ex != null)
            throw ex;
    }

    private void amountDisplayItemDetails(List<LiteObject> items) {
        if (CommonUtility.hasValue(items)) {
            cachedDisplayItems.clear();
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> section2DisplayItemsRels = cachedSchemaRels.getOrDefault(relDefinitionType.section2DisplayItems.toString(), null);
            for (LiteObject item : items) {
                if (section2DisplayItemsRels != null)
                    item.collectEnd2Relationship(section2DisplayItemsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                cachedDisplayItems.put(item.getObjUID(), item);
            }
            log.info("cached display item(s) completed with " + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountFormDetails(List<LiteObject> items) {
        if (CommonUtility.hasValue(items)) {
            cachedForms.clear();
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> classDefFormsRels = cachedSchemaRels.getOrDefault(relDefinitionType.classDefForms.toString(), null);
            List<LiteObject> form2SectionsRels = cachedSchemaRels.getOrDefault(relDefinitionType.form2Sections.toString(), null);
            for (LiteObject item : items) {
                if (classDefFormsRels != null)
                    item.collectEnd2Relationship(classDefFormsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                if (form2SectionsRels != null)
                    item.collectEnd1Relationship(form2SectionsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid1().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                cachedForms.put(item.getObjUID(), item);
            }
            log.info("cached form(s) completed with " + PerformanceUtility.stop(stopWatch));
        }
    }

    protected void amountSectionDetails(List<LiteObject> items) {
        if (CommonUtility.hasValue(items)) {
            cachedSections.clear();
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> form2SectionsRels = cachedSchemaRels.getOrDefault(relDefinitionType.form2Sections.toString(), null);
            List<LiteObject> section2DisplayItemsRels = cachedSchemaRels.getOrDefault(relDefinitionType.section2DisplayItems.toString(), null);
            for (LiteObject item : items) {
                if (form2SectionsRels != null)
                    item.collectEnd2Relationship(form2SectionsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                if (section2DisplayItemsRels != null)
                    item.collectEnd1Relationship(section2DisplayItemsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid1().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                cachedSections.put(item.getObjUID(), item);
            }
            log.info("cached section(s) completed with " + PerformanceUtility.stop(stopWatch));
        }
    }

    protected List<LiteObject> getSchemaObjectsByClassDef(List<LiteObject> schemaObjects, classDefinitionType classDefinitionType) {
        if (CommonUtility.hasValue(schemaObjects)) {
            List<LiteObject> result = schemaObjects.stream().filter(c -> c.getClassDefinitionUid().equalsIgnoreCase(classDefinitionType.toString())).collect(Collectors.toList());
            if (CommonUtility.hasValue(result)) {
                log.info("cached " + classDefinitionType.toString() + " quantity:" + CommonUtility.getSize(result));
                schemaObjects.removeAll(result);
                return result;
            }
        }
        return null;
    }

    private void amountDomainDetails(List<LiteObject> items) {
        if (CommonUtility.hasValue(items)) {
            cachedDomain.clear();
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> classDefDomainInfoRels = cachedSchemaRels.getOrDefault(relDefinitionType.classDefDomainInfo.toString(), null);
            for (LiteObject item : items) {
                if (classDefDomainInfoRels != null)
                    item.collectEnd2Relationship(classDefDomainInfoRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                cachedDomain.put(item.getObjUID(), item);
            }
            log.info("cached domain(s) completed with " + PerformanceUtility.stop(stopWatch));
        }
    }

    private void refreshPropertyValueTypes() throws Exception {
        log.trace("enter to refresh property value type(s)");
        StopWatch stopWatch = PerformanceUtility.start();
        PageResult<LiteObject> propertyValueTypes = this.dataProviderService.getObjectsByNameOrDescription("", "", interfaceDefinitionType.IPropertyType.toString(), new ArrayList<String>() {{
            this.add(domainInfo.SCHEMA.toString());
        }});
        cachedPropertyValueTypes.clear();
        if (propertyValueTypes != null) {
            log.info("property value types from database quantity:" + propertyValueTypes.getResultList().size());
            List<LiteObject> resultList = propertyValueTypes.getResultList();
            if (resultList == null || resultList.size() == 0)
                throw new Exception("invalid property type(s) in current database");
            for (LiteObject liteObject : resultList) {
                CommonUtility.doAddElementGeneral(cachedPropertyValueTypes, liteObject.getClassDefinitionUid(), liteObject);
            }
        }
        log.info("finish to process property value type(s):" + cachedPropertyValueTypes.size() + PerformanceUtility.stop(stopWatch));
    }

    private void amountRelationships() throws Exception {
        log.trace("enter to get all schema relationship");
        StopWatch stopWatch = PerformanceUtility.start();
        List<MetaDataRel> relationships = this.metaRelService.getRelationshipsByRelDef(relDefinitionType.getRequiredToCachedRelDefs());
        List<LiteObject> relationshipLites = this.dataProviderService.toLiteRel(relationships, true);
        cachedSchemaRels.clear();
        if (CommonUtility.hasValue(relationshipLites))
            cachedSchemaRels.putAll(relationshipLites.stream().collect(Collectors.groupingBy(c -> c.getREL().getRelDefUid())));
        log.trace("finish to refresh schema rel:" + cachedSchemaRels.size() + PerformanceUtility.stop(stopWatch));
    }

    protected List<LiteObject> getObjectFromCachedOtherWithClassDefinitionUID(String classDefinitionUID) {
        if (!StringUtils.isEmpty(classDefinitionUID)) {
            if (otherCachedInfo.size() > 0) {
                List<LiteObject> result = new ArrayList<>();
                for (Map.Entry<String, LiteObject> objectEntry : otherCachedInfo.entrySet()) {
                    if (objectEntry.getValue().getClassDefinitionUid().equalsIgnoreCase(classDefinitionUID))
                        result.add(objectEntry.getValue());
                }
                return result;
            }
        }
        return null;
    }

    @Override
    public List<LiteObject> getCachedSchemaInfo(classDefinitionType classDefinitionType) {
        ArrayList<LiteObject> result = new ArrayList<>();
        if (classDefinitionType != null) {
            log.trace("enter to get cached schema info with " + classDefinitionType.toString());
            switch (classDefinitionType) {
                case ClassDef:
                    result.addAll(new ArrayList<>(cachedClassDefs.values()));
                    break;
                case RelDef:
                    result.addAll(new ArrayList<>(cachedRelDefs.values()));
                    break;
                case PropertyDef:
                    result.addAll(new ArrayList<>(cachedPropertyDefs.values()));
                    break;
                case EnumEnum:
                    result.addAll(cachedEnumEnum);
                    break;
                case EnumListType:
                    result.addAll(cachedEnumListTypes);
                    break;
                case EnumListLevelType:
                    result.addAll(new ArrayList<>(cachedEnumListLevelTypes.values()));
                    break;
                case InterfaceDef:
                    result.addAll(new ArrayList<>(cachedInterfaceDefs.values()));
                    break;
                case ALL:
                    result.addAll(new ArrayList<>(cachedClassDefs.values()));
                    result.addAll(new ArrayList<>(cachedRelDefs.values()));
                    result.addAll(new ArrayList<>(cachedPropertyDefs.values()));
                    result.addAll(cachedEnumEnum);
                    result.addAll(cachedEnumListTypes);
                    result.addAll(new ArrayList<>(cachedEnumListLevelTypes.values()));
                    result.addAll(new ArrayList<>(cachedInterfaceDefs.values()));
                    result.addAll(new ArrayList<>(cachedDomain.values()));
                    result.addAll(new ArrayList<>(cachedDisplayItems.values()));
                    result.addAll(new ArrayList<>(cachedSections.values()));
                    result.addAll(new ArrayList<>(cachedForms.values()));
                    result.addAll(new ArrayList<>(cachedPlants.values()));
                    for (Map.Entry<String, List<LiteObject>> stringListEntry : cachedSchemaRels.entrySet())
                        result.addAll(stringListEntry.getValue());
                    for (Map.Entry<String, List<LiteObject>> stringListEntry : cachedPropertyValueTypes.entrySet())
                        result.addAll(stringListEntry.getValue());
                    result.addAll(new ArrayList<>(otherCachedInfo.values()));
                    break;
                case Domain:
                    result.addAll(new ArrayList<>(cachedDomain.values()));
                    break;
                default:
                    result.addAll(this.getObjectFromCachedOtherWithClassDefinitionUID(classDefinitionType.toString()));
                    break;
            }
        }
        return result;
    }

    @Override
    public List<LiteObject> getPropertyValueTypes() {
        List<LiteObject> result = new ArrayList<>();
        for (Map.Entry<String, List<LiteObject>> stringListEntry : cachedPropertyValueTypes.entrySet())
            result.addAll(stringListEntry.getValue());
        return result.stream().distinct().collect(Collectors.toList());
    }

    @Override
    public IDataProviderService dataProvider() {
        return this.dataProviderService;
    }

    @Override
    public List<LiteObject> getSchemaRels() {
        List<LiteObject> result = new ArrayList<>();
        if (cachedSchemaRels.size() > 0) {
            for (Map.Entry<String, List<LiteObject>> stringListEntry : cachedSchemaRels.entrySet())
                result.addAll(stringListEntry.getValue());
        }
        return result;
    }

    protected void refreshOtherCachedInfo(List<LiteObject> items) {
        if (CommonUtility.hasValue(items)) {
            StopWatch stopWatch = PerformanceUtility.start();
            for (LiteObject item : items)
                otherCachedInfo.putIfAbsent(item.getOBID(), item);
            log.trace("finish to process other cached info:" + otherCachedInfo.size() + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountEnumListLevelType(List<LiteObject> items) {
        log.trace("enter to refresh enum list level definition(s):" + CommonUtility.getSize(items));
        if (CommonUtility.hasValue(items)) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> baseEnumListTypeForEnumListLevelTypeRels = cachedSchemaRels.getOrDefault(relDefinitionType.baseEnumListTypeForEnumListLevelType.toString(), null);
            List<LiteObject> usedEdgeDefForEnumListLevelTypeRels = cachedSchemaRels.getOrDefault(relDefinitionType.usedEdgeDefForEnumListLevelType.toString(), null);
            for (LiteObject item : items) {
                if (baseEnumListTypeForEnumListLevelTypeRels != null)
                    item.collectEnd1Relationship(baseEnumListTypeForEnumListLevelTypeRels.stream().map(LiteObject::getREL).filter(c -> c.getUid1().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                if (usedEdgeDefForEnumListLevelTypeRels != null)
                    item.collectEnd1Relationship(usedEdgeDefForEnumListLevelTypeRels.stream().map(LiteObject::getREL).filter(c -> c.getUid1().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                GeneralUtility.add(cachedEnumListLevelTypes, item.getObjUID(), item);
            }
            log.trace("complete to process enumerated list type(s):" + cachedEnumListLevelTypes.size() + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountEnumEnum(List<LiteObject> items) throws Exception {
        log.trace("enter to refresh enum list definition(s):" + CommonUtility.getSize(items));
        if (CommonUtility.hasValue(items)) {
            cachedEnumEnum.clear();
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> containsRels = cachedSchemaRels.getOrDefault(relDefinitionType.contains.toString(), null);
            for (LiteObject item : items) {
                if (containsRels != null)
                    item.collectEnd2Relationship(containsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
            }
            cachedEnumEnum.addAll(items);
            log.trace("finish to process enumerated entries:" + cachedEnumEnum.size() + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountEnumListType(List<LiteObject> items) throws Exception {
        log.trace("enter to refresh enum list type definition(s):" + CommonUtility.getSize(items));
        if (CommonUtility.hasValue(items)) {
            StopWatch stopWatch = PerformanceUtility.start();
            cachedEnumListTypes.clear();
            List<LiteObject> containsRels = cachedSchemaRels.getOrDefault(relDefinitionType.contains.toString(), null);
            for (LiteObject item : items) {
                if (containsRels != null) {
                    item.collectEnd1Relationship(containsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid1().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                    item.collectEnd2Relationship(containsRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(item.getObjUID())).collect(Collectors.toList()));
                }
            }
            cachedEnumListTypes.addAll(items);
            log.trace("finish to process enumerated list type(s):" + cachedEnumListTypes.size() + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountRelDef(List<LiteObject> items) {
        log.trace("enter to refresh relationship definition(s):" + CommonUtility.getSize(items));
        if (CommonUtility.hasValue(items)) {
            StopWatch stopWatch = PerformanceUtility.start();
            for (LiteObject item : items)
                GeneralUtility.add(cachedRelDefs, item.getName(), item);
            log.trace("finish to process relationship definition(s):" + cachedRelDefs.size() + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountPropertyDef(List<LiteObject> items) {
        log.trace("enter to refresh property definition(s):" + CommonUtility.getSize(items));
        if (CommonUtility.hasValue(items)) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> exposesRels = cachedSchemaRels.getOrDefault(relDefinitionType.exposes.toString(), null);
            List<LiteObject> scopedByRels = cachedSchemaRels.getOrDefault(relDefinitionType.scopedBy.toString(), null);
            for (LiteObject item : items) {
                String uid = item.getObjUID();
                if (scopedByRels != null)
                    item.collectEnd1Relationship(scopedByRels.stream().map(LiteObject::getREL).filter(c -> c.getUid1().equalsIgnoreCase(uid)).collect(Collectors.toList()));
                if (exposesRels != null)
                    item.collectEnd2Relationship(exposesRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(uid)).collect(Collectors.toList()));
                GeneralUtility.add(cachedPropertyDefs, item.getObjUID(), item);
            }
            log.trace("finish to process property definition(s):" + cachedPropertyDefs.size() + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountInterfaceDef(List<LiteObject> interfaceDefinitions) {
        log.trace("enter to refresh interface definition(s):" + CommonUtility.getSize(interfaceDefinitions));
        if (CommonUtility.hasValue(interfaceDefinitions)) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> realizesRels = cachedSchemaRels.getOrDefault(relDefinitionType.realizes.toString(), null);
            List<LiteObject> exposesRels = cachedSchemaRels.getOrDefault(relDefinitionType.exposes.toString(), null);
            for (LiteObject interfaceDefinition : interfaceDefinitions) {
                String interfaceDefinitionUID = interfaceDefinition.getObjUID();
                if (exposesRels != null)
                    interfaceDefinition.collectEnd1Relationship(exposesRels.stream().map(LiteObject::getREL).filter(c -> c.getUid1().equalsIgnoreCase(interfaceDefinitionUID)).collect(Collectors.toList()));
                if (realizesRels != null)
                    interfaceDefinition.collectEnd2Relationship(realizesRels.stream().map(LiteObject::getREL).filter(c -> c.getUid2().equalsIgnoreCase(interfaceDefinitionUID)).collect(Collectors.toList()));
                GeneralUtility.add(cachedInterfaceDefs, interfaceDefinition.getObjUID(), interfaceDefinition);
            }
            log.trace("finish to process interface definition(s):" + cachedInterfaceDefs.size() + PerformanceUtility.stop(stopWatch));
        }
    }

    private void amountClassDef(List<LiteObject> classDefinitions) {
        log.trace("enter to amount class definition(s):" + CommonUtility.getSize(classDefinitions));
        if (CommonUtility.hasValue(classDefinitions)) {
            StopWatch stopWatch = PerformanceUtility.start();
            List<LiteObject> relsOrDefault = cachedSchemaRels.getOrDefault(relDefinitionType.realizes.toString(), null);
            for (LiteObject classDef : classDefinitions) {
                if (relsOrDefault != null) {
                    List<LiteObject> rels = relsOrDefault.stream().filter(c -> c.getREL().getUid1().equalsIgnoreCase(classDef.getObjUID())).collect(Collectors.toList());
                    if (CommonUtility.hasValue(rels))
                        classDef.collectEnd1Relationship(rels.stream().map(LiteObject::getREL).collect(Collectors.toList()));
                }
                GeneralUtility.add(cachedClassDefs, classDef.getObjUID(), classDef);
            }
            log.trace("complete to amount class definition(s) progress:" + cachedClassDefs.size() + PerformanceUtility.stop(stopWatch));
        }
    }
}
