//package ccm.server.module.mapper;
//
//import com.baomidou.dynamic.datasource.annotation.DS;
//import org.apache.ibatis.annotations.Mapper;
//
//import java.util.Map;
//
///**
// * @author HuangTao
// * @version 1.0
// * @since 2021/10/21 22:21
// */
//@Mapper
//public interface ProcedureExecuteMapper {
//
//    @DS("spm_db")
//    Map<String,Object> createNewStatusRequest(Map<String, Object> prams);
//
//}
