package ccm.server.module.mapper;

import ccm.server.entity.MetaDataObjInterface;
import com.github.yulichang.base.MPJBaseMapper;

public interface MetaDataObjInterfaceMapper extends MPJBaseMapper<MetaDataObjInterface> {
}
