package ccm.server.module.mapper;


import ccm.server.entity.MetaDataObjPropertyDetails;
import com.github.yulichang.base.MPJBaseMapper;

public interface MetaDataObjPropertyDetailsMapper extends MPJBaseMapper<MetaDataObjPropertyDetails> {
}
