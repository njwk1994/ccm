package ccm.server.module.mapper;

import ccm.server.models.LiteObjectPart;
import com.github.yulichang.base.MPJBaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Param;
import com.baomidou.mybatisplus.core.conditions.Wrapper;

import java.util.List;

public interface LiteObjectPartMapper extends MPJBaseMapper<LiteObjectPart> {

    List<LiteObjectPart> getLiteObjectParts(@Param("fromSqlPart") String fromSqlPart);
}
