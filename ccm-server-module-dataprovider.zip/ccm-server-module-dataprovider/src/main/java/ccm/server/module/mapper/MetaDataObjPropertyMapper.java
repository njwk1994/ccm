package ccm.server.module.mapper;

import ccm.server.entity.MetaDataObjProperty;
import com.github.yulichang.base.MPJBaseMapper;

public interface MetaDataObjPropertyMapper extends MPJBaseMapper<MetaDataObjProperty> {
}
