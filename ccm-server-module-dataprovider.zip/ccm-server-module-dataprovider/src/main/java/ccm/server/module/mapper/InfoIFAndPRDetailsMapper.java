package ccm.server.module.mapper;

import ccm.server.models.info.InfoIFAndPRDetail;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.github.yulichang.base.MPJBaseMapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Param;
import com.baomidou.mybatisplus.core.conditions.Wrapper;

import java.util.List;

public interface InfoIFAndPRDetailsMapper extends MPJBaseMapper<InfoIFAndPRDetail> {
    @Select("SELECT DISTINCT " +
            "t1.Obid AS interface_obid," +
            "t1.Obj_Obid AS interface_obj_obid," +
            "t1.Interface_Def_Uid AS interface_interface_def_uid," +
            "t1.Creation_Date AS interface_creation_date," +
            "t1.Termination_Date AS interface_termination_date," +
            "t1.Creation_User AS interface_creation_user," +
            "t1.Termination_User AS interface_termination_user," +
            "t2.Obid AS property_obid," +
            "t2.Obj_Obid AS property_obj_obid," +
            "t2.Property_Def_Uid AS property_property_def_uid," +
            "t2.Interface_Obid AS property_interface_obid," +
            "t2.Interface_Def_Uid AS property_interface_def_uid," +
            "t2.Str_Value AS property_str_value," +
            "t2.Uom AS property_uom," +
            "t2.Creation_Date AS property_creation_date," +
            "t2.Termination_Date AS property_termination_date," +
            "t2.Creation_User AS property_creation_user," +
            "t2.Termination_User AS property_termination_user " +
            "FROM " +
            "OBJ t " +
            "LEFT JOIN OBJIF t1 ON t.OBID = t1.obj_obid " +
            "LEFT JOIN OBJPR t2 ON t2.interface_obid = t1.OBID " +
            "${ew.customSqlSegment}")
    List<InfoIFAndPRDetail> getOBJInfoDetails(@Param(Constants.WRAPPER) Wrapper<InfoIFAndPRDetail> wrapper);

    @Select("SELECT DISTINCT " +
            "t1.Obid AS interface_obid," +
            "t1.Obj_Obid AS interface_obj_obid," +
            "t1.Interface_Def_Uid AS interface_interface_def_uid," +
            "t1.Creation_Date AS interface_creation_date," +
            "t1.Termination_Date AS interface_termination_date," +
            "t1.Creation_User AS interface_creation_user," +
            "t1.Termination_User AS interface_termination_user," +
            "t2.Obid AS property_obid," +
            "t2.Obj_Obid AS property_obj_obid," +
            "t2.Property_Def_Uid AS property_property_def_uid," +
            "t2.Interface_Obid AS property_interface_obid," +
            "t2.Interface_Def_Uid AS property_interface_def_uid," +
            "t2.Str_Value AS property_str_value," +
            "t2.Uom AS property_uom," +
            "t2.Creation_Date AS property_creation_date," +
            "t2.Termination_Date AS property_termination_date," +
            "t2.Creation_User AS property_creation_user," +
            "t2.Termination_User AS property_termination_user " +
            "FROM " +
            "OBJREL t " +
            "LEFT JOIN OBJIF t1 ON t.OBID = t1.obj_obid " +
            "LEFT JOIN OBJPR t2 ON t2.interface_obid = t1.OBID " +
            "${ew.customSqlSegment}")
    List<InfoIFAndPRDetail> getRELInfoDetails(@Param(Constants.WRAPPER) Wrapper<InfoIFAndPRDetail> wrapper);
}
