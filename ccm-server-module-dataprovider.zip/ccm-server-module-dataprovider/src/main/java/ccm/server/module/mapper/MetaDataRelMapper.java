package ccm.server.module.mapper;

import ccm.server.entity.MetaDataRel;
import com.github.yulichang.base.MPJBaseMapper;

public interface MetaDataRelMapper extends MPJBaseMapper<MetaDataRel> {
}
