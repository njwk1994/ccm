package ccm.server.module.mapper;

import ccm.server.entity.MetaDataObj;
import com.github.yulichang.base.MPJBaseMapper;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
public interface MetaDataObjMapper extends MPJBaseMapper<MetaDataObj> {

}
