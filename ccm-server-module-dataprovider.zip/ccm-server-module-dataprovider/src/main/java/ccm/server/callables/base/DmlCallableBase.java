package ccm.server.callables.base;

import ccm.server.entity.JobWrapperEntity;
import ccm.server.entity.MetaData;
import ccm.server.processors.ProgressLatch;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

@Data
@Slf4j
public abstract class   DmlCallableBase<T extends MetaData> implements Callable<List<T>> {
    private final List<T> source = new ArrayList<>();
    private int executionOrder = 0;
    private final List<JobWrapperEntity<T>> parameters = new ArrayList<>();
    private final AtomicBoolean completedLatch = new AtomicBoolean(false);
    private final AtomicBoolean errorLatch = new AtomicBoolean(false);
    protected PlatformTransactionManager transactionManager;
    private ProgressLatch progressLatch;

    public CountDownLatch getRollBackLatch() {
        return this.progressLatch.getRollBackLatch();
    }

    public void setProgressLatch(ProgressLatch progressLatch) {
        this.progressLatch = progressLatch;
    }

    public CountDownLatch getMainThreadLatch() {
        return this.progressLatch.getMainThreadLatch();
    }

    public AtomicBoolean getRollBack() {
        return this.progressLatch.getRollBack();
    }

    public PlatformTransactionManager getTransactionManager() {
        return this.transactionManager;
    }

    public void setTransactionManager(PlatformTransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }

    protected abstract void doWork() throws Exception;

    public boolean hasError() {
        return this.errorLatch.get();
    }

    public boolean hasCompleted() {
        return this.completedLatch.get();
    }

    public List<Exception> exceptions() {
        List<Exception> result = new ArrayList<>();
        if (this.getParameters().size() > 0) {
            for (JobWrapperEntity<T> parameter : this.getParameters()) {
                List<Exception> exceptions = parameter.getExceptions();
                if (exceptions != null)
                    result.addAll(exceptions);
            }
        }
        return result;
    }

    public DmlCallableBase(PlatformTransactionManager transactionManager, JobWrapperEntity<T> jobWrapperEntity) {
        if (jobWrapperEntity != null)
            this.parameters.add(jobWrapperEntity);
        this.setTransactionManager(transactionManager);
    }

    public void add(JobWrapperEntity<T> jobWrapperEntity) {
        if (jobWrapperEntity != null)
            this.parameters.add(jobWrapperEntity);
    }

    public TransactionStatus getTransactionStatus() {
        DefaultTransactionDefinition defaultTransactionDefinition = new DefaultTransactionDefinition();
        defaultTransactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        defaultTransactionDefinition.setIsolationLevel(TransactionDefinition.ISOLATION_DEFAULT);
        return this.transactionManager.getTransaction(defaultTransactionDefinition);
    }

    @Override
    public List<T> call() {
        if (this.getRollBack().get()) {
            log.trace("required to be roll back, no need to run");
            this.getMainThreadLatch().countDown();
            return null;
        }
        TransactionStatus transactionStatus = this.getTransactionStatus();
        try {
            log.trace("star to process:" + this.getClass().getName());
            this.doWork();
            log.trace("finish to process");
            this.getMainThreadLatch().countDown();
            log.trace("normal status for internal thread:" + this.getMainThreadLatch().getCount());
            if (this.getMainThreadLatch().getCount() == 0)
                this.getRollBackLatch().countDown();
            this.getRollBackLatch().await();
            if (this.getRollBack().get()) {
                this.transactionManager.rollback(transactionStatus);
                log.error("****ERROR*********transaction rollback in multi-thread*******ERROR******");
            } else {
                this.transactionManager.commit(transactionStatus);
               // log.info("*************transaction committed in multi-thread*************");
                for (JobWrapperEntity<T> jobWrapperEntity : this.parameters) {
                    this.source.addAll(jobWrapperEntity.getItems());
                }
            }
        } catch (Exception exception) {
            this.errorLatch.set(true);
            this.getRollBack().set(true);
            this.getRollBackLatch().countDown();
            this.getMainThreadLatch().countDown();
            this.transactionManager.rollback(transactionStatus);
        } finally {
            this.completedLatch.set(true);
        }
        if (!this.errorLatch.get())
            return this.source;
        return null;
    }
}
