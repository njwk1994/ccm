package ccm.server.callables.base;

import ccm.server.consumers.ThrowableConsumer;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

@Data
@Slf4j
public class CallableBase<T> implements Callable<List<T>> {
    private List<T> source;
    private ThrowableConsumer<List<T>> consumer;

    public CallableBase(List<T> ts, ThrowableConsumer<List<T>> consumer) {
        this.consumer = consumer;
        this.source = ts;
    }

    @Override
    public List<T> call() {
        if (this.getConsumer() != null) {
            log.trace("star to do call in " + this.getClass().getName());
            if (this.source == null)
                this.source = new ArrayList<>();
            List<T> finalList = new ArrayList<>(this.getSource());
            this.getConsumer().accept(finalList);
            return finalList;
        }
        return null;
    }
}
