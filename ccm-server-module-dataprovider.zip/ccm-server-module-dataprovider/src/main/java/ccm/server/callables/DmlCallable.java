package ccm.server.callables;

import ccm.server.callables.base.DmlCallableBase;
import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.JobWrapperEntity;
import ccm.server.entity.MetaData;
import ccm.server.util.CommonUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Slf4j
public class DmlCallable<T extends MetaData> extends DmlCallableBase<T> {
    public DmlCallable(PlatformTransactionManager transactionManager, JobWrapperEntity<T> jobWrapperEntity) {
        super(transactionManager, jobWrapperEntity);
    }

    public DmlCallable(PlatformTransactionManager transactionManager) {
        super(transactionManager, null);
    }

    @Override
    protected void doWork() throws Exception {
        log.trace("enter to do work on DML callable");
        if (CommonUtility.hasValue(this.getParameters())) {
            AtomicBoolean flag = new AtomicBoolean(true);
            for (JobWrapperEntity<T> jobWrapperEntity : this.getParameters()) {
                if (flag.get()) {
                    try {
                        List<T> currentSource = jobWrapperEntity.getItems();
                        ThrowableConsumer<List<T>> consumer = jobWrapperEntity.getConsumer();
                        if (CommonUtility.hasValue(currentSource) && consumer != null) {
                            List<T> finalList = new ArrayList<>(currentSource);
                            consumer.accept(finalList);
                            jobWrapperEntity.getItems().clear();
                            jobWrapperEntity.getItems().addAll(finalList);
                        }
                    } catch (Exception exception) {
                        flag.set(false);
                        jobWrapperEntity.setException(exception);
                    }
                } else
                    break;
            }
            if (!flag.get())
                throw new Exception("error occurred during do work on DML CALLABLE");
            else
                log.trace("complete to do work on DML CALLABLE");
        }
    }
}
