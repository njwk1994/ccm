package ccm.server.interceptors;

import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.DefaultReflectorFactory;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.apache.ibatis.session.ResultHandler;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.sql.Statement;

@Slf4j
@Component
@Intercepts({
        @Signature(type = StatementHandler.class, method = "query", args = {Statement.class, ResultHandler.class})
})
public class SqlStatementInterceptor implements Interceptor {
    @Override
    public Object intercept(Invocation invocation) throws Exception {
        StatementHandler statementHandler = (StatementHandler) invocation.getTarget();
        MetaObject metaObject = MetaObject.forObject(statementHandler, SystemMetaObject.DEFAULT_OBJECT_FACTORY,
                SystemMetaObject.DEFAULT_OBJECT_WRAPPER_FACTORY, new DefaultReflectorFactory());
        MappedStatement mappedStatement = (MappedStatement) metaObject.getValue("delegate.mappedStatement");
        String sqlCommandType = mappedStatement.getSqlCommandType().toString();
        BoundSql boundSql = statementHandler.getBoundSql();
        StringBuffer sb = new StringBuffer(boundSql.getSql());
//        if (SqlCommandType.SELECT.toString().equalsIgnoreCase(sqlCommandType)) {
//            String fullSignature = mappedStatement.getId();
//            log.info("sql command type is SELECT and map statement's id :" + fullSignature);
//            String mapperWithMethod = fullSignature.contains("_") ? fullSignature.substring(0, fullSignature.lastIndexOf("_")) : fullSignature;
//            String methodName = mapperWithMethod.substring(mapperWithMethod.lastIndexOf(".") + 1);
//            String entityClass = fullSignature.contains("_") ? fullSignature.substring(fullSignature.lastIndexOf("_") + 1) : "";
//            Class<?> mapperClassType = Class.forName(mapperWithMethod.substring(0, mapperWithMethod.lastIndexOf(".")));
//            Method[] methods = mapperClassType.getMethods();
//            for (Method method : methods) {
//
//            }
//        }
        return invocation.proceed();
    }

    @Override
    public Object plugin(Object target) {

        if (target instanceof StatementHandler) {
            return Plugin.wrap(target, this);
        }
        return target;
    }
}
