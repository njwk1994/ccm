package ccm.server.configs;

import ccm.server.handlers.ConfigurationPlusDomainTableNameParser;
import ccm.server.injectors.MySqlInjector;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.DynamicTableNameInnerInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration("myBatisPlusConfig")
@MapperScan(basePackages = {"ccm.server.module.mapper"})
public class MyBatisPlusConfig {
    @Bean
    public MySqlInjector mySqlInjector() {
        return new MySqlInjector();
    }

    @Bean
    public MybatisPlusInterceptor cimMyBatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        DynamicTableNameInnerInterceptor dynamicTableNameInnerInterceptor = new DynamicTableNameInnerInterceptor();
        dynamicTableNameInnerInterceptor.setTableNameHandler(new ConfigurationPlusDomainTableNameParser("", ""));
        interceptor.addInnerInterceptor(dynamicTableNameInnerInterceptor);
        return interceptor;
    }
}
