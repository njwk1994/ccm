package ccm.server.service.impl;

import ccm.server.entity.MetaDataObj;
import ccm.server.enums.classDefinitionType;
import ccm.server.models.page.PageResult;
import ccm.server.models.scope.ScopeConfiguration;
import ccm.server.module.mapper.MetaDataObjMapper;
import ccm.server.service.IMetaDataObjService;
import ccm.server.util.CommonUtility;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service("metaDataObjServiceImpl")
@Slf4j
public class MetaDataObjServiceImpl extends MetaDataServiceImpl<MetaDataObjMapper, MetaDataObj> implements IMetaDataObjService {
    @Override
    public QueryWrapper<MetaDataObj> generateExistQueryWrapper(MetaDataObj metaDataObj) {
        if (metaDataObj != null) {
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(MetaDataObj::getObjUid, metaDataObj.getObjUid())
                    .eq(MetaDataObj::getConfig, metaDataObj.getConfig())
                    .eq(MetaDataObj::getDomainUid, metaDataObj.getDomainUid())
                    .eq(MetaDataObj::getClassDefinitionUid, metaDataObj.getClassDefinitionUid()).isNull(MetaDataObj::getTerminationDate);
            return queryWrapper;
        }
        return null;
    }

    @Override
    public QueryWrapper<MetaDataObj> generateQueryWrapper() {
        return super.generateQueryWrapper();
    }

    @Override
    public QueryWrapper<MetaDataObj> generateQueryWrapper(ScopeConfiguration scopeConfiguration) {
        QueryWrapper<MetaDataObj> queryWrapper = super.generateQueryWrapper(scopeConfiguration);
        this.setQueryConfigCondition(queryWrapper, scopeConfiguration);
        return queryWrapper;
    }

    @Override
    public QueryWrapper<MetaDataObj> generateExistQueryWrapper(List<MetaDataObj> t) {
        if (CommonUtility.hasValue(t)) {
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda()
                    .in(MetaDataObj::getObjUid, t.stream().map(MetaDataObj::getObjUid).collect(Collectors.toList()))
                    .in(MetaDataObj::getDomainUid, t.stream().map(MetaDataObj::getDomainUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataObj::getClassDefinitionUid, t.stream().map(MetaDataObj::getClassDefinitionUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataObj::getConfig, t.stream().map(MetaDataObj::getConfig).distinct().collect(Collectors.toList())).
                    isNull(MetaDataObj::getTerminationDate);
            return queryWrapper;
        }
        return null;
    }

    @Override
    public void beforeUpdate(MetaDataObj metaDataObj) {
    }

    @Override
    public PageResult<MetaDataObj> get(QueryWrapper<MetaDataObj> queryWrapper, int pageIndex, int pageSize) {
        PageResult<MetaDataObj> result = new PageResult<>();
        if (queryWrapper != null) {
            queryWrapper.lambda().isNull(MetaDataObj::getTerminationDate);
            this.setQueryConfigCondition(queryWrapper, null);
            if (pageIndex < 0 || pageSize <= 0) {
                result.setResultList(this.get(queryWrapper));
                result.setCurrent(1);
                result.setSize(CommonUtility.getSize(result.getResultList()));
                result.setTotal((long) CommonUtility.getSize(result.getResultList()));
            } else {
                Page<MetaDataObj> selectPage = this.getBaseMapper().selectPage(new Page<>(pageIndex, pageSize), queryWrapper);
                result.setCurrent(pageIndex);
                result.setSize(pageSize);
                result.setTotal(selectPage.getTotal());
                result.setResultList(selectPage.getRecords());
            }
        }
        return result;
    }

    @Deprecated
    @Override
    public PageResult<MetaDataObj> get(MPJLambdaWrapper<MetaDataObj> lambdaWrapper, int pageIndex, int pageSize) {
        PageResult<MetaDataObj> result = new PageResult<>();
        if (lambdaWrapper != null) {
            lambdaWrapper.isNull(MetaDataObj::getTerminationDate);
            this.setQueryConfigCondition(lambdaWrapper, null);
            if (pageIndex < 0 || pageSize < 0) {
                List<MetaDataObj> dataObjs = this.myMapper().selectJoinList(MetaDataObj.class, lambdaWrapper);
                result.setResultList(dataObjs);
                result.setCurrent(0);
                result.setSize(0);
                result.setTotal((long) CommonUtility.getSize(result.getResultList()));
            } else {
                IPage<MetaDataObj> selectJoinPage = this.myMapper().selectJoinPage(new Page<MetaDataObj>(pageIndex, pageSize), MetaDataObj.class, lambdaWrapper);
                result.setResultList(selectJoinPage.getRecords());
                result.setCurrent(pageIndex);
                result.setSize(pageSize);
                result.setTotal(selectJoinPage.getTotal());
            }
        }
        return result;
    }

    @Override
    public PageResult<MetaDataObj> get(MPJQueryWrapper<MetaDataObj> queryWrapper, int pageIndex, int pageSize) {
        PageResult<MetaDataObj> result = new PageResult<>();
        if (queryWrapper != null) {
            this.setQueryConfigCondition(queryWrapper, null);
            if (pageIndex < 0 || pageSize < 0) {
                List<MetaDataObj> dataObjs = this.get(MetaDataObj.class, queryWrapper);
                result.setResultList(dataObjs);
                result.setCurrent(0);
                result.setSize(0);
                result.setTotal((long) CommonUtility.getSize(result.getResultList()));
            } else {
                IPage<MetaDataObj> selectJoinPage = this.myMapper().selectJoinPage(new Page<MetaDataObj>(pageIndex, pageSize), MetaDataObj.class, queryWrapper);
                result.setResultList(selectJoinPage.getRecords());
                result.setCurrent(pageIndex);
                result.setSize(pageSize);
                result.setTotal(selectJoinPage.getTotal());
            }
        }
        return result;
    }

    @Override
    public List<MetaDataObj> getByObjUids(List<String> uids) {
        if (CommonUtility.hasValue(uids)) {
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().isNull(MetaDataObj::getTerminationDate).in(MetaDataObj::getObjUid, uids);
            return this.get(queryWrapper);
        }
        return null;
    }

    @Override
    public MetaDataObj getByUID(String objUid) {
        if (!StringUtils.isEmpty(objUid)) {
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().isNull(MetaDataObj::getTerminationDate).eq(MetaDataObj::getObjUid, objUid);
        }
        return null;
    }

    @Override
    public List<MetaDataObj> getSchemaObjects(List<String> classDefs) {
        if (!CommonUtility.hasValue(classDefs))
            classDefs = classDefinitionType.getRequiredToCachedClassDefinitionForRunner();
        if (CommonUtility.hasValue(classDefs)) {
            List<String> finalSchemeDefs = new ArrayList<>();
            for (String classDef : classDefs) {
                if (classDefinitionType.contains(classDef))
                    finalSchemeDefs.add(classDef);
            }
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().in(MetaDataObj::getClassDefinitionUid, finalSchemeDefs);
            List<MetaDataObj> result = this.get(queryWrapper);
            if (CommonUtility.hasValue(result))
                return result;
        }
        return new ArrayList<>();
    }

    @Override
    public MetaDataObj getByUIDAndDomainUID(String objUID, String domainUID) {
        if (!StringUtils.isEmpty(objUID)) {
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().eq(MetaDataObj::getObjUid, objUID);
            if (!StringUtils.isEmpty(domainUID))
                queryWrapper.lambda().eq(MetaDataObj::getDomainUid, domainUID);
            List<MetaDataObj> metaDataObjs = this.myMapper().selectList(queryWrapper);
            if (CommonUtility.hasValue(metaDataObjs))
                return metaDataObjs.get(0);
        }
        return null;
    }

    @Override
    public List<MetaDataObj> getByUIDAndDomainUID(List<String> objUIDs, String domainUID) {
        if (CommonUtility.hasValue(objUIDs)) {
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().in(MetaDataObj::getObjUid, objUIDs);
            if (!StringUtils.isEmpty(domainUID))
                queryWrapper.lambda().eq(MetaDataObj::getDomainUid, domainUID);
            return this.myMapper().selectList(queryWrapper);
        }
        return null;
    }

    @Override
    public List<MetaDataObj> getByUIDAndDomainUID(List<String> objUIDs, List<String> domainUID) {
        if (CommonUtility.hasValue(objUIDs)) {
            QueryWrapper<MetaDataObj> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().in(MetaDataObj::getObjUid, objUIDs);
            if (CommonUtility.hasValue(domainUID))
                queryWrapper.lambda().in(MetaDataObj::getDomainUid, domainUID);
            return this.myMapper().selectList(queryWrapper);
        }
        return null;
    }
}
