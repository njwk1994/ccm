package ccm.server.service.impl;

import ccm.server.models.LiteObjectPart;
import ccm.server.module.mapper.LiteObjectPartMapper;
import ccm.server.service.ILiteObjectPartService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class LiteObjectPartServiceImpl extends MPJBaseServiceImpl<LiteObjectPartMapper, LiteObjectPart> implements ILiteObjectPartService {

}
