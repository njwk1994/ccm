package ccm.server.service;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataObjInterface;
import ccm.server.entity.MetaDataRel;
import ccm.server.params.IfAndPRCarrier;

import java.util.List;

public interface IMetaDataObjInterfaceService extends IMetaDataService<MetaDataObjInterface> {
    List<MetaDataObjInterface> getByObj(MetaDataObj metaDataObj);

    List<MetaDataObjInterface> getByRel(MetaDataRel metaDataRel);

    List<MetaDataObjInterface> getByRel(List<MetaDataRel> metaDataRels);

    List<MetaDataObjInterface> getByObj(List<MetaDataObj> metaDataObjs);
}
