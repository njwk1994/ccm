package ccm.server.service.impl;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataObjProperty;
import ccm.server.entity.MetaDataRel;
import ccm.server.handlers.ConfigurationPlusDomainTableNameParser;
import ccm.server.module.mapper.MetaDataObjPropertyMapper;
import ccm.server.params.IfAndPRCarrier;
import ccm.server.service.IMetaDataObjPropertyService;
import ccm.server.util.CommonUtility;
import ccm.server.util.PerformanceUtility;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service("metaDataObjPropertyServiceImpl")
@Slf4j
public class MetaDataObjPropertyServiceImpl extends MetaDataServiceImpl<MetaDataObjPropertyMapper, MetaDataObjProperty> implements IMetaDataObjPropertyService {
    @Override
    public QueryWrapper<MetaDataObjProperty> generateExistQueryWrapper(MetaDataObjProperty metaDataObjProperty) {
        if (metaDataObjProperty != null) {
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(MetaDataObjProperty::getObjObid, metaDataObjProperty.getObjObid())
                    .eq(MetaDataObjProperty::getPropertyDefUid, metaDataObjProperty.getPropertyDefUid())
                    .eq(MetaDataObjProperty::getInterfaceObid, metaDataObjProperty.getInterfaceObid())
                    .isNull(MetaDataObjProperty::getTerminationDate);
            return queryWrapper;
        }
        return null;
    }

    @Override
    public QueryWrapper<MetaDataObjProperty> generateExistQueryWrapper(List<MetaDataObjProperty> t) {
        if (CommonUtility.hasValue(t)) {
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda()
                    .in(MetaDataObjProperty::getObjObid, t.stream().map(MetaDataObjProperty::getObjObid).distinct().collect(Collectors.toList()))
                    .in(MetaDataObjProperty::getPropertyDefUid, t.stream().map(MetaDataObjProperty::getPropertyDefUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataObjProperty::getInterfaceObid, t.stream().map(MetaDataObjProperty::getInterfaceObid).distinct().collect(Collectors.toList()))
                    .isNull(MetaDataObjProperty::getTerminationDate);
            return queryWrapper;
        }
        return null;
    }

    protected boolean same(MetaDataObjProperty p1, MetaDataObjProperty p2) {
        if (p1 != null && p2 != null) {
            if (p1.toString().equalsIgnoreCase(p2.toString())) {
                if (p1.getStrValue().equalsIgnoreCase(p2.getStrValue()) && p1.getUom().equalsIgnoreCase(p2.getUom()))
                    return true;
            }
        }
        return false;
    }

    @Override
    public boolean createOrUpdate(MetaDataObjProperty metaDataObjProperty) throws Exception {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (metaDataObjProperty != null) {
            if (metaDataObjProperty.fromDb()) {
                boolean terminated = this.terminate(metaDataObjProperty);
                if (!terminated)
                    throw new Exception("terminate property failed for:" + metaDataObjProperty.toString());
            } else {
                MetaDataObjProperty ensure = this.ensure(metaDataObjProperty);
                if (ensure != null) {
                    if (this.same(ensure, metaDataObjProperty)) {
                        log.trace("provided property is totally same with provided");
                        result = true;
                    } else {
                        boolean terminate = this.terminate(ensure);
                        if (!terminate)
                            throw new Exception("terminate property failed for:" + ensure.toString());
                    }
                }
            }
            if (!result)
                result = this.create(metaDataObjProperty);
        }
        log.trace("exit to createOrUpdate(MetadataObjProperty metaDataObjProperty:" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    private List<MetaDataObjProperty> filterForCreateAndTerminate(List<MetaDataObjProperty> t) throws ExecutionException, InterruptedException {
        List<MetaDataObjProperty> insertList = new ArrayList<>(t);
        Map<String, MetaDataObjProperty> mapInsert = this.mapByKey(insertList);
        log.trace("convert to provided properties to be HashMap:" + mapInsert.size());
        List<MetaDataObjProperty> exist = null;
        try {
            exist = this.exist(t, false);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        if (CommonUtility.hasValue(exist)) {
            Map<String, MetaDataObjProperty> mapExist = this.mapByKey(exist);
            for (Map.Entry<String, MetaDataObjProperty> propertyEntry : mapExist.entrySet()) {
                if (mapInsert.containsKey(propertyEntry.getKey())) {
                    if (this.same(propertyEntry.getValue(), mapInsert.get(propertyEntry.getKey()))) {
                        mapInsert.remove(propertyEntry.getKey());
                        exist.remove(propertyEntry.getValue());
                    }
                }
            }
            t.clear();
            log.trace("existed properties quantity:" + exist.size() + " to be terminated");
            t.addAll(exist);
        }
        log.trace("to be created properties quantity:" + mapInsert.size());
        return new ArrayList<>(mapInsert.values());
    }

    @Override
    public void beforeUpdate(MetaDataObjProperty metaDataObjProperty) {
//        if (metaDataObjProperty != null) {
//
//        }
    }

    @Override
    public List<MetaDataObjProperty> getByObjOBID(String objOBID) {
        if (!StringUtils.isEmpty(objOBID)) {
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(MetaDataObjProperty::getObjObid, objOBID).isNull(MetaDataObjProperty::getTerminationDate);
            return this.getBaseMapper().selectList(queryWrapper);
        }
        return null;
    }

    @Override
    public List<MetaDataObjProperty> getByObjOBID(List<String> objOBIDs) {
        if (CommonUtility.hasValue(objOBIDs)) {
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().in(MetaDataObjProperty::getObjObid, objOBIDs).isNull(MetaDataObjProperty::getTerminationDate);
            return this.getBaseMapper().selectList(queryWrapper);
        }
        return null;
    }

    @Override
    public boolean deleteByObjOBID(String objOBID) {
        if (!StringUtils.isEmpty(objOBID)) {
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(MetaDataObjProperty::getObjObid, objOBID);
            return this.getBaseMapper().delete(queryWrapper) != -1;
        }
        return false;
    }

    @Override
    public boolean deleteByObjOBID(List<String> objOBID) {
        if (CommonUtility.hasValue(objOBID)) {
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().in(MetaDataObjProperty::getObjObid, objOBID).isNull(MetaDataObjProperty::getTerminationDate);
            return this.getBaseMapper().delete(queryWrapper) != -1;
        }
        return false;
    }

    @Override
    public List<MetaDataObjProperty> getByObject(MetaDataObj metaDataObj) {
        if (metaDataObj != null && metaDataObj.fromDb()) {
            log.trace("enter to getByObject(MetaDataObj metaDataObj:" + metaDataObj.toString());
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjProperty::getTerminationDate);
            queryWrapper.lambda().eq(MetaDataObjProperty::getObjObid, metaDataObj.getObid());
            List<MetaDataObjProperty> result = this.get(queryWrapper);
            log.trace("progress result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public List<MetaDataObjProperty> getByRel(MetaDataRel metaDataRel) {
        if (metaDataRel != null && metaDataRel.fromDb()) {
            log.trace("enter to getByObject(MetaDataRel metaDataRel:" + metaDataRel.toString());
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjProperty::getTerminationDate);
            queryWrapper.lambda().eq(MetaDataObjProperty::getObjObid, metaDataRel.getObid());
            List<MetaDataObjProperty> result = this.get(queryWrapper);
            log.trace("progress result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public List<MetaDataObjProperty> getByObject(List<MetaDataObj> metaDataObjs) {
        if (CommonUtility.hasValue(metaDataObjs)) {
            log.trace("enter to getByObject(List<MetaDataObj> metaDataObjs:" + CommonUtility.getSize(metaDataObjs));
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjProperty::getTerminationDate);
            queryWrapper.lambda().in(MetaDataObjProperty::getObjObid, metaDataObjs.stream().map(MetaDataObj::getObid).distinct().collect(Collectors.toList()));
            List<MetaDataObjProperty> result = this.get(queryWrapper);
            log.trace("progress result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public List<MetaDataObjProperty> getByRel(List<MetaDataRel> metaDataRels) {
        if (CommonUtility.hasValue(metaDataRels)) {
            log.trace("enter to getByObject(List<MetaDataRel> metaDataRels:" + CommonUtility.getSize(metaDataRels));
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjProperty::getTerminationDate);
            queryWrapper.lambda().in(MetaDataObjProperty::getObjObid, metaDataRels.stream().map(MetaDataRel::getObid).distinct().collect(Collectors.toList()));
            List<MetaDataObjProperty> result = this.get(queryWrapper);
            log.trace("progress result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public MetaDataObjProperty getProperty(String objOBID, String propertyDefUID) {
        if (!StringUtils.isEmpty(objOBID) && !StringUtils.isEmpty(propertyDefUID)) {
            QueryWrapper<MetaDataObjProperty> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(MetaDataObjProperty::getObjObid, objOBID).eq(MetaDataObjProperty::getPropertyDefUid, propertyDefUID)
                    .isNull(MetaDataObjProperty::getTerminationDate);
            return this.myMapper().selectOne(queryWrapper);
        }
        return null;
    }

    @Override
    public boolean threadCreateOrUpdate(List<MetaDataObjProperty> t) throws Exception {
        log.trace("enter to threadCreateOrUpdate(List<MetaDataObjProperty> t):" + CommonUtility.getSize(t));
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            List<MetaDataObjProperty> toBeCreated = this.filterForCreateAndTerminate(t);
            result = this.terminate(t);
            if (!result) {
                throw new Exception("terminated properties failed");
            }
            result = this.create(toBeCreated);
            if (!result) {
                throw new Exception("create properties failed");
            }
        }
        log.trace("exit to threadCreateOrUpdate(List<MetaDataObjProperty> t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }
}
