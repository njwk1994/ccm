package ccm.server.service.impl;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataRel;
import ccm.server.enums.relDirection;
import ccm.server.module.mapper.MetaDataRelMapper;
import ccm.server.models.page.PageResult;
import ccm.server.params.ObjRelationshipCarrier;
import ccm.server.params.RelRelationshipCarrier;
import ccm.server.service.IMetaDataRelService;
import ccm.server.util.CommonUtility;
import ccm.server.util.PerformanceUtility;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Slf4j
@Service("metaDataRelServiceImpl")
public class MetaDataRelServiceImpl extends MetaDataServiceImpl<MetaDataRelMapper, MetaDataRel> implements IMetaDataRelService {
    @Override
    public QueryWrapper<MetaDataRel> generateExistQueryWrapper(MetaDataRel metaDataRel) {
        if (metaDataRel != null) {
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate)
                    .eq(MetaDataRel::getObjUid, metaDataRel.getObjUid());
            return queryWrapper;
        }
        return null;
    }

    @Override
    public QueryWrapper<MetaDataRel> generateExistQueryWrapper(List<MetaDataRel> t) {
        if (CommonUtility.hasValue(t)) {
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate)
                    .in(MetaDataRel::getObjUid, t.stream().map(MetaDataRel::getObjUid).distinct().collect(Collectors.toList()));
            return queryWrapper;
        }
        return null;
    }

    @Override
    public boolean createOrUpdate(MetaDataRel metaDataRel) throws Exception {
        boolean result = false;
        if (metaDataRel != null) {
            MetaDataRel ensure = this.ensure(metaDataRel);
            if (ensure != null) {
                if (ensure.getObjUid().equalsIgnoreCase(metaDataRel.getObjUid()))
                    result = true;
                else {
                    if (!this.terminate(ensure))
                        throw new Exception("terminate relationship failed");
                    result = this.create(metaDataRel);
                }
            } else
                result = this.create(metaDataRel);
        }
        return result;
    }

    private List<MetaDataRel> filterForCreateAndTerminate(List<MetaDataRel> t) throws ExecutionException, InterruptedException {
        List<MetaDataRel> insertList = new ArrayList<>(t);
        Map<String, MetaDataRel> mapInsert = this.mapByKey(insertList);
        log.trace("convert to provided relationships to be HashMap:" + mapInsert.size());
        List<MetaDataRel> exist = null;
        try {
            exist = this.exist(t, false);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        if (CommonUtility.hasValue(exist)) {
            Map<String, MetaDataRel> mapExist = this.mapByKey(exist);
            for (Map.Entry<String, MetaDataRel> propertyEntry : mapExist.entrySet()) {
                if (mapInsert.containsKey(propertyEntry.getKey())) {
                    if (this.same(propertyEntry.getValue(), mapInsert.get(propertyEntry.getKey()))) {
                        mapInsert.remove(propertyEntry.getKey());
                        exist.remove(propertyEntry.getValue());
                    }
                }
            }
            t.clear();
            log.trace("existed relationships quantity:" + exist.size() + " to be terminated");
            t.addAll(exist);
        }
        log.trace("to be created relationships quantity:" + mapInsert.size());
        return new ArrayList<>(mapInsert.values());
    }

    protected boolean same(MetaDataRel p1, MetaDataRel p2) {
        if (p1 != null && p2 != null) {
            if (p1.toString().equalsIgnoreCase(p2.toString()))
                return true;
        }
        return false;
    }

    @Override
    public void beforeUpdate(MetaDataRel metaDataRel) {
        if (metaDataRel != null) {

        }
    }

    @Override
    public boolean threadCreateOrUpdate(List<MetaDataRel> t) throws Exception {
        log.trace("enter to threadCreateOrUpdate(List<T> t):" + CommonUtility.getSize(t));
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            List<MetaDataRel> toBeCreated = this.filterForCreateAndTerminate(t);
            result = this.terminate(t);
            if (!result) {
                throw new Exception("terminated relationships failed");
            }
            result = this.create(toBeCreated);
            if (!result) {
                throw new Exception("create relationships failed");
            }
        }
        log.trace("exit to threadCreateOrUpdate(List<T> t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public PageResult<MetaDataRel> get(QueryWrapper<MetaDataRel> queryWrapper, int pageIndex, int pageSize) {
        PageResult<MetaDataRel> result = new PageResult<>();
        if (queryWrapper != null) {
            queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate);
            this.setQueryConfigCondition(queryWrapper, null);
            if (pageIndex < 0 || pageSize <= 0) {
                result.setResultList(this.get(queryWrapper));
                result.setCurrent(0);
                result.setSize(0);
                result.setTotal((long) CommonUtility.getSize(result.getResultList()));
            } else {
                Page<MetaDataRel> selectPage = this.getBaseMapper().selectPage(new Page<>(pageIndex, pageSize), queryWrapper);
                result.setCurrent(pageIndex);
                result.setSize(pageSize);
                result.setTotal(selectPage.getTotal());
                result.setResultList(selectPage.getRecords());
            }
        }
        return result;
    }

    @Override
    @Deprecated
    public PageResult<MetaDataRel> get(MPJLambdaWrapper<MetaDataRel> wrapper, int pageIndex, int pageSize) {
        PageResult<MetaDataRel> result = new PageResult<>();
        if (wrapper != null) {
            wrapper.isNull(MetaDataRel::getTerminationDate);
            this.setQueryConfigCondition(wrapper, null);
            if (pageIndex < 0 || pageSize < 0) {
                List<MetaDataRel> dataObjs = this.myMapper().selectJoinList(MetaDataRel.class, wrapper);
                result.setResultList(dataObjs);
                result.setCurrent(0);
                result.setSize(0);
                result.setTotal((long) CommonUtility.getSize(result.getResultList()));
            } else {
                IPage<MetaDataRel> selectJoinPage = this.myMapper().selectJoinPage(new Page<MetaDataRel>(pageIndex, pageSize), MetaDataRel.class, wrapper);
                result.setResultList(selectJoinPage.getRecords());
                result.setCurrent(pageIndex);
                result.setSize(pageSize);
                result.setTotal(selectJoinPage.getTotal());
            }
        }
        return result;
    }

    @Override
    public PageResult<MetaDataRel> get(MPJQueryWrapper<MetaDataRel> wrapper, int pageIndex, int pageSize) {
        PageResult<MetaDataRel> result = new PageResult<>();
        if (wrapper != null) {
            this.setQueryConfigCondition(wrapper, null);
            if (pageIndex < 0 || pageSize < 0) {
                List<MetaDataRel> dataObjs = this.myMapper().selectJoinList(MetaDataRel.class, wrapper);
                result.setResultList(dataObjs);
                result.setCurrent(0);
                result.setSize(0);
                result.setTotal((long) CommonUtility.getSize(result.getResultList()));
            } else {
                IPage<MetaDataRel> selectJoinPage = this.myMapper().selectJoinPage(new Page<MetaDataRel>(pageIndex, pageSize), MetaDataRel.class, wrapper);
                result.setResultList(selectJoinPage.getRecords());
                result.setCurrent(pageIndex);
                result.setSize(pageSize);
                result.setTotal(selectJoinPage.getTotal());
            }
        }
        return result;
    }

    @Override
    public List<MetaDataRel> getEnd1Relationships(String uid1, String relDefUid) {
        List<MetaDataRel> result = new ArrayList<>();
        if (!StringUtils.isEmpty(uid1)) {
            if (StringUtils.isEmpty(relDefUid))
                return this.getEnd1Relationships(uid1);
            else {
                log.trace("enter to getEnd1Relationships(String uid1, String relDefUid):" + uid1 + "," + relDefUid);
                StopWatch stopWatch = PerformanceUtility.start();
                QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
                queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid1, uid1).eq(MetaDataRel::getRelDefUid, relDefUid);
                result = this.get(queryWrapper);
                log.trace("expand relationship by uid1 and relDefUid:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            }
        }
        return result;
    }

    @Override
    public List<MetaDataRel> getEnd1Relationships(String uid1) {
        log.trace("enter to  getEnd1Relationships(String uid1):" + uid1);
        List<MetaDataRel> result = new ArrayList<>();
        if (!StringUtils.isEmpty(uid1)) {
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid1, uid1);
            result = this.get(queryWrapper);
            log.trace("expand relationship by uid1:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
        }
        return result;
    }

    @Override
    public List<MetaDataRel> getEnd1Relationships(String uid1, List<String> relDefUids) {
        List<MetaDataRel> result = new ArrayList<>();
        if (!StringUtils.isEmpty(uid1)) {
            if (CommonUtility.hasValue(relDefUids)) {
                log.trace("enter to getEnd1Relationships(String uid1,List<String> relDefUids:" + uid1 + "," + CommonUtility.getSize(relDefUids));
                StopWatch stopWatch = PerformanceUtility.start();
                QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
                queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid1, uid1).in(MetaDataRel::getRelDefUid, relDefUids);
                result = this.get(queryWrapper);
                log.trace("expand relationship(s) by uid1 and relDefs:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            } else
                return this.getEnd1Relationships(uid1);
        }
        return result;
    }

    @Override
    public List<MetaDataRel> getEnd2Relationships(String uid2, String relDefUid) {
        List<MetaDataRel> result = new ArrayList<>();
        if (!StringUtils.isEmpty(uid2)) {
            if (StringUtils.isEmpty(relDefUid))
                return this.getEnd2Relationships(uid2);
            else {
                log.trace("enter to getEnd2Relationships(String uid2, String relDefUid):" + uid2 + "," + relDefUid);
                StopWatch stopWatch = PerformanceUtility.start();
                QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
                queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid2, uid2).eq(MetaDataRel::getRelDefUid, relDefUid);
                result = this.get(queryWrapper);
                log.trace("expand relationship by uid2 and relDefUid:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            }
        }
        return result;
    }

    @Override
    public List<MetaDataRel> getEnd2Relationships(String uid2) {
        log.trace("enter to  getEnd2Relationships(String uid1):" + uid2);
        List<MetaDataRel> result = new ArrayList<>();
        if (!StringUtils.isEmpty(uid2)) {
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid2, uid2);
            result = this.get(queryWrapper);
            log.trace("expand relationship by uid2:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
        }
        return result;
    }

    @Override
    public List<MetaDataRel> getEnd2Relationships(String uid2, List<String> relDefUids) {
        List<MetaDataRel> result = new ArrayList<>();
        if (!StringUtils.isEmpty(uid2)) {
            if (CommonUtility.hasValue(relDefUids)) {
                log.trace("enter to getEnd2Relationships(String uid2,List<String> relDefUids:" + uid2 + "," + CommonUtility.getSize(relDefUids));
                StopWatch stopWatch = PerformanceUtility.start();
                QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
                queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid2, uid2).in(MetaDataRel::getRelDefUid, relDefUids);
                result = this.get(queryWrapper);
                log.trace("expand relationship(s) by uid2 and relDefs:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            } else
                return this.getEnd2Relationships(uid2);
        }
        return result;
    }

    @Override
    public Map<MetaDataObj, List<MetaDataRel>> getEnd1Relationships(List<MetaDataObj> objs, List<String> relDefUids) {
        log.trace("enter to getEnd1Relationships(List<MetaDataObj> objs, List<String> relDefUids):" + CommonUtility.getSize(objs) + "," + String.join(",", relDefUids));
        if (CommonUtility.hasValue(objs) && CommonUtility.hasValue(relDefUids)) {
            StopWatch stopWatch = PerformanceUtility.start();
            Map<MetaDataObj, List<MetaDataRel>> result = new HashMap<>();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda()
                    .in(MetaDataRel::getUid1, objs.stream().map(MetaDataObj::getObjUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataRel::getDomainUid1, objs.stream().map(MetaDataObj::getDomainUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataRel::getRelDefUid, relDefUids).isNull(MetaDataRel::getTerminationDate);
            List<MetaDataRel> rels = this.get(queryWrapper);
            if (CommonUtility.hasValue(rels)) {
                Map<String, List<MetaDataRel>> listMap = rels.stream().collect(Collectors.groupingBy(MetaDataRel::getUid1));
                for (Map.Entry<String, List<MetaDataRel>> entry : listMap.entrySet()) {
                    MetaDataObj dataObj = objs.stream().filter(c -> c.getObjUid().equalsIgnoreCase(entry.getKey())).findFirst().orElse(null);
                    if (dataObj == null)
                        log.trace("object with uid:" + entry.getKey() + " was not found in system");
                    else {
                        result.put(dataObj, entry.getValue());
                        objs.remove(dataObj);
                    }
                }
            }
            log.trace("end1 relationship(s):" + result.size() + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public Map<MetaDataRel, List<MetaDataRel>> getEnd1RelationshipsForRel(List<MetaDataRel> rels, List<String> relDefUids) {
        log.trace("enter to getEnd1Relationships(List<MetaDataRel> rels, List<String> relDefUids):" + CommonUtility.getSize(rels) + "," + String.join(",", relDefUids));
        if (CommonUtility.hasValue(rels) && CommonUtility.hasValue(relDefUids)) {
            StopWatch stopWatch = PerformanceUtility.start();
            Map<MetaDataRel, List<MetaDataRel>> result = new HashMap<>();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda()
                    .in(MetaDataRel::getUid1, rels.stream().map(MetaDataRel::getObjUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataRel::getRelDefUid, relDefUids).isNull(MetaDataRel::getTerminationDate);
            List<MetaDataRel> resultRels = this.get(queryWrapper);
            if (CommonUtility.hasValue(resultRels)) {
                Map<String, List<MetaDataRel>> listMap = resultRels.stream().collect(Collectors.groupingBy(MetaDataRel::getUid1));
                for (Map.Entry<String, List<MetaDataRel>> entry : listMap.entrySet()) {
                    MetaDataRel relObj = rels.stream().filter(c -> c.getObjUid().equalsIgnoreCase(entry.getKey())).findFirst().orElse(null);
                    if (relObj == null)
                        log.trace("relationship with uid:" + entry.getKey() + " was not found in system");
                    else {
                        result.put(relObj, entry.getValue());
                        rels.remove(relObj);
                    }
                }
            }
            log.trace("end1 relationship(s):" + result.size() + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public Map<MetaDataObj, List<MetaDataRel>> getEnd2Relationships(List<MetaDataObj> objs, List<String> relDefUids) {
        log.trace("enter to getEnd2Relationships(List<MetaDataObj> objs, List<String> relDefUids):" + CommonUtility.getSize(objs) + "," + String.join(",", relDefUids));
        if (CommonUtility.hasValue(objs) && CommonUtility.hasValue(relDefUids)) {
            StopWatch stopWatch = PerformanceUtility.start();
            Map<MetaDataObj, List<MetaDataRel>> result = new HashMap<>();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda()
                    .in(MetaDataRel::getUid2, objs.stream().map(MetaDataObj::getObjUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataRel::getDomainUid2, objs.stream().map(MetaDataObj::getDomainUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataRel::getRelDefUid, relDefUids).isNull(MetaDataRel::getTerminationDate);
            List<MetaDataRel> rels = this.get(queryWrapper);
            if (CommonUtility.hasValue(rels)) {
                Map<String, List<MetaDataRel>> listMap = rels.stream().collect(Collectors.groupingBy(MetaDataRel::getUid2));
                for (Map.Entry<String, List<MetaDataRel>> entry : listMap.entrySet()) {
                    MetaDataObj dataObj = objs.stream().filter(c -> c.getObjUid().equalsIgnoreCase(entry.getKey())).findFirst().orElse(null);
                    if (dataObj == null)
                        log.warn("object with uid:" + entry.getKey() + " was not found in system");
                    else {
                        result.put(dataObj, entry.getValue());
                        objs.remove(dataObj);
                    }
                }
            }
            log.trace("end2 relationships:" + result.size() + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public Map<MetaDataRel, List<MetaDataRel>> getEnd2RelationshipsForRel(List<MetaDataRel> rels, List<String> relDefUids) {
        log.trace("enter to getEnd1Relationships(List<MetaDataRel> rels, List<String> relDefUids):" + CommonUtility.getSize(rels) + "," + String.join(",", relDefUids));
        if (CommonUtility.hasValue(rels) && CommonUtility.hasValue(relDefUids)) {
            StopWatch stopWatch = PerformanceUtility.start();
            Map<MetaDataRel, List<MetaDataRel>> result = new HashMap<>();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda()
                    .in(MetaDataRel::getUid2, rels.stream().map(MetaDataRel::getObjUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataRel::getRelDefUid, relDefUids).isNull(MetaDataRel::getTerminationDate);
            List<MetaDataRel> resultRels = this.get(queryWrapper);
            if (CommonUtility.hasValue(resultRels)) {
                Map<String, List<MetaDataRel>> listMap = resultRels.stream().collect(Collectors.groupingBy(MetaDataRel::getUid2));
                for (Map.Entry<String, List<MetaDataRel>> entry : listMap.entrySet()) {
                    MetaDataRel relObj = rels.stream().filter(c -> c.getObjUid().equalsIgnoreCase(entry.getKey())).findFirst().orElse(null);
                    if (relObj == null)
                        log.trace("relationship with uid:" + entry.getKey() + " was not found in system");
                    else {
                        result.put(relObj, entry.getValue());
                        rels.remove(relObj);
                    }
                }
            }
            log.trace("end1 relationship(s):" + result.size() + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public List<MetaDataRel> getRelationshipsByRelDef(String relDef) {
        if (!StringUtils.isEmpty(relDef)) {
            log.trace("enter to getRelationshipsByRelDef(String relDef):" + relDef);
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getRelDefUid, relDef);
            List<MetaDataRel> result = this.get(queryWrapper);
            log.trace("expand result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public List<MetaDataRel> getRelationshipsByRelDef(List<String> relDefs) {
        if (CommonUtility.hasValue(relDefs)) {
            log.trace("enter to getRelationshipsByRelDef(List<String> relDefs):" + relDefs.size());
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataRel::getTerminationDate).in(MetaDataRel::getRelDefUid, relDefs);
            List<MetaDataRel> result = this.get(queryWrapper);
            log.trace("expand result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public boolean terminateEnd1Relationships(String uid1) {
        if (!StringUtils.isEmpty(uid1)) {
            log.trace("enter to terminateEnd1Relationships(String uid1):" + uid1);
            StopWatch stopWatch = PerformanceUtility.start();
            UpdateWrapper<MetaDataRel> updateWrapper = new UpdateWrapper<>();
            updateWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid1, uid1);
            updateWrapper.lambda().set(MetaDataRel::getTerminationDate, new Date());
            boolean result = this.update(updateWrapper);
            log.trace("result progress: " + result + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public boolean terminateEnd1Relationships(String uid1, String relDefUid) {
        if (!StringUtils.isEmpty(uid1)) {
            if (StringUtils.isEmpty(relDefUid))
                return this.terminateEnd1Relationships(uid1);
            log.trace("enter to terminateEnd1Relationships(String uid1,String relDefUid):" + uid1 + "," + relDefUid);
            StopWatch stopWatch = PerformanceUtility.start();
            UpdateWrapper<MetaDataRel> updateWrapper = new UpdateWrapper<>();
            updateWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid1, uid1).eq(MetaDataRel::getRelDefUid, relDefUid);
            updateWrapper.lambda().set(MetaDataRel::getTerminationDate, new Date());
            boolean result = this.update(updateWrapper);
            log.trace("result progress: " + result + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public boolean terminateEnd1Relationships(String uid1, List<String> relDefUids) {
        if (!StringUtils.isEmpty(uid1)) {
            if (!CommonUtility.hasValue(relDefUids))
                return this.terminateEnd1Relationships(uid1);
            log.trace("enter to terminateEnd1Relationships(String uid1,List<String> relDefUids):" + uid1 + "," + CommonUtility.getSize(relDefUids));
            StopWatch stopWatch = PerformanceUtility.start();
            UpdateWrapper<MetaDataRel> updateWrapper = new UpdateWrapper<>();
            updateWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid1, uid1).in(MetaDataRel::getRelDefUid, relDefUids);
            updateWrapper.lambda().set(MetaDataRel::getTerminationDate, new Date());
            boolean result = this.update(updateWrapper);
            log.trace("result progress: " + result + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public boolean terminateEnd2Relationships(String uid2) {
        if (!StringUtils.isEmpty(uid2)) {
            log.trace("enter to terminateEnd2Relationships(String uid2):" + uid2);
            StopWatch stopWatch = PerformanceUtility.start();
            UpdateWrapper<MetaDataRel> updateWrapper = new UpdateWrapper<>();
            updateWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid2, uid2);
            updateWrapper.lambda().set(MetaDataRel::getTerminationDate, new Date());
            boolean result = this.update(updateWrapper);
            log.trace("result progress: " + result + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public boolean terminateEnd2Relationships(String uid2, String relDefUid) {
        if (!StringUtils.isEmpty(uid2)) {
            if (StringUtils.isEmpty(relDefUid))
                return this.terminateEnd2Relationships(uid2);
            log.trace("enter to terminateEnd2Relationships(String uid2,String relDefUid):" + uid2 + "," + relDefUid);
            StopWatch stopWatch = PerformanceUtility.start();
            UpdateWrapper<MetaDataRel> updateWrapper = new UpdateWrapper<>();
            updateWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid2, uid2).eq(MetaDataRel::getRelDefUid, relDefUid);
            updateWrapper.lambda().set(MetaDataRel::getTerminationDate, new Date());
            boolean result = this.update(updateWrapper);
            log.trace("result progress: " + result + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public boolean terminateEnd2Relationships(String uid2, List<String> relDefUids) {
        if (!StringUtils.isEmpty(uid2)) {
            if (!CommonUtility.hasValue(relDefUids))
                return this.terminateEnd2Relationships(uid2);
            log.trace("enter to terminateEnd1Relationships(String uid2,List<String> relDefUids):" + uid2 + "," + CommonUtility.getSize(relDefUids));
            StopWatch stopWatch = PerformanceUtility.start();
            UpdateWrapper<MetaDataRel> updateWrapper = new UpdateWrapper<>();
            updateWrapper.lambda().isNull(MetaDataRel::getTerminationDate).eq(MetaDataRel::getUid2, uid2).in(MetaDataRel::getRelDefUid, relDefUids);
            updateWrapper.lambda().set(MetaDataRel::getTerminationDate, new Date());
            boolean result = this.update(updateWrapper);
            log.trace("result progress: " + result + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public ThrowableConsumer<ObjRelationshipCarrier> fillingObj() {
        return new ThrowableConsumer<ObjRelationshipCarrier>() {
            @Override
            public void accept0(ObjRelationshipCarrier ts) throws Exception {
                log.trace("enter to consumer's accept0:" + ts.toString());
                if (CommonUtility.hasValue(ts.getList())) {
                    StopWatch stopWatch = PerformanceUtility.start();
                    List<MetaDataObj> metaDataObjs = new ArrayList<>(ts.getList().keySet());
                    Map<relDirection, List<String>> relDefs = ts.groupByRelDirection();
                    for (Map.Entry<relDirection, List<String>> entry : relDefs.entrySet()) {
                        switch (entry.getKey()) {
                            case _1To2:
                                Map<MetaDataObj, List<MetaDataRel>> end1Relationships = getEnd1Relationships(metaDataObjs, entry.getValue());
                                if (end1Relationships != null)
                                    ts.getEnd1Relationships().putAll(end1Relationships);
                                break;
                            case _2To1:
                                Map<MetaDataObj, List<MetaDataRel>> end2Relationships = getEnd2Relationships(metaDataObjs, entry.getValue());
                                if (end2Relationships != null)
                                    ts.getEnd2Relationships().putAll(end2Relationships);
                                break;
                        }
                    }
                    ts.getList().clear();
                    log.trace("finish to filling relationship progress" + PerformanceUtility.stop(stopWatch));
                }
            }
        };
    }

    @Override
    public ThrowableConsumer<RelRelationshipCarrier> fillingRel() {
        return new ThrowableConsumer<RelRelationshipCarrier>() {
            @Override
            public void accept0(RelRelationshipCarrier ts) throws Exception {
                log.trace("enter to consumer's accept0:" + ts.toString());
                if (CommonUtility.hasValue(ts.getList())) {
                    StopWatch stopWatch = PerformanceUtility.start();
                    List<MetaDataRel> metaDataRels = new ArrayList<>(ts.getList().keySet());
                    Map<relDirection, List<String>> relDefs = ts.groupByRelDirection();
                    for (Map.Entry<relDirection, List<String>> entry : relDefs.entrySet()) {
                        switch (entry.getKey()) {
                            case _1To2:
                                Map<MetaDataRel, List<MetaDataRel>> end1Relationships = getEnd1RelationshipsForRel(metaDataRels, entry.getValue());
                                if (end1Relationships != null)
                                    ts.getEnd1Relationships().putAll(end1Relationships);
                                break;
                            case _2To1:
                                Map<MetaDataRel, List<MetaDataRel>> end2Relationships = getEnd2RelationshipsForRel(metaDataRels, entry.getValue());
                                if (end2Relationships != null)
                                    ts.getEnd2Relationships().putAll(end2Relationships);
                                break;
                        }
                    }
                    ts.getList().clear();
                    log.trace("finish to filling relationship progress" + PerformanceUtility.stop(stopWatch));
                }
            }
        };
    }

    @Override
    public MetaDataRel getByUIDAndDomainUID(String uid, String domainUID) {
        log.trace("enter to getByUIDAndDomainUID(String uid, String domainUID):" + uid + "," + domainUID);
        if (!StringUtils.isEmpty(uid)) {
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().eq(MetaDataRel::getObjUid, uid);
            if (!StringUtils.isEmpty(domainUID))
                queryWrapper.lambda().eq(MetaDataRel::getDomainUid, domainUID);
            MetaDataRel dataRel = this.myMapper().selectOne(queryWrapper);
            log.trace("finish to get relationship" + PerformanceUtility.stop(stopWatch));
            return dataRel;
        }
        return null;
    }

    @Override
    public List<MetaDataRel> getByUIDAndDomainUID(List<String> uid, String domainUID) {
        log.trace("enter to getByUIDAndDomainUID(List<String> uid, String domainUID):" + uid + "," + domainUID);
        if (CommonUtility.hasValue(uid)) {
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().in(MetaDataRel::getObjUid, uid);
            if (!StringUtils.isEmpty(domainUID))
                queryWrapper.lambda().eq(MetaDataRel::getDomainUid, domainUID);
            List<MetaDataRel> metaDataRels = this.myMapper().selectList(queryWrapper);
            log.trace("finish to get relationship" + PerformanceUtility.stop(stopWatch));
            return metaDataRels;
        }
        return null;
    }

    @Override
    public List<MetaDataRel> getByUIDAndDomainUID(List<String> uid, List<String> domainUID) {
        log.trace("enter to getByUIDAndDomainUID(List<String> uid, List<String> domainUID):" + uid + "," + domainUID);
        if (CommonUtility.hasValue(uid)) {
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataRel> queryWrapper = this.generateQueryWrapper();
            this.setQueryConfigCondition(queryWrapper, null);
            queryWrapper.lambda().in(MetaDataRel::getObjUid, uid);
            if (CommonUtility.hasValue(domainUID)) {
                queryWrapper.lambda().in(MetaDataRel::getDomainUid, domainUID);
            }
            List<MetaDataRel> metaDataRels = this.myMapper().selectList(queryWrapper);
            log.trace("finish to get relationship" + PerformanceUtility.stop(stopWatch));
            return metaDataRels;
        }
        return null;
    }
}
