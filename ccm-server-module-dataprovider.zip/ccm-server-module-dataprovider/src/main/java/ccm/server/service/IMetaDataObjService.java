package ccm.server.service;

import ccm.server.entity.MetaDataObj;
import ccm.server.models.page.PageResult;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;

import java.util.List;

public interface IMetaDataObjService extends IMetaDataService<MetaDataObj> {

    PageResult<MetaDataObj> get(QueryWrapper<MetaDataObj> queryWrapper, int pageIndex, int pageSize);

    PageResult<MetaDataObj> get(MPJLambdaWrapper<MetaDataObj> wrapper, int pageIndex, int pageSize);

    PageResult<MetaDataObj> get(MPJQueryWrapper<MetaDataObj> wrapper, int pageIndex, int pageSize);

    List<MetaDataObj> getByObjUids(List<String> uids);

    MetaDataObj getByUID(String objUid);

    List<MetaDataObj> getSchemaObjects(List<String> classDefs);

    MetaDataObj getByUIDAndDomainUID(String objUID, String domainUID);

    List<MetaDataObj> getByUIDAndDomainUID(List<String> objUIDs, String domainUID);

    List<MetaDataObj> getByUIDAndDomainUID(List<String> objUIDs, List<String> domainUID);


}
