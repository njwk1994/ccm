package ccm.server.service.impl;

import ccm.server.entity.MetaDataObjPropertyDetails;
import ccm.server.module.mapper.MetaDataObjPropertyDetailsMapper;
import ccm.server.service.IMetaDataObjPropertyDetailsService;
import ccm.server.util.CommonUtility;
import ccm.server.util.PerformanceUtility;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service("metaDataObjPropertyDetailsServiceImpl")
@Slf4j
public class MetaDataObjPropertyDetailsServiceImpl extends MetaDataServiceImpl<MetaDataObjPropertyDetailsMapper, MetaDataObjPropertyDetails> implements IMetaDataObjPropertyDetailsService {

    @Override
    public QueryWrapper<MetaDataObjPropertyDetails> generateExistQueryWrapper(MetaDataObjPropertyDetails metaDataObjPropertyDetails) {
        if (metaDataObjPropertyDetails != null) {
            QueryWrapper<MetaDataObjPropertyDetails> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(MetaDataObjPropertyDetails::getPropertyObid, metaDataObjPropertyDetails.getPropertyObid()).isNull(MetaDataObjPropertyDetails::getTerminationDate);
            return queryWrapper;
        }
        return null;
    }

    @Override
    public QueryWrapper<MetaDataObjPropertyDetails> generateExistQueryWrapper(List<MetaDataObjPropertyDetails> t) {
        if (CommonUtility.hasValue(t)) {
            QueryWrapper<MetaDataObjPropertyDetails> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().in(MetaDataObjPropertyDetails::getPropertyObid, t.stream().map(MetaDataObjPropertyDetails::getPropertyObid).collect(Collectors.toList()))
                .in(MetaDataObjPropertyDetails::getTerminationDate);
            return queryWrapper;
        }
        return null;
    }

    @Override
    public void beforeUpdate(MetaDataObjPropertyDetails metaDataObjPropertyDetails) {

    }

    protected boolean same(MetaDataObjPropertyDetails p1, MetaDataObjPropertyDetails p2) {
        if (p1 != null && p2 != null) {
            if (p1.toString().equalsIgnoreCase(p2.toString())) {
                if (p1.getDetails().equalsIgnoreCase(p2.getDetails()))
                    return true;
            }
        }
        return false;
    }

    private List<MetaDataObjPropertyDetails> filterForCreateAndUpdate(List<MetaDataObjPropertyDetails> t) throws ExecutionException, InterruptedException {
        List<MetaDataObjPropertyDetails> insertList = new ArrayList<>(t);
        Map<String, MetaDataObjPropertyDetails> mapInsert = this.mapByKey(insertList);
        log.info("convert to provided MetaDataObjPropertyDetails to be HashMap:" + mapInsert.size());
        List<MetaDataObjPropertyDetails> exist = null;
        try {
            exist = this.exist(t, false);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        if (CommonUtility.hasValue(exist)) {
            Map<String, MetaDataObjPropertyDetails> mapExist = this.mapByKey(exist);
            for (Map.Entry<String, MetaDataObjPropertyDetails> propertyEntry : mapExist.entrySet()) {
                if (mapInsert.containsKey(propertyEntry.getKey())) {
                    if (this.same(propertyEntry.getValue(), mapInsert.get(propertyEntry.getKey()))) {
                        mapInsert.remove(propertyEntry.getKey());
                        exist.remove(propertyEntry.getValue());
                    }
                }
            }
            t.clear();
            log.info("existed MetaDataObjPropertyDetails quantity:" + exist.size() + " to be terminated");
            t.addAll(exist);
        }
        log.info("to be created MetaDataObjPropertyDetails quantity:" + mapInsert.size());
        return new ArrayList<>(mapInsert.values());
    }

    @Override
    public boolean threadCreateOrUpdate(List<MetaDataObjPropertyDetails> t) throws Exception {
        log.info("enter to threadCreateOrUpdate(List<T> t):" + CommonUtility.getSize(t));
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            List<MetaDataObjPropertyDetails> toBeCreated = this.filterForCreateAndUpdate(t);
            result = this.terminate(t);
            if (!result) {
                throw new Exception("terminated MetaDataObjPropertyDetails failed");
            }
            result = this.create(toBeCreated);
            if (!result) {
                throw new Exception("create MetaDataObjPropertyDetails failed");
            }
        }
        log.info("exit to threadCreateOrUpdate(List<T> t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public MetaDataObjPropertyDetails getPropertyDetails(String propertyObid) {
        if (!StringUtils.isEmpty(propertyObid)) {
            QueryWrapper<MetaDataObjPropertyDetails> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(MetaDataObjPropertyDetails::getPropertyObid, propertyObid).isNull(MetaDataObjPropertyDetails::getTerminationDate);
            return this.getBaseMapper().selectOne(queryWrapper);
        }
        return null;
    }
}
