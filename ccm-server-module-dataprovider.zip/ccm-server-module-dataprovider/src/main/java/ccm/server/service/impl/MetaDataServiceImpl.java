package ccm.server.service.impl;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaData;
import ccm.server.enums.domainInfo;
import ccm.server.enums.propertyDefinitionType;
import ccm.server.handlers.ConfigurationPlusDomainTableNameParser;
import ccm.server.models.LiteObject;
import ccm.server.models.ResultSet;
import ccm.server.models.scope.ScopeConfiguration;
import ccm.server.processors.ThreadsProcessor;
import ccm.server.service.IMetaDataService;
import ccm.server.shared.ISharedLocalService;
import ccm.server.util.CollectionUtility;
import ccm.server.util.CommonUtility;
import ccm.server.util.PerformanceUtility;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.yulichang.base.MPJBaseMapper;
import com.github.yulichang.base.MPJBaseServiceImpl;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.toolkit.Constant;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service("metaDataServiceImpl")
@Slf4j
public abstract class MetaDataServiceImpl<M extends MPJBaseMapper<T>, T extends MetaData> extends MPJBaseServiceImpl<M, T> implements IMetaDataService<T> {
    @Override
    public MPJBaseMapper<T> myMapper() {
        return (MPJBaseMapper<T>) this.getBaseMapper();
    }

    @Autowired
    private ThreadsProcessor threadsProcessor;
    @Autowired
    private ISharedLocalService sharedLocalService;

    @Override
    public List<T> getByPrimaryKeys(List<String> primaryKeys) {
        if (CommonUtility.hasValue(primaryKeys))
            return this.getBaseMapper().selectBatchIds(primaryKeys);
        return null;
    }

    @Override
    public void setConfigurationAndDomain(String configuration, String domain) {
        if (configuration == null)
            configuration = "";
        if (StringUtils.isEmpty(domain))
            domain = domainInfo.SCHEMA.toString();
        ConfigurationPlusDomainTableNameParser.setConfigurationAndDomainGroupAlias(configuration, domain);
    }

    protected void setQueryConfigCondition(MPJLambdaWrapper<T> queryWrapper, ScopeConfiguration currentScope) {
        if (queryWrapper != null) {
            if (currentScope != null && CommonUtility.hasValue(currentScope.getQueryConfigs())) {
                List<LiteObject> queryConfigs = currentScope.getQueryConfigs();
                if (CommonUtility.hasValue(queryConfigs)) {
                    List<String> configUids = new ArrayList<>();
                    configUids.add("");
                    for (LiteObject queryConfig : queryConfigs) {
                        if (!queryConfig.getObjUID().equalsIgnoreCase(ScopeConfiguration.SCOPE_NOT_SET_UID))
                            configUids.add(queryConfig.getObjUID());
                    }
                    if (configUids.size() == 1 && configUids.get(0).trim().equalsIgnoreCase("")) {
                        //log.info("no scoped found and no need to add query scope in query wrapper");
                    } else
                        queryWrapper.in(T::getConfig, configUids);
                }
            }
        }
    }

    protected void setQueryConfigCondition(MPJQueryWrapper<T> queryWrapper, ScopeConfiguration currentScope) {
        if (queryWrapper != null) {
            if (currentScope != null && CommonUtility.hasValue(currentScope.getQueryConfigs())) {
                List<LiteObject> queryConfigs = currentScope.getQueryConfigs();
                if (CommonUtility.hasValue(queryConfigs)) {
                    List<String> configUids = new ArrayList<>();
                    configUids.add("");
                    for (LiteObject queryConfig : queryConfigs) {
                        if (!queryConfig.getObjUID().equalsIgnoreCase(ScopeConfiguration.SCOPE_NOT_SET_UID))
                            configUids.add(queryConfig.getObjUID());
                    }
                    if (configUids.size() == 1 && configUids.get(0).trim().equalsIgnoreCase("")) {
                        // log.trace("no scoped found and no need to add query scope in query wrapper");
                    } else
                        queryWrapper.in(propertyDefinitionType.Config.generateColumn(Constant.TABLE_ALIAS), configUids);
                }
            }
        }
    }

    protected void setQueryConfigCondition(QueryWrapper<T> queryWrapper, ScopeConfiguration currentScope) {
        if (queryWrapper != null) {
            if (currentScope != null && CommonUtility.hasValue(currentScope.getQueryConfigs())) {
                List<LiteObject> queryConfigs = currentScope.getQueryConfigs();
                if (CommonUtility.hasValue(queryConfigs)) {
                    List<String> configUids = new ArrayList<>();
                    configUids.add("");
                    for (LiteObject queryConfig : queryConfigs) {
                        if (!queryConfig.getObjUID().equalsIgnoreCase(ScopeConfiguration.SCOPE_NOT_SET_UID))
                            configUids.add(queryConfig.getObjUID());
                    }
                    if (configUids.size() == 1 && configUids.get(0).trim().equalsIgnoreCase("")) {
                        // log.trace("no scoped found and no need to add query scope in query wrapper");
                    } else
                        queryWrapper.lambda().in(T::getConfig, configUids);
                }
            }
        }
    }

    @Override
    public QueryWrapper<T> generateQueryWrapper(ScopeConfiguration scopeConfiguration) {
        return this.generateQueryWrapper();
    }

    @Override
    public ThrowableConsumer<List<T>> deleteConsumer() {
        return e -> {
            boolean b = threadDelete(e);
            if (b)
                e.clear();
            if (!b)
                throw new Exception("deleting progress failed");
        };
    }

    @Override
    public ThrowableConsumer<List<T>> terminateConsumer() {
        return ts -> {
            if (CommonUtility.hasValue(ts)) {
                boolean b = threadTerminate(ts);
                if (!b)
                    throw new Exception("termination progress failed");
            }
        };
    }

    @Override
    public ThrowableConsumer<List<T>> createOrUpdateConsumer() {
        return ts -> {
            if (CommonUtility.hasValue(ts)) {
                boolean flag = threadCreateOrUpdate(ts);
                //  log.trace("create consumer result:" + flag);
            }
        };
    }

    @Override
    public ThrowableConsumer<List<T>> existConsumer(QueryWrapper<T> queryWrapper) {
        return ts -> {
            if (CommonUtility.hasValue(ts)) {
                if (queryWrapper != null) {
                    List<T> selectList = get(queryWrapper);
                    if (CommonUtility.hasValue(selectList)) {
                        ts.clear();
                        ts.addAll(new ArrayList<>(selectList));
                    } else
                        ts.clear();
                } else
                    ts.clear();
            }
        };
    }

    @Override
    public ThrowableConsumer<List<T>> queryConsumer() {
        return ts -> {
            if (CommonUtility.hasValue(ts)) {
                QueryWrapper<T> queryWrapper = generateExistQueryWrapper(ts);
                if (queryWrapper != null) {
                    List<T> selectList = get(queryWrapper);
                    if (CommonUtility.hasValue(selectList)) {
                        ts.clear();
                        ts.addAll(new ArrayList<>(selectList));
                    } else
                        ts.clear();
                } else
                    ts.clear();
            }
        };
    }

    @Override
    public ThrowableConsumer<List<T>> createConsumer() {
        return ts -> {
            if (CommonUtility.hasValue(ts)) {
                boolean flag = threadCreate(ts);
                if (!flag)
                    ts.clear();
                // log.trace("create consumer result:" + flag);
            }
        };
    }

    @Override
    public ThrowableConsumer<List<T>> updateConsumer() {
        return ts -> {
            if (CommonUtility.hasValue(ts)) {
                boolean update = threadUpdate(ts);
                if (!update) ts.clear();
                // log.trace("update consumer result:" + update);
            }
        };
    }

    @SneakyThrows
    @Override
    public List<T> get(Class<T> tClass, MPJQueryWrapper<T> queryWrapper) {
        if (queryWrapper != null) {
            try {
                List<T> ts = this.myMapper().selectJoinList(tClass, queryWrapper);
                ts = ts.stream().distinct().collect(Collectors.toList());
                return ts;
            } catch (Exception exception) {
                log.error(exception.getMessage());
            }
        }
        return null;
    }

    @Override
    public List<Map<String, Object>> get(MPJQueryWrapper<?> queryWrapper) {
        if (queryWrapper != null) {
            return this.getBaseMapper().selectJoinMaps(queryWrapper);
        }
        return null;
    }

    @Override
    public Map<String, T> mapByKey(List<T> t) {
        // log.trace("enter to mapByKey(List<T> t)");
        Map<String, T> result = null;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t))
            result = t.stream().collect(Collectors.toMap(T::getUniqueIdentity, c -> c));
        // log.trace("exit to mapByKey(List<T> t):" + t.size() + ", map size:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean terminate(T t) {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (t != null) {
            if (t.fromDb()) {
                t.setTerminationDate(new Date());
                result = this.update(t);
            } else
                log.warn("provided entity is not from db record,cannot terminate");
        }
        // log.trace("exit to terminate(T t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public boolean terminate(List<T> t) throws Exception {
        boolean result = true;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            t.forEach(c -> {
                c.setTerminationDate(new Date());
            });
            result = this.update(t);
        }
        //log.trace("exit to terminate(List<T> t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }


    @Override
    public T ensure(T t) {
        T result = null;
        //log.trace("enter to ensure(T t) ->" + CommonUtility.getObjectClass(t));
        StopWatch stopWatch = PerformanceUtility.start();
        if (t != null) {
            QueryWrapper<T> queryWrapper = this.generateExistQueryWrapper(t);
            if (queryWrapper != null)
                result = this.getBaseMapper().selectOne(queryWrapper);
        }
        // log.trace("exit to ensure(T t) -> " + CommonUtility.getToString(result) + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public String ensurePrimaryKey(T t) {
        T ensure = this.ensure(t);
        if (ensure != null)
            return ensure.getPrimaryKey();
        return "";
    }

    @Override
    public QueryWrapper<T> generateQueryWrapper() {
        return new QueryWrapper<T>();
    }

    @Override
    public boolean exist(T t) {
        // log.trace("enter to exist(T t)");
        StopWatch stopWatch = PerformanceUtility.start();
        boolean result = false;
        QueryWrapper<T> queryWrapper = this.generateExistQueryWrapper(t);
        result = this.getBaseMapper().selectCount(queryWrapper) > 0;
        //  log.trace("exit to exist(T t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public List<T> exist(QueryWrapper<T> queryWrapper) throws Exception {
        // log.trace("enter to exist(QueryWrapper<T> queryWrapper):");
        List<T> result = new ArrayList<>();
        StopWatch stopWatch = PerformanceUtility.start();
        return null;
    }

    @Override
    public List<T> exist(List<T> ts, boolean callFromMainThread) throws Exception {
        if (CommonUtility.hasValue(ts)) {
            // log.trace("enter to exist judgement progress for " + ts.get(0).getClass().getName() + " and call from Main Thread:" + callFromMainThread);
            List<T> result = new ArrayList<>();
            StopWatch stopWatch = PerformanceUtility.start();
            List<T> judgement = new ArrayList<>(result);
//            if (CommonUtility.hasValue(ts)) {
//                for (T t : ts) {
//                    if (t.fromDb())
//                        result.add(t);
//                    else
//                        judgement.add(t);
//                }
//            }
//            log.info("exist items->" + result.size() + " identified by fromDb()");
            ts.removeAll(result);
//            log.info("provided list to be -> " + CommonUtility.getSize(ts));
            if (CommonUtility.hasValue(judgement)) {
                ResultSet<T> resultSet = null;
                if (callFromMainThread)
                    resultSet = this.threadsProcessor.query(judgement, this.queryConsumer());
                else
                    resultSet = this.threadsProcessor.queryMT(judgement, this.queryConsumer());

                if (resultSet.getResult()) {
                    List<T> query = resultSet.getList();
//                    log.info("start to set db status for provided list");
                    Collection<T> defectList = CollectionUtility.receiveCollectionList(ts, query);
                    // log.trace("defect list from provided to exist:" + CommonUtility.getSize(defectList));
                    if (CommonUtility.hasValue(defectList)) {
                        ArrayList<T> finalList = new ArrayList<>(CollectionUtility.receiveDefectList(ts, defectList));
                        ts.clear();
                        ts.addAll(finalList);
                        Map<String, List<T>> listMap = query.stream().collect(Collectors.groupingBy(MetaData::toString));
                        for (T t : defectList) {
                            if (listMap.containsKey(t.toString())) {
                                T t1 = listMap.get(t.toString()).get(0);
                                if (t1 != null) {
                                    t.setPrimaryKey(t1.getPrimaryKey());
                                    result.add(t);
                                }
                            }
                        }
                    }
                }
            }
            //log.trace("existed-> " + result.size() + ", new-> " + ts.size() + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public boolean create(T t) throws Exception {
        boolean result = false;
        // log.trace("enter to create(T t)");
        StopWatch stopWatch = PerformanceUtility.start();
        if (t != null) {
            this.beforeCreate(t);
            result = this.save(t);
        }
        //log.trace("exit create(T t)->" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public boolean create(List<T> t) throws Exception {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            //  log.trace("enter to create(List<T> t):" + CommonUtility.getSize(t));
            result = this.getResult(t, this.createConsumer());
        } else return true;
        //  log.trace("exit create(List<T> t)->" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean update(T t) {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (t != null) {
            // log.trace("enter to update(T t)" + t.getClass().toString());
            this.beforeUpdate(t);
            result = this.getBaseMapper().updateById(t) > 0;
        } else
            return true;
        //  log.trace("exit update(T t) -> " + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public boolean update(List<T> t) throws Exception {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            //   log.trace("enter to update(List<T> t) -> " + t.size() + "," + t.get(0).getClass().toString());
            result = this.getResult(t, this.updateConsumer());
        } else
            return true;
        // log.trace("exit to update(List<T> t) ->" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean createOrUpdate(T t) throws Exception {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (t != null) {
            T t1 = this.ensure(t);
            if (t1 != null) {
                t.setPrimaryKey(t1.getPrimaryKey());
                this.beforeUpdate(t);
            } else
                this.beforeCreate(t);
            // log.trace("enter to createOrUpdate(T t)" + t.getClass().toString());
            result = this.saveOrUpdate(t);
        }
        // log.trace("exit to createOrUpdate(T t)" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    protected boolean getResult(List<T> ts, ThrowableConsumer<List<T>> consumer) throws Exception {
        boolean result = false;
        if (CommonUtility.hasValue(ts) && consumer != null) {
            List<T> finalList = new ArrayList<>(ts);
            consumer.accept(finalList);
            ts.clear();
            ts.addAll(finalList);
            result = true;
//            ResultSet<T> resultSet = this.threadsProcessor.dml(ts, consumer);
//            result = resultSet.getResult();
//            if (result) {
//                ts.clear();
//                ts.addAll(resultSet.getList());
//            } else
//                resultSet.Throw();
        }
        return result;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean createOrUpdate(List<T> t) throws Exception {
        boolean result = false;
        if (CommonUtility.hasValue(t)) {
            // log.trace("enter to createOrUpdate(List<T> t)," + t.get(0).getClass().toString() + "," + t.size());
            StopWatch stopWatch = PerformanceUtility.start();
            result = this.getResult(t, this.createOrUpdateConsumer());
            //  log.trace("exit to createOrUpdate(List<T> t:" + result + PerformanceUtility.stop(stopWatch));
        }
        return result;
    }

    @Override
    public boolean delete(T t) {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        // log.trace("enter to delete(T t)");
        if (t != null) {
            if (t.fromDb())
                result = this.getBaseMapper().deleteById(t.getPrimaryKey()) != -1;
//            else{
//                // log.trace("provided entity is not from db, cannot delete it");
//            }

        }
        //   log.trace("exit to delete(T t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public boolean delete(List<T> t) {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            // log.trace("enter to delete(List<T> t:" + t.size());
            int i = this.getBaseMapper().deleteBatchIds(t.stream().map(MetaData::getPrimaryKey).filter(c -> !StringUtils.isEmpty(c)).collect(Collectors.toList()));
            result = i != -1;
        }
        // log.trace("exit to delete(List<T> t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean deleteByObid(T t) throws Exception {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (t != null) {
            QueryWrapper<T> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().eq(T::getObid, t.getObid());
            result = this.getBaseMapper().delete(queryWrapper) != -1;
        }
        // log.trace("exit to deleteByObid(T t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public boolean deleteByObid(List<T> t) throws Exception {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            QueryWrapper<T> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().in(T::getObid, t.stream().map(T::getObid).collect(Collectors.toList()));
            result = this.getBaseMapper().delete(queryWrapper) != -1;
        }
        //log.trace("exit to deleteByObid(T t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public List<T> get(QueryWrapper<T> queryWrapper) {
        if (queryWrapper != null)
            return this.getBaseMapper().selectList(queryWrapper);
        return null;
    }

    @Override
    public List<T> get(Class<T> tClass, MPJLambdaWrapper<T> lambdaWrapper) {
        if (lambdaWrapper != null) {
            return this.myMapper().selectJoinList(tClass, lambdaWrapper);
        }
        return null;
    }

    @Override
    public QueryWrapper<T> generateExistQueryWrapper(T t) {
        return null;
    }

    @Override
    public QueryWrapper<T> generateExistQueryWrapper(List<T> t) {
        return null;
    }

    @Override
    public boolean equal(T t1, T t2) {
        if (t1 != null && t2 != null) {
            return t1.toString().equalsIgnoreCase(t2.toString());
        }
        return false;
    }

    @Override
    public void beforeUpdate(T t) {

    }

    @Override
    public void beforeCreate(T t) {
//        if (t != null)
//            if (t.getCreationDate() == null || StringUtils.isEmpty(t.getCreationDate().toString()))
//                t.setCreationDate(CommonUtility.localDateTimeToDate(LocalDateTime.now()));
    }

    @Override
    public void afterUpdate(T t) {
    }

    @Override
    public void afterCreate(T t) {
    }

    public static <T extends MetaData> Map<String, List<T>> splitWithTablePrefix(List<T> ts) {
        Map<String, List<T>> result = new HashMap<>();
        if (CommonUtility.hasValue(ts)) {
            for (T t : ts) {
                List<String> uniqueTablePrefixes = t.UniqueTablePrefix();
                for (String tablePrefix : uniqueTablePrefixes)
                    CommonUtility.doAddElement(result, tablePrefix, t);
            }
        }
        return result;
    }

    @Override
    public boolean threadCreate(List<T> t) throws Exception {
        boolean result = true;
        StopWatch stopWatch = PerformanceUtility.start();
        Exception exception = null;
        if (CommonUtility.hasValue(t)) {
            //  log.trace("enter to thread create progress for " + t.get(0).getClass().getName());
            try {
                Map<String, List<T>> splitWithTablePrefix = splitWithTablePrefix(t);
                for (Map.Entry<String, List<T>> listEntry : splitWithTablePrefix.entrySet()) {
                    StopWatch stopWatch1 = PerformanceUtility.start();
                    String simpleName = listEntry.getValue().get(0).getClass().getSimpleName();
                    ConfigurationPlusDomainTableNameParser.setTablePrefix(listEntry.getKey());
                    //  log.info("start to thread-create " + listEntry.getValue().size() + " under *****" + listEntry.getKey() + simpleName);
                    for (T t1 : listEntry.getValue()) {
                        t1.selfCheck();
                    }
                    result = result && this.saveBatch(listEntry.getValue());
                    // log.trace("complete to thread-create:" + listEntry.getValue().size() + PerformanceUtility.stop(stopWatch1));
                }
            } catch (Exception e) {
                ConfigurationPlusDomainTableNameParser.reset();
                log.error("thread create failed", e);
                exception = e;
            }
        }
        if (exception != null)
            throw exception;
        // log.trace("********** exit to thread Create: " + result + " ************" + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean threadUpdate(List<T> t) throws Exception {
        boolean result = true;
        Exception exception = null;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            //  log.trace("enter to thread update progress for " + t.get(0).getClass().getName());
            try {
                Map<String, List<T>> splitWithTablePrefix = splitWithTablePrefix(t);
                for (Map.Entry<String, List<T>> listEntry : splitWithTablePrefix.entrySet()) {
                    StopWatch stopWatch1 = PerformanceUtility.start();
                    String simpleName = listEntry.getValue().get(0).getClass().getSimpleName();
                    ConfigurationPlusDomainTableNameParser.setTablePrefix(listEntry.getKey());
                    //   log.info("start to thread-update " + listEntry.getValue().size() + " under " + listEntry.getKey() + simpleName);
                    for (T t1 : listEntry.getValue()) {
                        t1.selfCheck();
                    }
                    List<List<T>> listList = CommonUtility.createList(listEntry.getValue());
                    for (List<T> ts : listList) {
                        result = result && this.updateBatchById(ts);
                    }
                    //  log.trace("complete to thread-update:" + listEntry.getValue().size() + PerformanceUtility.stop(stopWatch1));
                }
            } catch (Exception e) {
                ConfigurationPlusDomainTableNameParser.reset();
                log.error("thread update failed", e);
                exception = e;
            }
        }
        if (exception != null)
            throw exception;
        // log.trace("********** exit to thread update:" + result + " *************" + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean threadDelete(List<T> t) throws Exception {
        if (CommonUtility.hasValue(t)) {
            Exception exception = null;
            // log.trace("enter to thread delete for " + t.get(0).getClass().getName());
            StopWatch stopWatch = PerformanceUtility.start();
            Map<String, List<T>> splitWithTablePrefix = splitWithTablePrefix(t);
            boolean result = true;
            int i = 0;
            try {
                for (Map.Entry<String, List<T>> listEntry : splitWithTablePrefix.entrySet()) {
                    StopWatch stopWatch1 = PerformanceUtility.start();
                    String simpleName = listEntry.getValue().get(0).getClass().getSimpleName();
                    ConfigurationPlusDomainTableNameParser.setTablePrefix(listEntry.getKey());
                    //  log.info("start to thread-delete " + listEntry.getValue().size() + " under " + listEntry.getKey() + simpleName);
                    List<List<T>> listList = CommonUtility.createList(listEntry.getValue());
                    for (List<T> list : listList) {
                        i += this.myMapper().deleteBatchIds(list.stream().map(MetaData::getPrimaryKey).collect(Collectors.toList()));
                    }
                    //   log.trace("complete to thread-delete:" + listEntry.getValue().size() + PerformanceUtility.stop(stopWatch1));
                }
            } catch (Exception ex) {
                ConfigurationPlusDomainTableNameParser.reset();
                result = false;
                log.error("thread delete failed", ex);
                exception = ex;
            }
            if (result)
                result = i >= 0;
            if (exception != null)
                throw exception;
            // log.trace("********* thread delete progress completed and effect row(s):" + i + "*********" + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public boolean threadTerminate(List<T> t) throws Exception {
        if (CommonUtility.hasValue(t)) {
            //  log.trace("enter to thread terminate for " + t.get(0).getClass().getName());
            StopWatch stopWatch = PerformanceUtility.start();
            Exception exception = null;
            boolean result = true;
            Map<String, List<T>> listMap = splitWithTablePrefix(t);
            try {
                for (Map.Entry<String, List<T>> listEntry : listMap.entrySet()) {
                    StopWatch stopWatch1 = PerformanceUtility.start();
                    String simpleName = listEntry.getValue().get(0).getClass().getSimpleName();
                    ConfigurationPlusDomainTableNameParser.setTablePrefix(listEntry.getKey());
                    // log.trace("start to thread-terminate " + listEntry.getValue().size() + " under " + listEntry.getKey() + simpleName);
                    List<List<T>> listList = CommonUtility.createList(listEntry.getValue());
                    for (List<T> list : listList) {
                        boolean tempResult = this.updateBatchById(list);
                        if (result)
                            result = tempResult;
                    }
                    // log.info("complete to thread-terminate:" + listEntry.getValue().size() + PerformanceUtility.stop(stopWatch1));
                }
            } catch (Exception e) {
                exception = e;
                result = false;
                log.error("thread terminated failed", exception);
                ConfigurationPlusDomainTableNameParser.reset();
            }
            if (exception != null)
                throw exception;
            //  log.trace("********* terminate complete: " + result + "*********" + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return false;
    }

    @Override
    public boolean threadCreateOrUpdate(List<T> t) throws Exception {
        boolean result = true;
        StopWatch stopWatch = PerformanceUtility.start();
        Exception exception = null;
        if (CommonUtility.hasValue(t)) {
            // log.trace("enter to thread create or update progress for " + t.get(0).getClass().getName());
            Map<String, List<T>> splitWithTablePrefix = splitWithTablePrefix(t);
            try {
                for (Map.Entry<String, List<T>> listEntry : splitWithTablePrefix.entrySet()) {
                    ConfigurationPlusDomainTableNameParser.setTablePrefix(listEntry.getKey());
                    List<T> entryValue = listEntry.getValue();
                    List<T> ts = this.exist(entryValue, false);
                    entryValue.forEach(c -> {
                        this.beforeCreate(c);
                        this.beforeUpdate(c);
                    });
                    boolean tempResult = this.saveOrUpdateBatch(entryValue);
                    if (result)
                        result = tempResult;
                }
            } catch (Exception e) {
                result = false;
                log.error("thread create or update failed", e);
                exception = e;
                ConfigurationPlusDomainTableNameParser.reset();
            }
        }
        if (exception != null)
            throw exception;
        // log.trace("exit to threadCreateOrUpdate(List<T> t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean threadQuery(String tablePrefix, QueryWrapper<T> queryWrapper, List<T> result) {
        // log.trace("enter to thread query with " + tablePrefix);
        if (queryWrapper != null) {
            StopWatch stopWatch = PerformanceUtility.start();
            ConfigurationPlusDomainTableNameParser.setTablePrefix(tablePrefix);
            List<T> selectList = this.getBaseMapper().selectList(queryWrapper);
            result.clear();
            if (selectList != null)
                result.addAll(selectList);
            // log.info("complete to do thread-query" + PerformanceUtility.stop(stopWatch));
            return true;
        }
        return false;
    }

    @Override
    public ThrowableConsumer<List<T>> queryConsumer(QueryWrapper<T> queryWrapper, String tablePrefix) {
        return e -> {
            if (e == null)
                throw new Exception("invalid result container as it is null");
            e.clear();
            boolean flag = threadQuery(tablePrefix, queryWrapper, e);
            if (!flag)
                throw new Exception("query progress failed with exception");
        };
    }
}
