package ccm.server.service;

import ccm.server.entity.MetaDataObjPropertyDetails;

public interface IMetaDataObjPropertyDetailsService extends IMetaDataService<MetaDataObjPropertyDetails> {
    MetaDataObjPropertyDetails getPropertyDetails(String propertyObid);
}
