package ccm.server.service;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataRel;
import ccm.server.models.page.PageResult;
import ccm.server.params.ObjRelationshipCarrier;
import ccm.server.params.RelRelationshipCarrier;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;

import java.util.List;
import java.util.Map;

public interface IMetaDataRelService extends IMetaDataService<MetaDataRel> {

    PageResult<MetaDataRel> get(QueryWrapper<MetaDataRel> queryWrapper, int pageIndex, int pageSize);

    @Deprecated
    PageResult<MetaDataRel> get(MPJLambdaWrapper<MetaDataRel> wrapper, int pageIndex, int pageSize);

    PageResult<MetaDataRel> get(MPJQueryWrapper<MetaDataRel> wrapper, int pageIndex, int pageSize);



    List<MetaDataRel> getEnd1Relationships(String uid1, String relDefUid);

    List<MetaDataRel> getEnd1Relationships(String uid1);

    List<MetaDataRel> getEnd1Relationships(String uid1, List<String> relDefUids);

    List<MetaDataRel> getEnd2Relationships(String uid2, String relDefUid);

    List<MetaDataRel> getEnd2Relationships(String uid2);

    List<MetaDataRel> getEnd2Relationships(String uid2, List<String> relDefUids);

    Map<MetaDataObj, List<MetaDataRel>> getEnd1Relationships(List<MetaDataObj> objs, List<String> relDefUids);

    Map<MetaDataRel, List<MetaDataRel>> getEnd1RelationshipsForRel(List<MetaDataRel> rels, List<String> relDefUids);

    Map<MetaDataObj, List<MetaDataRel>> getEnd2Relationships(List<MetaDataObj> objs, List<String> relDefUids);

    Map<MetaDataRel, List<MetaDataRel>> getEnd2RelationshipsForRel(List<MetaDataRel> rels, List<String> relDefUids);

    List<MetaDataRel> getRelationshipsByRelDef(String relDef);

    List<MetaDataRel> getRelationshipsByRelDef(List<String> relDefs);


    boolean terminateEnd1Relationships(String uid1);

    boolean terminateEnd1Relationships(String uid1, String relDefUid);

    boolean terminateEnd1Relationships(String uid1, List<String> relDefUids);


    boolean terminateEnd2Relationships(String uid2);

    boolean terminateEnd2Relationships(String uid2, String relDefUid);

    boolean terminateEnd2Relationships(String uid2, List<String> relDefUids);

    ThrowableConsumer<ObjRelationshipCarrier> fillingObj();

    ThrowableConsumer<RelRelationshipCarrier> fillingRel();

    MetaDataRel getByUIDAndDomainUID(String uid, String domainUID);

    List<MetaDataRel> getByUIDAndDomainUID(List<String> uid, String domainUID);

    List<MetaDataRel> getByUIDAndDomainUID(List<String> uid, List<String> domainUID);

}
