package ccm.server.service;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaData;
import ccm.server.models.info.InfoIFAndPRDetail;
import ccm.server.params.InfoDetailsCarrier;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

import com.baomidou.mybatisplus.core.conditions.Wrapper;

public interface IInfoDetailsService extends IService<InfoIFAndPRDetail> {
    List<InfoIFAndPRDetail> getOBJInfoDetails(Wrapper<InfoIFAndPRDetail> wrapper);

    List<InfoIFAndPRDetail> getRELInfoDetails(Wrapper<InfoIFAndPRDetail> wrapper);

    <T extends MetaData> ThrowableConsumer<InfoDetailsCarrier<T>> getInfoDetailsConsumer();
}
