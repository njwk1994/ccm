package ccm.server.service.impl;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaData;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataRel;
import ccm.server.handlers.ConfigurationPlusDomainTableNameParser;
import ccm.server.models.info.InfoIFAndPRDetail;
import ccm.server.module.mapper.InfoIFAndPRDetailsMapper;
import ccm.server.params.InfoDetailsCarrier;
import ccm.server.service.IInfoDetailsService;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.yulichang.base.MPJBaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class InfoDetailServiceImpl extends MPJBaseServiceImpl<InfoIFAndPRDetailsMapper, InfoIFAndPRDetail> implements IInfoDetailsService {
    @Override
    public List<InfoIFAndPRDetail> getOBJInfoDetails(Wrapper<InfoIFAndPRDetail> wrapper) {
        return this.baseMapper.getOBJInfoDetails(wrapper);
    }

    @Override
    public List<InfoIFAndPRDetail> getRELInfoDetails(Wrapper<InfoIFAndPRDetail> wrapper) {
        return this.baseMapper.getRELInfoDetails(wrapper);
    }

    @Override
    public <T extends MetaData> ThrowableConsumer<InfoDetailsCarrier<T>> getInfoDetailsConsumer() {
        return infoDetailsCarrier -> {
            QueryWrapper<InfoIFAndPRDetail> queryWrapper = new QueryWrapper<>();
            queryWrapper.in("t.obid", infoDetailsCarrier.getSource().stream().map(MetaData::getObid).collect(Collectors.toList()));
            ConfigurationPlusDomainTableNameParser.setTablePrefix(infoDetailsCarrier.getTablePrefix());
            List<InfoIFAndPRDetail> infoIFAndPRDetails = null;
            if (infoDetailsCarrier.getTClass().equals(MetaDataObj.class)) {
                infoIFAndPRDetails = this.getOBJInfoDetails(queryWrapper);
            } else if (infoDetailsCarrier.getTClass().equals(MetaDataRel.class)) {
                infoIFAndPRDetails = this.getRELInfoDetails(queryWrapper);
            }
            if (infoIFAndPRDetails != null && infoIFAndPRDetails.size() > 0)
                infoDetailsCarrier.getFinalResult().addAll(infoIFAndPRDetails);
            ConfigurationPlusDomainTableNameParser.reset();
        };
    }
}
