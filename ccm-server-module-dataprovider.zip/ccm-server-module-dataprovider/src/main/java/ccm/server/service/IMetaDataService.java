package ccm.server.service;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaData;
import ccm.server.models.scope.ScopeConfiguration;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.github.yulichang.base.MPJBaseMapper;
import com.github.yulichang.query.MPJQueryWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;

import java.util.List;
import java.util.Map;

public interface IMetaDataService<T extends MetaData> extends IService<T> {

    MPJBaseMapper myMapper();

    List<T> getByPrimaryKeys(List<String> primaryKeys);

    QueryWrapper<T> generateQueryWrapper();

    QueryWrapper<T> generateQueryWrapper(ScopeConfiguration scopeConfiguration);

    void setConfigurationAndDomain(String configuration, String domain);

    boolean exist(T t);

    ThrowableConsumer<List<T>> existConsumer(QueryWrapper<T> queryWrapper);

    ThrowableConsumer<List<T>> queryConsumer();

    ThrowableConsumer<List<T>> createConsumer();

    ThrowableConsumer<List<T>> updateConsumer();

    ThrowableConsumer<List<T>> queryConsumer(QueryWrapper<T> queryWrapper, String tablePrefix);

    ThrowableConsumer<List<T>> createOrUpdateConsumer();

    ThrowableConsumer<List<T>> deleteConsumer();

    ThrowableConsumer<List<T>> terminateConsumer();

    Map<String, T> mapByKey(List<T> t);

    String ensurePrimaryKey(T t);

    boolean terminate(T t);

    boolean terminate(List<T> t) throws Exception;

    T ensure(T t);

    List<T> exist(QueryWrapper<T> queryWrapper) throws Exception;

    //**
    //return existed items in database, and result items' obid will be reset by db records
    //and remove existed info from provided list together
    //**
    List<T> exist(List<T> ts, boolean callFromMainThread) throws Exception;

    boolean create(T t) throws Exception;

    boolean create(List<T> t) throws Exception;

    boolean update(T t);

    boolean update(List<T> t) throws Exception;

    boolean createOrUpdate(T t) throws Exception;

    boolean createOrUpdate(List<T> t) throws Exception;

    boolean delete(T t);

    boolean delete(List<T> t);

    boolean deleteByObid(T t) throws Exception;

    boolean deleteByObid(List<T> t) throws Exception;

    List<T> get(QueryWrapper<T> queryWrapper);

    List<T> get(Class<T> tClass, MPJLambdaWrapper<T> lambdaWrapper);

    List<T> get(Class<T> tClass, MPJQueryWrapper<T> queryWrapper);

    List<Map<String, Object>> get(MPJQueryWrapper<?> queryWrapper);

    QueryWrapper<T> generateExistQueryWrapper(T t);

    QueryWrapper<T> generateExistQueryWrapper(List<T> t);

    boolean equal(T t1, T t2);

    void beforeUpdate(T t);

    void beforeCreate(T t);

    void afterUpdate(T t);

    void afterCreate(T t);

    boolean threadCreate(List<T> t) throws Exception;

    boolean threadUpdate(List<T> t) throws Exception;

    boolean threadCreateOrUpdate(List<T> t) throws Exception;

    boolean threadDelete(List<T> t) throws Exception;

    boolean threadTerminate(List<T> t) throws Exception;

    boolean threadQuery(String tablePrefix, QueryWrapper<T> queryWrapper, List<T> result);
}
