package ccm.server.service.impl;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaData;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataObjInterface;
import ccm.server.entity.MetaDataRel;
import ccm.server.handlers.ConfigurationPlusDomainTableNameParser;
import ccm.server.module.mapper.MetaDataObjInterfaceMapper;
import ccm.server.params.IfAndPRCarrier;
import ccm.server.service.IMetaDataObjInterfaceService;
import ccm.server.util.CommonUtility;
import ccm.server.util.PerformanceUtility;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service("metaDataObjInterfaceServiceImpl")
@Slf4j
public class MetaDataObjInterfaceServiceImpl extends MetaDataServiceImpl<MetaDataObjInterfaceMapper, MetaDataObjInterface> implements IMetaDataObjInterfaceService {
    @Override
    public QueryWrapper<MetaDataObjInterface> generateExistQueryWrapper(MetaDataObjInterface metaDataObjInterface) {
        if (metaDataObjInterface != null) {
            QueryWrapper<MetaDataObjInterface> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjInterface::getTerminationDate)
                    .eq(MetaDataObjInterface::getInterfaceDefUid, metaDataObjInterface.getInterfaceDefUid())
                    .eq(MetaDataObjInterface::getObjObid, metaDataObjInterface.getObjObid());
            return queryWrapper;
        }
        return null;
    }

    @Override
    public QueryWrapper<MetaDataObjInterface> generateExistQueryWrapper(List<MetaDataObjInterface> t) {
        if (CommonUtility.hasValue(t)) {
            QueryWrapper<MetaDataObjInterface> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjInterface::getTerminationDate)
                    .in(MetaDataObjInterface::getInterfaceDefUid, t.stream().map(MetaDataObjInterface::getInterfaceDefUid).distinct().collect(Collectors.toList()))
                    .in(MetaDataObjInterface::getObjObid, t.stream().map(MetaDataObjInterface::getObjObid).distinct().collect(Collectors.toList()));
            return queryWrapper;
        }
        return null;
    }

    @Override
    public void beforeUpdate(MetaDataObjInterface metaDataObjInterface) {

    }

    protected boolean same(MetaDataObjInterface p1, MetaDataObjInterface p2) {
        if (p1 != null && p2 != null) {
            if (p1.toString().equalsIgnoreCase(p2.toString()))
                return true;
        }
        return false;
    }

    private List<MetaDataObjInterface> filterForCreateAndTerminate(List<MetaDataObjInterface> t) throws ExecutionException, InterruptedException {
        List<MetaDataObjInterface> insertList = new ArrayList<>(t);
        Map<String, MetaDataObjInterface> mapInsert = this.mapByKey(insertList);
        List<MetaDataObjInterface> exist = null;
        try {
            exist = this.exist(t, false);
        } catch (Exception exception) {
            log.error(exception.getMessage());
        }
        if (CommonUtility.hasValue(exist)) {
            Map<String, MetaDataObjInterface> mapExist = this.mapByKey(exist);
            for (Map.Entry<String, MetaDataObjInterface> propertyEntry : mapExist.entrySet()) {
                if (mapInsert.containsKey(propertyEntry.getKey())) {
                    if (this.same(propertyEntry.getValue(), mapInsert.get(propertyEntry.getKey()))) {
                        mapInsert.remove(propertyEntry.getKey());
                        exist.remove(propertyEntry.getValue());
                    }
                }
            }
            t.clear();
            log.trace("existed interface(s) quantity:" + exist.size() + " to be terminated");
            t.addAll(exist);
        }
        log.trace("to be created interface(s) quantity:" + mapInsert.size());
        return new ArrayList<>(mapInsert.values());
    }


    @Override
    public boolean createOrUpdate(MetaDataObjInterface metaDataObjInterface) throws Exception {
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (metaDataObjInterface != null) {
            if (metaDataObjInterface.fromDb()) {
                boolean terminated = this.terminate(metaDataObjInterface);
                if (!terminated)
                    throw new Exception("terminate property failed for:" + metaDataObjInterface.toString());
            } else {
                MetaDataObjInterface ensure = this.ensure(metaDataObjInterface);
                if (ensure != null) {
                    if (this.same(ensure, metaDataObjInterface)) {
                        log.trace("provided interface is totally same with provided");
                        result = true;
                    } else {
                        boolean terminate = this.terminate(ensure);
                        if (!terminate)
                            throw new Exception("terminate interface failed for:" + ensure.toString());
                    }
                }
            }
            if (!result)
                result = this.create(metaDataObjInterface);
        }
        log.trace("exit to createOrUpdate(MetaDataObjInterface metaDataObjInterface:" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public boolean threadCreateOrUpdate(List<MetaDataObjInterface> t) throws Exception {
        log.trace("enter to threadCreateOrUpdate(List<MetaDataObjInterface> t):" + CommonUtility.getSize(t));
        boolean result = false;
        StopWatch stopWatch = PerformanceUtility.start();
        if (CommonUtility.hasValue(t)) {
            List<MetaDataObjInterface> toBeCreated = this.filterForCreateAndTerminate(t);
            result = this.terminate(t);
            if (!result) {
                throw new Exception("terminated interface(s) failed");
            }
            result = this.create(toBeCreated);
            if (!result) {
                throw new Exception("create interface(s) failed");
            }
        }
        log.trace("exit to threadCreateOrUpdate(List<MetaDataObjInterface> t):" + result + PerformanceUtility.stop(stopWatch));
        return result;
    }

    @Override
    public List<MetaDataObjInterface> getByObj(MetaDataObj metaDataObj) {
        if (metaDataObj != null && metaDataObj.fromDb())
            return this.getInfoInterfaces(metaDataObj.getObid());
        return null;
    }

    private List<MetaDataObjInterface> getInfoInterfaces(String obid) {
        if (StringUtils.isEmpty(obid)) {
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataObjInterface> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjInterface::getTerminationDate);
            queryWrapper.lambda().eq(MetaDataObjInterface::getObjObid, obid);
            List<MetaDataObjInterface> result = this.get(queryWrapper);
            log.info("progress result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public List<MetaDataObjInterface> getByRel(MetaDataRel metaDataRel) {
        if (metaDataRel != null && metaDataRel.fromDb())
            return getInfoInterfaces(metaDataRel.getObid());
        return null;
    }

    @Override
    public List<MetaDataObjInterface> getByRel(List<MetaDataRel> metaDataRels) {
        if (CommonUtility.hasValue(metaDataRels)) {
            return this.getInfoInterfaces(metaDataRels.stream().map(MetaData::getObid).distinct().collect(Collectors.toList()));
        }
        return null;
    }

    private List<MetaDataObjInterface> getInfoInterfaces(List<String> obids) {
        if (CommonUtility.hasValue(obids)) {
            StopWatch stopWatch = PerformanceUtility.start();
            QueryWrapper<MetaDataObjInterface> queryWrapper = this.generateQueryWrapper();
            queryWrapper.lambda().isNull(MetaDataObjInterface::getTerminationDate);
            queryWrapper.lambda().in(MetaDataObjInterface::getObjObid, obids);
            List<MetaDataObjInterface> result = this.get(queryWrapper);
            log.trace("get info interface result:" + CommonUtility.getSize(result) + PerformanceUtility.stop(stopWatch));
            return result;
        }
        return null;
    }

    @Override
    public List<MetaDataObjInterface> getByObj(List<MetaDataObj> metaDataObjs) {
        if (CommonUtility.hasValue(metaDataObjs)) {
            return this.getInfoInterfaces(metaDataObjs.stream().map(MetaData::getObid).distinct().collect(Collectors.toList()));
        }
        return null;
    }
}
