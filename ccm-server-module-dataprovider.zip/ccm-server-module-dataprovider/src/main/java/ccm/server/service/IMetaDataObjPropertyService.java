package ccm.server.service;

import ccm.server.consumers.ThrowableConsumer;
import ccm.server.entity.MetaDataObj;
import ccm.server.entity.MetaDataObjProperty;
import ccm.server.entity.MetaDataRel;
import ccm.server.params.IfAndPRCarrier;

import java.util.List;

public interface IMetaDataObjPropertyService extends IMetaDataService<MetaDataObjProperty> {

    List<MetaDataObjProperty> getByObjOBID(String objOBID);

    List<MetaDataObjProperty> getByObjOBID(List<String> objOBIDs);

    boolean deleteByObjOBID(String objOBID);

    boolean deleteByObjOBID(List<String> objOBID);

    List<MetaDataObjProperty> getByObject(MetaDataObj metaDataObj);

    List<MetaDataObjProperty> getByRel(MetaDataRel metaDataRel);

    List<MetaDataObjProperty> getByObject(List<MetaDataObj> metaDataObjs);

    List<MetaDataObjProperty> getByRel(List<MetaDataRel> metaDataRels);

    MetaDataObjProperty getProperty(String objOBID, String propertyDefUID);
}
