package ccm.server.service;

import ccm.server.models.LiteObjectPart;
import com.baomidou.mybatisplus.extension.service.IService;

public interface ILiteObjectPartService extends IService<LiteObjectPart> {

}
