package com.github.yulichang.wrapper;

import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.core.toolkit.support.ColumnCache;
import com.baomidou.mybatisplus.core.toolkit.support.SFunction;
import com.github.yulichang.toolkit.Constant;
import com.github.yulichang.toolkit.LambdaUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static java.util.stream.Collectors.joining;

/**
 * 参考 {@link com.baomidou.mybatisplus.core.conditions.AbstractLambdaWrapper}
 *
 * @author yulichang
 */
@Slf4j
public abstract class MPJAbstractLambdaWrapper<T, Children extends MPJAbstractLambdaWrapper<T, Children>>
    extends MPJAbstractWrapper<T, Children> {
//    protected final Map<Class<?>, List<Integer>> joinTableWrappers = new HashMap<>();
    /**
     * 关联的表
     */
    protected Map<Class<?>, Integer> subTable = new HashMap<>();
    /**
     * 缓存字段
     */
    protected Map<Class<?>, Map<String, ColumnCache>> columnMap = new HashMap<>();

//    protected void removeTableIndex(Class<?> clazz) {
//        if (this.joinTableWrappers.size() > 0) {
//            List<Integer> integerList = this.joinTableWrappers.getOrDefault(clazz, null);
//            if (integerList != null && integerList.size() > 0) {
//                integerList.remove(0);
//                this.joinTableWrappers.replace(clazz, integerList);
//            }
//        }
//    }
//
//    protected Integer getTaleIndex(Class<?> clazz, boolean removeFromCache) {
//        Integer result = null;
//        if (this.joinTableWrappers.size() > 0) {
//            List<Integer> integerList = this.joinTableWrappers.getOrDefault(clazz, null);
//            if (integerList != null && integerList.size() > 0) {
//                result = integerList.get(0);
//                if (removeFromCache) {
//                    integerList.remove(0);
//                    this.joinTableWrappers.replace(clazz, integerList);
//                }
//            }
//        }
//        return result;
//    }

    @Override
    protected <X> String columnToString(X column, Integer tableIndex) {
        return columnToString((SFunction<?, ?>) column, tableIndex);
    }

    @Override
    protected <X> String columnToString(X column) {
        return columnToString((SFunction<?, ?>) column);
    }

    @Override
    @SafeVarargs
    protected final <X> String columnsToString(X... columns) {
        return Arrays.stream(columns).map(i -> columnToString((SFunction<?, ?>) i)).collect(joining(StringPool.COMMA));
    }

    protected String columnToString(SFunction<?, ?> column) {
        return Constant.TABLE_ALIAS + getDefault(this.subTable.get(LambdaUtils.getEntityClass(column))) + StringPool.DOT +
                   getCache(column).getColumn();
    }

    protected String columnToString(SFunction<?, ?> column, Integer tableIndex) {
        if (tableIndex == null)
            return columnToString(column);
        return Constant.TABLE_ALIAS + getDefault(tableIndex) + StringPool.DOT +
                   getCache(column).getColumn();
    }

    protected ColumnCache getCache(SFunction<?, ?> fn) {
        Class<?> aClass = LambdaUtils.getEntityClass(fn);
        Map<String, ColumnCache> cacheMap = columnMap.get(aClass);
        if (cacheMap == null) {
            cacheMap = LambdaUtils.getColumnMap(aClass);
            columnMap.put(aClass, cacheMap);
        }
        return cacheMap.get(LambdaUtils.formatKey(LambdaUtils.getName(fn)));
    }

    protected String getDefault(Integer i) {
        if (Objects.nonNull(i)) {
            return i.toString();
        }
        return StringPool.EMPTY;
    }

}
